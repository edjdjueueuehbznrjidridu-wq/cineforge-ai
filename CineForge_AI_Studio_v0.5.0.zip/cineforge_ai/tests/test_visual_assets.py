from pathlib import Path

from PIL import Image, ImageDraw
import pytest

from app.schemas import Scene, VideoPlan, VideoRequest
from app import visual_assets


def test_extract_image_url_reads_documented_data_envelope():
    payload = {
        "success": True,
        "data": {"image": {"url": "https://cdn.example.test/scene.webp"}},
        "source": {"docs": "https://nestapi.ir/docs/"},
    }
    assert visual_assets.extract_image_url(payload) == "https://cdn.example.test/scene.webp"


def test_extract_image_url_uses_error_code_and_message():
    with pytest.raises(RuntimeError, match="GENERATION_FAILED"):
        visual_assets.extract_image_url({
            "success": False,
            "error": {"code": "GENERATION_FAILED", "message": "temporary"},
            "source": {"docs": "https://nestapi.ir/docs/"},
        })


def test_extract_image_url_rejects_success_without_image_url():
    with pytest.raises(RuntimeError, match="URL تصویر"):
        visual_assets.extract_image_url({"success": True, "data": {"status": "ok"}, "source": {"docs": "https://nestapi.ir/docs/"}})


def test_build_scene_image_prompt_contains_scene_specific_art_direction():
    request = VideoRequest(prompt="یک ویدیو درباره معماری پایدار بساز", duration=6, visual_engine="nano_banana")
    plan = VideoPlan(
        visual_bible="Warm documentary film, tactile stone and wood",
        subject_anchor="A contemporary sustainable building",
        scenes=[
            Scene(title="نمای هوایی", subtitle="ساختار در بافت شهر", duration=3, image_prompt="Aerial wide shot of a timber building", composition="diagonal"),
            Scene(title="جزئیات مصالح", subtitle="اتصال چوب و سنگ", duration=3, image_prompt="Extreme macro detail of wood and stone joinery", composition="left"),
        ],
    )
    first = visual_assets.build_scene_image_prompt(request, plan, 0)
    second = visual_assets.build_scene_image_prompt(request, plan, 1)
    assert first != second
    assert "PROJECT WORLD" in first
    assert "FRAMING" in first
    assert "No typography" in first
    assert "Extreme macro" in second


def _save_test_art(path: Path, variant: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    im = Image.new("RGB", (512, 512), (12, 22, 42))
    d = ImageDraw.Draw(im)
    if variant == "base":
        d.polygon([(40, 440), (210, 50), (310, 440)], fill=(40, 150, 180))
        d.ellipse((160, 100, 350, 290), fill=(235, 150, 60))
    elif variant == "different":
        d.rectangle((32, 32, 480, 220), fill=(150, 65, 100))
        for x in range(0, 512, 28):
            d.line((x, 260, 512-x, 500), fill=(65, 220, 160), width=4)
    else:
        d.ellipse((70, 70, 440, 440), outline=(100, 180, 255), width=25)
        d.rectangle((40, 350, 470, 450), fill=(230, 200, 90))
    im.save(path, "WEBP", quality=90)


def test_prepare_scene_assets_retries_near_duplicate_images(tmp_path, monkeypatch):
    monkeypatch.setattr(visual_assets, "ASSETS_DIR", tmp_path / "assets")
    request = VideoRequest(
        prompt="یک ویدیوی کوتاه درباره یک شهر آینده بساز",
        duration=6,
        resolution="540p",
        visual_engine="nano_banana",
    )
    plan = VideoPlan(scenes=[
        Scene(title="نمای شهر", duration=3, image_prompt="Wide aerial cinematic city skyline, golden dusk"),
        Scene(title="جزئیات خیابان", duration=3, image_prompt="Street-level cinematic view of the same city in rain"),
    ])
    calls = []

    def fake_generate(engine, prompt, ratio, quality, destination, *, upscale=True, upscale_scale=2):
        calls.append(prompt)
        if "CRITICAL DIFFERENT-SHOT REQUIREMENT" in prompt:
            _save_test_art(destination, "different")
        else:
            _save_test_art(destination, "base")
        return {"width": 512, "height": 512, "bytes": destination.stat().st_size}

    monkeypatch.setattr(visual_assets, "_generate_one", fake_generate)
    assets, report = visual_assets.prepare_scene_assets(request, plan, "project-test")
    assert set(assets) == {0, 1}
    assert report["generated"] == 2
    assert report["duplicate_retries"] == [2]
    assert report["unresolved_duplicates"] == []
    assert report["visual_diversity_passed"] is True
    assert len(calls) == 3
    assert assets[0].exists() and assets[1].exists()


def test_prepare_scene_assets_uses_cache(tmp_path, monkeypatch):
    monkeypatch.setattr(visual_assets, "ASSETS_DIR", tmp_path / "assets")
    request = VideoRequest(prompt="یک ویدیوی معماری بساز", duration=5, resolution="540p", visual_engine="nano_banana")
    plan = VideoPlan(scenes=[Scene(title="نمای اصلی", duration=5, image_prompt="A distinct modern architecture shot")])
    calls = []

    def fake_generate(engine, prompt, ratio, quality, destination, *, upscale=True, upscale_scale=2):
        calls.append(prompt)
        _save_test_art(destination, "different")
        return {"width": 512, "height": 512, "bytes": destination.stat().st_size}

    monkeypatch.setattr(visual_assets, "_generate_one", fake_generate)
    first_assets, first_report = visual_assets.prepare_scene_assets(request, plan, "project-test")
    second_assets, second_report = visual_assets.prepare_scene_assets(request, plan, "project-test")
    assert len(calls) == 1
    assert first_report["generated"] == 1
    assert second_report["reused"] == 1
    assert second_assets[0] == first_assets[0]


def test_image_quality_metrics_detect_flat_low_detail_image(tmp_path):
    path = tmp_path / "flat.webp"
    Image.new("RGB", (512, 512), (30, 30, 30)).save(path, "WEBP")
    metrics = visual_assets._image_quality_metrics(path)
    issues = visual_assets._image_quality_issues(metrics)
    assert "جزئیات لبه‌ای بسیار کم" in issues


def test_image_quality_retry_uses_second_generation(tmp_path, monkeypatch):
    monkeypatch.setattr(visual_assets, "ASSETS_DIR", tmp_path / "assets")
    request = VideoRequest(prompt="یک پوستر با جزئیات بصری بساز", duration=5, resolution="540p", visual_engine="nano_banana")
    plan = VideoPlan(scenes=[Scene(title="جزئیات", duration=5, image_prompt="Detailed close-up of a crafted object")])
    calls = []

    def fake_generate(engine, prompt, ratio, quality, destination, *, upscale=True, upscale_scale=2):
        calls.append(prompt)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if len(calls) == 1:
            Image.new("RGB", (512, 512), (30, 30, 30)).save(destination, "WEBP")
        else:
            _save_test_art(destination, "different")
        return {"width": 512, "height": 512, "bytes": destination.stat().st_size}

    monkeypatch.setattr(visual_assets, "_generate_one", fake_generate)
    assets, report = visual_assets.prepare_scene_assets(request, plan, "project-quality")
    assert len(calls) == 2
    assert report["quality_retry_scenes"] == [1]
    assert report["unresolved_quality_scenes"] == []
    assert report["visual_audit_passed"] is True
    assert assets[0].exists()


def test_nano_banana_request_uses_documented_query_and_optional_upscaler(tmp_path, monkeypatch):
    calls = []

    class FakeResponse:
        status_code = 200
        def __init__(self, payload):
            self.payload = payload
        def raise_for_status(self):
            return None
        def json(self):
            return self.payload

    class FakeClient:
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def get(self, url, params=None, headers=None):
            calls.append((url, dict(params or {})))
            if url == visual_assets.NESTAPI_NANO_BANANA:
                return FakeResponse({"success": True, "data": {"image_url": "https://cdn.example.test/original.webp"}})
            if url == visual_assets.NESTAPI_UPSCALE_IMAGE:
                return FakeResponse({"success": True, "data": {"image_url": "https://cdn.example.test/upscaled.webp"}})
            raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(visual_assets.httpx, "Client", lambda **kwargs: FakeClient())
    downloaded = {}
    def fake_download(url, destination):
        destination.parent.mkdir(parents=True, exist_ok=True)
        _save_test_art(destination, "different")
        downloaded["url"] = url
        return {"width": 512, "height": 512, "bytes": destination.stat().st_size}
    monkeypatch.setattr(visual_assets, "download_and_normalize_image", fake_download)

    destination = tmp_path / "scene.webp"
    info = visual_assets._generate_one(
        "nano_banana", "A cinematic image", "9:16", "high", destination,
        upscale=True, upscale_scale=3,
    )
    assert calls[0][0] == visual_assets.NESTAPI_NANO_BANANA
    assert calls[0][1] == {"prompt": "A cinematic image", "ratio": "9:16", "quality": "high"}
    assert calls[1][0] == visual_assets.NESTAPI_UPSCALE_IMAGE
    assert calls[1][1]["scale"] == "3"
    assert calls[1][1]["url"] == "https://cdn.example.test/original.webp"
    assert downloaded["url"] == "https://cdn.example.test/upscaled.webp"
    assert info["upscale_applied"] is True


def test_upscale_failure_falls_back_to_original_generated_image(tmp_path, monkeypatch):
    calls = []
    class FakeResponse:
        status_code = 200
        def raise_for_status(self):
            return None
        def json(self):
            return {"success": True, "data": {"image_url": "https://cdn.example.test/original.webp"}}
    class FakeClient:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def get(self, url, params=None, headers=None):
            calls.append(url)
            if url == visual_assets.NESTAPI_NANO_BANANA:
                return FakeResponse()
            raise RuntimeError("upscale service temporarily unavailable")
    monkeypatch.setattr(visual_assets.httpx, "Client", lambda **kwargs: FakeClient())
    downloaded = {}
    def fake_download(url, destination):
        destination.parent.mkdir(parents=True, exist_ok=True)
        _save_test_art(destination, "different")
        downloaded["url"] = url
        return {"width": 512, "height": 512, "bytes": destination.stat().st_size}
    monkeypatch.setattr(visual_assets, "download_and_normalize_image", fake_download)
    info = visual_assets._generate_one("nano_banana", "A still", "9:16", "high", tmp_path / "asset.webp")
    assert downloaded["url"] == "https://cdn.example.test/original.webp"
    assert info["upscale_applied"] is False
    assert "upscale_warning" in info


def test_perceptual_hash_and_color_histogram_distinguish_test_art(tmp_path):
    first = tmp_path / "first.webp"
    same = tmp_path / "same.webp"
    different = tmp_path / "different.webp"
    _save_test_art(first, "base")
    _save_test_art(same, "base")
    _save_test_art(different, "different")
    assert visual_assets._perceptual_hash(first) == visual_assets._perceptual_hash(same)
    assert visual_assets._near_duplicate(same, [(
        visual_assets._difference_hash(first),
        visual_assets._perceptual_hash(first),
        visual_assets._color_histogram(first),
    )])
    assert not visual_assets._near_duplicate(different, [(
        visual_assets._difference_hash(first),
        visual_assets._perceptual_hash(first),
        visual_assets._color_histogram(first),
    )])


def test_visual_coverage_gate_blocks_weak_ai_fallback_by_default(tmp_path):
    request = VideoRequest(prompt="یک ویدیو بساز درباره معماری", duration=6, visual_engine="nano_banana")
    plan = VideoPlan(scenes=[
        Scene(title="اول", duration=2, image_prompt="Shot one"),
        Scene(title="دوم", duration=2, image_prompt="Shot two"),
        Scene(title="سوم", duration=2, image_prompt="Shot three"),
    ])
    report = {"visual_audit_passed": False, "fallback_scenes": [1, 2, 3]}
    with pytest.raises(RuntimeError, match="ممیزی کیفیت اجازه رندر نداد"):
        visual_assets.enforce_visual_coverage(request, plan, {}, report)


def test_visual_coverage_gate_allows_explicit_fallback(tmp_path):
    request = VideoRequest(
        prompt="یک ویدیو بساز درباره معماری", duration=6,
        visual_engine="nano_banana", allow_procedural_fallback=True,
    )
    plan = VideoPlan(scenes=[
        Scene(title="اول", duration=2),
        Scene(title="دوم", duration=2),
        Scene(title="سوم", duration=2),
    ])
    one_asset = tmp_path / "first.webp"
    _save_test_art(one_asset, "base")
    report = {"visual_audit_passed": False, "fallback_scenes": [2, 3]}
    visual_assets.enforce_visual_coverage(request, plan, {0: one_asset}, report)
    assert report["ai_asset_coverage"] == pytest.approx(1/3, rel=1e-3)
    assert report["visual_audit_passed"] is False
    assert any("پوشش تصویر AI" in warning for warning in report["warnings"])


def test_image_generator_uses_only_documented_prompt_query(tmp_path, monkeypatch):
    calls = []
    class FakeResponse:
        status_code = 200
        def raise_for_status(self): return None
        def json(self):
            return {"success": True, "data": {"image_url": "https://cdn.example.test/generated.webp"}}
    class FakeClient:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def get(self, url, params=None, headers=None):
            calls.append((url, dict(params or {})))
            return FakeResponse()
    monkeypatch.setattr(visual_assets.httpx, "Client", lambda **kwargs: FakeClient())
    def fake_download(url, destination):
        destination.parent.mkdir(parents=True, exist_ok=True)
        _save_test_art(destination, "different")
        return {"width": 512, "height": 512, "bytes": destination.stat().st_size}
    monkeypatch.setattr(visual_assets, "download_and_normalize_image", fake_download)
    result = visual_assets._generate_one(
        "ai_image_generator", "A documentary mountain still", "16:9", "high", tmp_path / "image.webp",
        upscale=False,
    )
    assert calls == [(visual_assets.NESTAPI_IMAGE_GENERATOR, {"prompt": "A documentary mountain still"})]
    assert result["upscale_applied"] is False


def test_ensemble_runs_two_nestapi_image_engines_and_selects_best(tmp_path, monkeypatch):
    calls = []
    def fake_generate(engine, prompt, ratio, quality):
        calls.append((engine, prompt, ratio, quality))
        return f"https://cdn.example.test/{engine}.webp"

    def fake_download(url, destination):
        destination.parent.mkdir(parents=True, exist_ok=True)
        variant = "base" if "nano_banana" in url else "different"
        _save_test_art(destination, variant)
        return {"width": 512, "height": 512, "bytes": destination.stat().st_size}

    monkeypatch.setattr(visual_assets, "_request_generation", fake_generate)
    monkeypatch.setattr(visual_assets, "download_and_normalize_image", fake_download)
    destination = tmp_path / "ensemble.webp"
    report = visual_assets._generate_one(
        "ensemble", "A unique cinematic shot", "9:16", "high", destination,
        upscale=False, refine=False,
    )
    assert {item[0] for item in calls} == {"nano_banana", "ai_image_generator"}
    assert len(calls) == 2
    assert report["candidate_count"] == 2
    assert report["endpoint"] in {"nano_banana", "ai_image_generator"}
    assert all(item["status"] == "ok" for item in report["ensemble_candidates"])
    assert destination.exists()


def test_edit_image_uses_documented_url_and_prompt_parameters(monkeypatch):
    captured = {}
    class FakeResponse:
        def raise_for_status(self): return None
        def json(self): return {"success": True, "data": {"image_url": "https://cdn.example.test/edited.webp"}}
    class FakeClient:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def get(self, endpoint, params=None, headers=None):
            captured["endpoint"] = endpoint
            captured["params"] = dict(params or {})
            return FakeResponse()
    monkeypatch.setattr(visual_assets.httpx, "Client", lambda **kwargs: FakeClient())
    result = visual_assets._request_edit("https://cdn.example.test/source.webp", "Improve lighting")
    assert captured["endpoint"] == visual_assets.NESTAPI_EDIT_IMAGE
    assert captured["params"] == {"url": "https://cdn.example.test/source.webp", "prompt": "Improve lighting"}
    assert result == "https://cdn.example.test/edited.webp"
