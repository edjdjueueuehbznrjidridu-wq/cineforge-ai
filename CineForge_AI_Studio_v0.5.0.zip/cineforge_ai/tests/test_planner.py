import json

import pytest

from app.audit import audit_plan, repair_plan
from app.planner import (
    _allocate_exact,
    _extract_json,
    _normalise_plan,
    build_concept_prompt,
    build_director_prompt,
    create_plan,
    fallback_plan,
    _fallback_subject,
    _semantic_domain,
)
from app.providers import _deep_text, _gemini_complete, _nestapi_complete
from app.schemas import Scene, VideoPlan, VideoRequest


def _concept():
    return {
        "concept_title": "حرکت از آشفتگی به نظم",
        "intent": "توضیح یک سیستم پیچیده",
        "core_message": "ارتباط اجزا باعث پدید آمدن معنا می‌شود",
        "audience_tone": "کنجکاو و سینمایی",
        "original_angle": "نمایش ایده به‌صورت یک شبکه که از سکون به الگو می‌رسد",
        "visual_metaphor": "نقاط جدا که با مسیرهای زنده به یک ساختار تبدیل می‌شوند",
        "narrative_beats": ["سکون", "اتصال", "جریان", "کشف", "تعادل"],
        "palette_logic": "آبی سرد با نور گرم محدود در لحظه کشف",
        "pacing_logic": "آغاز آرام، میانه پویا، پایان با مکث",
        "avoid_list": ["نمودار عددی جعلی", "موتیف تکراری"],
        "continuity_rules": "هسته شبکه در تمام نماها باقی بماند اما شکل آن تکامل یابد",
    }


def _plan_json():
    return {
        "project_title": "شبکه‌ای که معنا می‌سازد",
        "creative_direction": "قاب‌های لایه‌ای با مسیرهای درخشان و فضای منفی وسیع",
        "narrative_arc": "از نقاط منفرد به ساختار زنده و سپس یک پایان آرام",
        "director_notes": "هر صحنه یک وظیفه روایی مستقل دارد.",
        "scenes": [
            {"title": "نقطه آغاز", "subtitle": "سکون پیش از اتصال", "kind": "intro", "duration": 3, "motion": "reveal", "motif": "radial", "composition": "center", "visual_note": "یک هسته کوچک با فضای منفی زیاد"},
            {"title": "پیوندها", "subtitle": "ارتباط اجزا آشکار می‌شود", "kind": "technology", "duration": 4, "motion": "parallax", "motif": "network", "composition": "split", "visual_note": "گره‌های نامتقارن با اتصال تدریجی"},
            {"title": "جریان", "subtitle": "مسیرها به حرکت درمی‌آیند", "kind": "process", "duration": 4, "motion": "sweep", "motif": "waveform", "composition": "diagonal", "visual_note": "نوارهای منحنی از چپ به راست حرکت می‌کنند"},
            {"title": "تعادل", "subtitle": "ساختار در یک قاب می‌نشیند", "kind": "outro", "duration": 4, "motion": "slow_zoom", "motif": "constellation", "composition": "center", "visual_note": "نقاط پراکنده به تعادل بصری می‌رسند"},
        ],
    }


def test_fallback_plan_matches_exact_duration_and_uses_semantic_subject():
    request = VideoRequest(prompt="یک ویدیوی سینمایی درباره هوش مصنوعی و شبکه‌های عصبی بساز", duration=37, use_ai=False)
    plan = fallback_plan(request)
    assert sum(scene.duration for scene in plan.scenes) == 37
    assert 3 <= len(plan.scenes) <= 24
    assert "هوش مصنوعی" in plan.project_title
    assert len({scene.motif for scene in plan.scenes}) >= 3


def test_largest_remainder_exact_allocation_many_inputs():
    for total, weights in [
        (5, [0.01, 0.01, 0.01, 0.97]),
        (17, [4, 8, 3, 2]),
        (120, [1] * 16),
        (600, [1 + (i % 5) for i in range(24)]),
    ]:
        result = _allocate_exact(total, weights)
        assert sum(result) == total
        assert len(result) == min(total, len(weights))
        assert all(value >= 1 for value in result)


def test_long_offline_plan_scales_scene_count_and_varies_visual_language():
    request = VideoRequest(prompt="A detailed documentary about the history of scientific ideas", duration=240, style="documentary", language="en", use_ai=False)
    plan, report = repair_plan(request, fallback_plan(request))
    assert sum(scene.duration for scene in plan.scenes) == 240
    assert len(plan.scenes) >= 18
    assert len({scene.motif for scene in plan.scenes}) >= 12
    assert report["metrics"]["unique_compositions"] >= 4


def test_ai_plan_durations_are_normalized_and_roles_are_intact():
    request = VideoRequest(prompt="یک فیلم درباره ایده بساز", duration=15, use_ai=False)
    plan = _normalise_plan(_plan_json(), 15, request)
    assert sum(scene.duration for scene in plan.scenes) == 15
    assert plan.scenes[0].kind == "intro"
    assert plan.scenes[-1].kind == "outro"


def test_json_extraction_and_deep_text_parse():
    content = '```json\n{"project_title":"X","scenes":[]}\n```'
    assert _extract_json(content)["project_title"] == "X"
    assert _deep_text({"success": True, "data": {"answer": "hello"}}) == "hello"
    assert _deep_text({"steps": [{"type": "model_output", "content": [{"type": "text", "text": "nested text"}]}]}) == "nested text"


def test_nestapi_uses_documented_get_contract_and_continuation(monkeypatch):
    captured = {}

    class FakeResponse:
        def raise_for_status(self):
            return None

        def json(self):
            return {"success": True, "data": {"answer": '{"ok":true}', "conversation_id": "conv-77", "id": 123}}

    class FakeClient:
        def __init__(self, **kwargs):
            captured["timeout"] = kwargs["timeout"]

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def get(self, endpoint, params):
            captured["endpoint"] = endpoint
            captured["params"] = params
            return FakeResponse()

    monkeypatch.setattr("app.providers.httpx.Client", FakeClient)
    monkeypatch.setattr("app.providers.NESTAPI_CHAT_URL", "https://example.test/apis-1/chat-ai")
    answer, context = _nestapi_complete("make a plan", "gpt4o", "en")
    assert answer == '{"ok":true}'
    assert captured["endpoint"] == "https://example.test/apis-1/chat-ai"
    assert captured["params"]["model"] == "gpt4o"
    assert captured["params"]["lang"] == "en"
    assert captured["params"]["length"] == "detail"
    assert captured["params"]["style"] == "creativity"
    assert context == {"conversation_id": "conv-77", "message_id": 123}

    _nestapi_complete("continue", "gpt4o", "fa", context)
    assert captured["params"]["conversation_id"] == "conv-77"
    assert captured["params"]["id"] == 123


def test_gemini_interactions_uses_key_header_and_previous_id(monkeypatch):
    captured = {}

    class FakeResponse:
        def raise_for_status(self):
            return None

        def json(self):
            return {"id": "v1_456", "steps": [{"type": "model_output", "content": [{"type": "text", "text": '{"ok":true}'}]}]}

    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def post(self, endpoint, headers, json):
            captured.update(endpoint=endpoint, headers=headers, body=json)
            return FakeResponse()

    monkeypatch.setattr("app.providers.httpx.Client", FakeClient)
    monkeypatch.setattr("app.providers.GEMINI_INTERACTIONS_URL", "https://example.test/v1beta/interactions")
    answer, context = _gemini_complete("plan", "gemini-3.8-flash", "test-key", {"interaction_id": "v1_previous"})
    assert answer == '{"ok":true}'
    assert captured["headers"]["x-goog-api-key"] == "test-key"
    assert captured["headers"]["Content-Type"] == "application/json"
    assert "Api-Revision" not in captured["headers"]
    assert captured["body"]["model"] == "gemini-3.8-flash"
    assert captured["body"]["previous_interaction_id"] == "v1_previous"
    assert context == {"interaction_id": "v1_456"}


def test_two_pass_ai_planner_and_saved_project_context(monkeypatch):
    import app.planner as planner_module

    calls = []
    responses = [
        (json.dumps(_concept(), ensure_ascii=False), {"conversation_id": "nest-conv", "message_id": 3}),
        (json.dumps(_plan_json(), ensure_ascii=False), {"conversation_id": "nest-conv", "message_id": 4}),
    ]

    def fake_complete_text(**kwargs):
        calls.append(kwargs)
        return responses.pop(0)

    saved = {}
    monkeypatch.setattr(planner_module, "complete_text", fake_complete_text)
    monkeypatch.setattr(planner_module, "get_project_provider_context", lambda project_id: {})
    monkeypatch.setattr(planner_module, "save_project_provider_context", lambda project_id, provider, context: saved.update(project=project_id, provider=provider, context=context))
    request = VideoRequest(prompt="یک ویدیوی دقیق درباره ایده‌ها بساز", duration=15, project_id="project-1", ai_provider="nestapi", use_ai=True)
    plan, planner, note, model, report = create_plan(request)
    assert planner == "ai"
    assert model == "gpt5"
    assert len(calls) == 2
    assert "concept" in calls[1]["prompt"].lower()
    assert calls[1]["context"]["conversation_id"] == "nest-conv"
    assert saved == {"project": "project-1", "provider": "nestapi", "context": {"conversation_id": "nest-conv", "message_id": 4}}
    assert sum(scene.duration for scene in plan.scenes) == 15
    assert report["passed"] is True


def test_ai_provider_failure_falls_back_without_breaking_planning(monkeypatch):
    import app.planner as planner_module

    def broken(**kwargs):
        raise RuntimeError("temporary network failure")

    monkeypatch.setattr(planner_module, "complete_text", broken)
    monkeypatch.setattr(planner_module, "get_project_provider_context", lambda project_id: {})
    request = VideoRequest(prompt="یک ویدیوی سینمایی درباره ایده‌ها بساز", duration=12, use_ai=True)
    plan, provider, note, model, report = create_plan(request)
    assert provider == "fallback"
    assert sum(scene.duration for scene in plan.scenes) == 12
    assert "جایگزین شد" in note
    assert model is None
    assert report["passed"] is True


def test_audit_and_repair_reduce_repeated_visual_patterns():
    request = VideoRequest(prompt="یک موشن گرافیک بساز", duration=20, use_ai=False)
    plan = VideoPlan(scenes=[
        Scene(title="A", duration=5, kind="intro", motion="pan", motif="network", composition="center", visual_note="same repeated scene note"),
        Scene(title="B", duration=5, motion="pan", motif="network", composition="center", visual_note="same repeated scene note"),
        Scene(title="C", duration=5, motion="pan", motif="network", composition="center", visual_note="same repeated scene note"),
        Scene(title="D", duration=5, kind="outro", motion="pan", motif="network", composition="center", visual_note="same repeated scene note"),
    ])
    repaired, report = repair_plan(request, plan)
    assert sum(s.duration for s in repaired.scenes) == 20
    assert len({s.motif for s in repaired.scenes}) == 4
    assert len({s.motion for s in repaired.scenes}) == 4
    assert report["metrics"]["unique_compositions"] >= 3


def test_director_prompt_uses_previous_project_and_edit_instruction():
    request = VideoRequest(prompt="ویرایش پروژه قبلی", duration=15)
    previous = {"project_title": "Old", "scenes": [{"title": "Original"}]}
    prompt = build_director_prompt(request, previous, "فقط پایان را خلوت‌تر کن", [{"role": "user", "content": "نسخه اول"}])
    assert "Original" in prompt
    assert "فقط پایان را خلوت‌تر کن" in prompt
    assert "نسخه اول" in prompt


def test_render_budget_rejects_without_silent_quality_downgrade():
    with pytest.raises(ValueError):
        VideoRequest(prompt="long video", duration=180, resolution="1080p", fps=30)
    accepted = VideoRequest(prompt="long video", duration=600, resolution="540p", fps=24)
    assert accepted.duration == 600


def test_fallback_subject_and_domain_do_not_misclassify_substrings():
    assert _fallback_subject("یک فیلم درباره تبدیل ایده خام به ساختار زنده؛ با خطوط نور و پایان آرام") == "تبدیل ایده خام به ساختار زنده"
    assert _semantic_domain("هندسه نامتقارن و حرکت نرم") == "abstract"
    assert _semantic_domain("شبکه عصبی و هوش مصنوعی") == "technology"
    assert _semantic_domain("جنگل و اقیانوس") == "nature"


def test_multi_agent_planner_merges_parallel_specialist_deliverables(monkeypatch):
    import app.planner as planner_module

    agent_calls = []
    def fake_ensemble(**kwargs):
        agent_calls.append(kwargs)
        return [
            {"role": "STORY ARCHITECT", "model": "gpt5", "deliverable": "Build a discovery arc with a strong reveal."},
            {"role": "CINEMATOGRAPHY & ART DIRECTOR", "model": "claude45", "deliverable": "Use macro material details, aerial scale and warm backlight."},
            {"role": "EDITOR & SOUND DESIGNER", "model": "gemini3", "deliverable": "Start sparse, rise to a pulse, resolve with a warm chord."},
        ]

    calls = []
    concept = _concept()
    storyboard = _plan_json()
    storyboard.update({
        "music_mood": "hopeful",
        "music_tempo_bpm": 104,
        "music_direction": "Warm piano-like pad with light pulse and a gradual lift.",
        "music_energy_curve": [0.2, 0.4, 0.9, 0.35],
        "sound_events": [{"time_seconds": 6, "kind": "soft_hit", "intensity": 0.3, "duration": 0.5, "pan": 0.2}],
    })
    responses = [
        (json.dumps(concept, ensure_ascii=False), {"conversation_id": "multi-1", "message_id": 1}),
        (json.dumps(storyboard, ensure_ascii=False), {"conversation_id": "multi-1", "message_id": 2}),
    ]
    def fake_complete_text(**kwargs):
        calls.append(kwargs)
        return responses.pop(0)

    monkeypatch.setattr(planner_module, "complete_nestapi_ensemble", fake_ensemble)
    monkeypatch.setattr(planner_module, "complete_text", fake_complete_text)
    monkeypatch.setattr(planner_module, "get_project_provider_context", lambda project_id: {})
    request = VideoRequest(
        prompt="یک ویدیوی امیدبخش و سینمایی درباره ساخت آینده بساز",
        duration=15, ai_provider="nestapi", multi_agent=True, use_ai=True,
    )
    plan, planner, note, model, report = create_plan(request)
    assert planner == "ai"
    assert len(agent_calls) == 1
    assert len(calls) == 2
    assert "STORY ARCHITECT" in calls[0]["prompt"]
    assert "CINEMATOGRAPHY" in calls[1]["prompt"]
    assert "EDITOR & SOUND DESIGNER" in calls[1]["prompt"]
    assert plan.music_mood == "hopeful"
    assert plan.music_tempo_bpm == 104
    assert len(plan.music_energy_curve) == 4
    assert plan.sound_events[0].kind == "soft_hit"
    assert sum(scene.duration for scene in plan.scenes) == 15
    assert report["passed"] is True


def test_normalise_plan_ignores_null_optional_audio_arrays():
    data = _plan_json()
    data["music_energy_curve"] = None
    data["sound_events"] = None
    request = VideoRequest(prompt="یک ویدیوی کوتاه درباره ایده بساز", duration=15, use_ai=False)
    plan = _normalise_plan(data, 15, request)
    assert plan.music_energy_curve == []
    assert plan.sound_events == []


def test_music_tempo_validation_requires_auto_or_musical_range():
    from pydantic import ValidationError
    import pytest

    with pytest.raises(ValidationError):
        VideoPlan(scenes=[{"duration": 5}], music_tempo_bpm=40)


def test_gemini_ensemble_runs_three_specialists_in_parallel(monkeypatch):
    import threading
    import time
    from app.providers import complete_gemini_ensemble

    barrier = threading.Barrier(3)
    calls = []
    lock = threading.Lock()

    def fake_gemini(prompt, model, api_key, context=None):
        barrier.wait(timeout=3)
        with lock:
            calls.append((prompt, model, api_key, context))
        role = next((name for name in ("STORY ARCHITECT", "CINEMATOGRAPHY & ART DIRECTOR", "EDITOR & SOUND DESIGNER") if name in prompt), "unknown")
        return f"deliverable:{role}", {"interaction_id": None}

    monkeypatch.setattr("app.providers._gemini_complete", fake_gemini)
    result = complete_gemini_ensemble("A distinct film brief", "gemini-3.8-flash", "secret-key")
    assert len(result) == 3
    assert len(calls) == 3
    assert {item["role"] for item in result} == {
        "STORY ARCHITECT", "CINEMATOGRAPHY & ART DIRECTOR", "EDITOR & SOUND DESIGNER"
    }
    assert all(item["model"] == "gemini-3.8-flash" for item in result)
    assert all(call[1] == "gemini-3.8-flash" and call[2] == "secret-key" and call[3] is None for call in calls)


def test_nestapi_ensemble_runs_three_independent_models_in_parallel(monkeypatch):
    import threading
    from app.providers import complete_nestapi_ensemble

    barrier = threading.Barrier(3)
    calls = []
    lock = threading.Lock()

    def fake_nestapi(prompt, model, language, context=None):
        barrier.wait(timeout=3)
        with lock:
            calls.append((model, language, context, prompt))
        return f"deliverable:{model}", {}

    monkeypatch.setattr("app.providers._nestapi_complete", fake_nestapi)
    result = complete_nestapi_ensemble("A unique documentary brief", language="fa")
    assert len(result) == 3
    assert {item["model"] for item in result} == {"gpt5", "claude45", "gemini3"}
    assert len(calls) == 3
    assert all(language == "fa" and context is None for _, language, context, _ in calls)
    assert all("PROJECT BRIEF AND CONSTRAINTS" in prompt for *_, prompt in calls)


def test_fallback_persian_titles_do_not_mix_long_latin_brief_text():
    request = VideoRequest(
        prompt="A cinematic short film about a quiet idea becoming a living constellation",
        duration=12, language="fa", use_ai=False,
    )
    plan = fallback_plan(request)
    assert all(not any("a" <= ch.lower() <= "z" for ch in scene.title) for scene in plan.scenes)
