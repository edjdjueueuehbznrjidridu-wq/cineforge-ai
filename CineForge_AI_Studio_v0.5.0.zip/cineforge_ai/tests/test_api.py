from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health_and_supported_models():
    response = client.get("/api/health")
    assert response.status_code == 200
    body = response.json()
    assert body["ok"] is True
    assert "nestapi" in body["providers"]
    assert "gemini" in body["providers"]
    assert body["persistent_memory"] is True


def test_plan_fallback_creates_persistent_project():
    response = client.post("/api/plan", json={
        "prompt": "یک ویدیوی سینمایی درباره تکنولوژی بساز",
        "duration": 15,
        "use_ai": False,
    })
    assert response.status_code == 200
    body = response.json()
    assert body["planner"] == "fallback"
    assert body["project_id"]
    assert sum(scene["duration"] for scene in body["plan"]["scenes"]) == 15
    project = client.get(f"/api/projects/{body['project_id']}")
    assert project.status_code == 200
    assert project.json()["plan"]["project_title"] == body["plan"]["project_title"]


def test_extended_customization_is_accepted():
    response = client.post("/api/plan", json={
        "prompt": "یک ویدیوی رویایی درباره طبیعت بساز",
        "duration": 10,
        "resolution": "1080p",
        "style": "dream",
        "accent_palette": "violet",
        "motion_intensity": "high",
        "text_density": "rich",
        "music_style": "mellow",
        "music_volume": 18,
        "render_quality": "high",
        "use_ai": False,
    })
    assert response.status_code == 200
    assert response.json()["plan"]["scenes"]


def test_invalid_custom_color_is_rejected():
    response = client.post("/api/plan", json={
        "prompt": "یک ویدیوی خوب بساز",
        "accent_color": "not-a-color",
        "use_ai": False,
    })
    assert response.status_code == 422


def test_render_pixel_budget_rejects_extreme_combination():
    response = client.post("/api/plan", json={
        "prompt": "یک ویدیوی طولانی با کیفیت بالا بساز",
        "duration": 180,
        "resolution": "1080p",
        "fps": 30,
        "use_ai": False,
    })
    assert response.status_code == 422


def test_job_status_exposes_poster_and_hides_server_paths():
    from app import main

    job_id = "abcdef123456"
    main._jobs[job_id] = {
        "job_id": job_id, "status": "completed", "progress": 100, "message": "ready",
        "download_url": f"/api/jobs/{job_id}/download", "error": None, "plan": None,
        "planner": "fallback", "note": "test",
        "metadata": {"path": "/server/private/output.mp4", "poster_path": "/server/private/output.jpg", "width": 540, "height": 960, "fps": 24, "duration": 5, "bytes": 1024},
    }
    try:
        response = client.get(f"/api/jobs/{job_id}")
        assert response.status_code == 200
        body = response.json()
        assert body["poster_url"] == f"/api/jobs/{job_id}/poster"
        assert body["metadata"]["width"] == 540
        assert "path" not in body["metadata"]
        assert "poster_path" not in body["metadata"]
    finally:
        main._jobs.pop(job_id, None)


def test_job_playback_and_download_are_separate(tmp_path):
    from app import main

    job_id = "1234abcdef56"
    output = main.OUTPUT_DIR / f"{job_id}.mp4"
    output.write_bytes(b"cineforge-test-video")
    main._jobs[job_id] = {
        "job_id": job_id, "status": "completed", "progress": 100, "message": "ready",
        "download_url": f"/api/jobs/{job_id}/download", "error": None, "plan": None,
        "planner": "fallback", "note": None, "metadata": {"path": str(output), "bytes": output.stat().st_size},
    }
    try:
        status = client.get(f"/api/jobs/{job_id}").json()
        assert status["video_url"] == f"/api/jobs/{job_id}/play"
        playback = client.get(status["video_url"])
        assert playback.status_code == 200
        assert "inline" in playback.headers.get("content-disposition", "")
        download = client.get(status["download_url"])
        assert "attachment" in download.headers.get("content-disposition", "")
    finally:
        main._jobs.pop(job_id, None)
        output.unlink(missing_ok=True)


def test_project_delete_cascades_memory():
    created = client.post("/api/plan", json={
        "prompt": "یک ویدیو درباره طبیعت بساز", "duration": 10, "use_ai": False,
    }).json()
    project_id = created["project_id"]
    assert client.delete(f"/api/projects/{project_id}").status_code == 200
    assert client.get(f"/api/projects/{project_id}").status_code == 404


def test_conversational_edits_do_not_accumulate_into_base_prompt(monkeypatch):
    from app import main
    from app.audit import repair_plan
    from app.planner import fallback_plan

    captured = []

    def fake_create_plan(request, previous_plan=None, edit_instruction=None, recent_messages=None):
        captured.append({"prompt": request.prompt, "edit": edit_instruction, "previous": previous_plan})
        plan, report = repair_plan(request, fallback_plan(request))
        return plan, "fallback", "test planner", None, report

    monkeypatch.setattr(main, "create_plan", fake_create_plan)
    base = "یک ویدیوی سینمایی درباره شکل‌گیری یک ایده بساز"
    created = client.post("/api/plan", json={"prompt": base, "duration": 12, "use_ai": False}).json()
    project_id = created["project_id"]

    first = client.post(f"/api/projects/{project_id}/edit", json={"instruction": "پایان را گرم‌تر و آرام‌تر کن"})
    second = client.post(f"/api/projects/{project_id}/edit", json={"instruction": "صحنه دوم را خلوت‌تر کن"})
    assert first.status_code == second.status_code == 200
    assert [entry["prompt"] for entry in captured] == [base, base, base]
    assert captured[1]["edit"] == "پایان را گرم‌تر و آرام‌تر کن"
    assert captured[2]["edit"] == "صحنه دوم را خلوت‌تر کن"
    detail = client.get(f"/api/projects/{project_id}").json()
    assert detail["request"]["prompt"] == base
    assert detail["version_number"] == 0


def test_gemini_key_is_encrypted_at_rest_and_never_returned(tmp_path, monkeypatch):
    import json
    import sqlite3
    from app import storage

    monkeypatch.setattr(storage, "DATA_DIR", tmp_path)
    monkeypatch.setattr(storage, "DB_PATH", tmp_path / "test-cineforge.sqlite3")
    monkeypatch.setattr(storage, "_fernet", None)
    storage.init_storage()

    secret = "AIzaSy-CineForge-Test-Only-Secret"
    saved = client.post("/api/settings/ai", json={
        "provider": "gemini",
        "nestapi_model": "gpt5",
        "gemini_model": "gemini-3.8-flash",
        "gemini_api_key": secret,
    })
    assert saved.status_code == 200
    assert secret not in saved.text

    fetched = client.get("/api/settings/ai")
    assert fetched.status_code == 200
    assert fetched.json()["gemini_configured"] is True
    assert fetched.json()["key_masked"]
    assert secret not in fetched.text

    with sqlite3.connect(storage.DB_PATH) as db:
        encoded = db.execute("SELECT value FROM settings WHERE key='gemini_key_enc'").fetchone()[0]
    assert secret not in encoded
    assert storage.get_provider_settings()["gemini_api_key"] == secret
    assert (tmp_path / ".secret.key").exists()


def test_health_lists_current_gemini_model_ids():
    body = client.get("/api/health").json()
    suggested = body["providers"]["gemini"]["current_suggested"]
    assert "gemini-4-hydrogen" in suggested
    assert "gemini-3.8-flash" in suggested
    assert "gemini-3.1-pro-preview" in suggested
    assert "gemini-3.1-pro" not in suggested


def test_health_advertises_per_scene_image_and_upscale_pipeline():
    body = client.get("/api/health").json()
    assert body["per_scene_keyframes"] is True
    assert body["image_upscaler"]["provider"] == "nestapi"
    assert body["image_upscaler"]["scales"] == [2, 3, 4]
    assert "phash_dct" in body["visual_similarity_audit"]["algorithms"]


def test_upscale_settings_are_validated_and_returned_by_plan_request():
    response = client.post("/api/plan", json={
        "prompt": "یک فیلم کوتاه درباره معماری و نور بساز",
        "duration": 8,
        "use_ai": False,
        "upscale_images": True,
        "upscale_scale": 4,
    })
    assert response.status_code == 200
    # The project request is persisted separately; plan response remains a plan envelope.
    project_id = response.json()["project_id"]
    details = client.get(f"/api/projects/{project_id}").json()
    assert details["request"]["upscale_images"] is True
    assert details["request"]["upscale_scale"] == 4


def test_audio_voice_catalogue_route_returns_live_voice_choices(monkeypatch):
    from app import audio

    monkeypatch.setattr(audio, "fetch_nestapi_voices", lambda locale="fa", gender=None: [
        {"id": "fa-IR-DilaraNeural", "label": "Dilara", "locale": "fa-IR", "gender": "Female"}
    ])
    response = client.get("/api/audio/voices?locale=fa")
    assert response.status_code == 200
    body = response.json()
    assert body["provider"] == "nestapi"
    assert body["count"] == 1
    assert body["voices"][0]["id"] == "fa-IR-DilaraNeural"
