import shutil
from pathlib import Path

import numpy as np
from PIL import Image
import pytest

from app.audio import create_ambient_track
from app.renderer import _draw_frame, render_video
from app.schemas import Scene, VideoPlan, VideoRequest


def test_frame_has_expected_shape_and_dtype():
    request = VideoRequest(
        prompt="یک ویدیوی کوتاه بساز",
        duration=5,
        resolution="540p",
        use_ai=False,
    )
    plan = VideoPlan(scenes=[
        Scene(title="شروع", subtitle="", kind="intro", duration=2, motion="reveal"),
        Scene(title="پایان", subtitle="", kind="outro", duration=3, motion="slow_zoom"),
    ])
    width, height = request.dimensions()
    frame = _draw_frame(width, height, 0, request.fps, request, plan)
    assert frame.shape == (height, width, 3)
    assert frame.dtype == np.uint8


def test_audio_track_length_and_silence_option(tmp_path):
    output = tmp_path / "silent.wav"
    create_ambient_track(output, duration=1, style="none", volume=0, sample_rate=8000)
    assert output.exists()
    assert output.stat().st_size > 40


@pytest.mark.skipif(shutil.which("ffmpeg") is None, reason="FFmpeg is not installed")
def test_render_produces_mp4(tmp_path):
    request = VideoRequest(
        prompt="یک ویدیوی آزمایشی کوتاه بساز",
        duration=5,
        fps=24,
        resolution="540p",
        use_ai=False,
        music_style="mellow",
        render_quality="fast",
    )
    plan = VideoPlan(scenes=[
        Scene(title="شروع آزمایش", subtitle="آغاز", kind="intro", duration=2, motion="reveal"),
        Scene(title="پایان آزمایش", subtitle="پایان", kind="outro", duration=3, motion="slow_zoom"),
    ])
    output = tmp_path / "test.mp4"
    metadata = render_video(request, plan, output)
    assert output.exists()
    assert metadata["frames"] == 120
    assert metadata["width"] == 540
    assert metadata["height"] == 960
    assert output.stat().st_size > 1000
    assert Path(metadata["poster_path"]).exists()
    assert metadata["probe"].get("video_codec") in {"h264", None}
    assert metadata["probe"].get("audio_codec") in {"aac", None}


@pytest.mark.parametrize("style", [
    "cinematic", "minimal", "documentary", "motion", "cyberpunk",
    "retro", "luxury", "nature", "corporate", "dream",
])
def test_all_visual_styles_render_a_frame(style):
    request = VideoRequest(
        prompt="یک نمونه بصری اختصاصی بساز",
        duration=5,
        style=style,
        resolution="540p",
        use_ai=False,
    )
    plan = VideoPlan(scenes=[
        Scene(title="نمونه", subtitle="آزمایش سبک", kind="intro", duration=5, motion="orbit"),
    ])
    frame = _draw_frame(180, 320, 24, request.fps, request, plan)
    assert frame.shape == (320, 180, 3)
    assert frame.dtype == np.uint8


@pytest.mark.parametrize("motion", [
    "slow_zoom", "pan", "pulse", "reveal", "drift", "orbit", "rise", "parallax",
    "float", "sweep", "ken_burns", "elastic",
])
def test_all_motion_presets_render_frames(motion):
    request = VideoRequest(
        prompt="آزمون حرکت صحنه",
        duration=5,
        resolution="540p",
        use_ai=False,
    )
    plan = VideoPlan(scenes=[
        Scene(title="حرکت", duration=5, kind="technology", motion=motion),
    ])
    first = _draw_frame(180, 320, 12, request.fps, request, plan)
    later = _draw_frame(180, 320, 72, request.fps, request, plan)
    assert first.shape == later.shape == (320, 180, 3)


@pytest.mark.parametrize("transition", ["dissolve", "slide", "wipe", "lightleak"])
def test_transition_variants_render_valid_frames(transition):
    request = VideoRequest(prompt="آزمون انتقال بین صحنه‌های متنوع", duration=6, resolution="540p", use_ai=False)
    plan = VideoPlan(scenes=[
        Scene(title="آغاز", kind="intro", duration=3, motion="reveal", motif="radial", transition="cut"),
        Scene(title="ادامه", kind="outro", duration=3, motion="pan", motif="network", transition=transition, composition="diagonal"),
    ])
    frame = _draw_frame(180, 320, 3 * request.fps + 2, request.fps, request, plan)
    assert frame.shape == (320, 180, 3)
    assert frame.dtype == np.uint8
    assert int(frame.std()) > 0


def test_ai_keyframe_images_drive_different_scene_backgrounds(tmp_path):
    request = VideoRequest(
        prompt="یک ویدیوی معماری با دو نمای متفاوت",
        duration=6,
        fps=24,
        resolution="540p",
        visual_engine="nano_banana",
        render_quality="fast",
        show_grid=False,
        show_particles=False,
    )
    plan = VideoPlan(scenes=[
        Scene(title="نمای گرم", duration=3, motion="slow_zoom", composition="left", image_prompt="warm architecture"),
        Scene(title="نمای سرد", duration=3, motion="pan", composition="right", image_prompt="cold architecture"),
    ])
    warm = Image.new("RGB", (640, 960), (168, 62, 28))
    cold = Image.new("RGB", (640, 960), (20, 76, 160))
    warm_path = tmp_path / "warm.webp"
    cold_path = tmp_path / "cold.webp"
    warm.save(warm_path, "WEBP")
    cold.save(cold_path, "WEBP")
    first = _draw_frame(180, 320, 24, 24, request, plan, {0: warm, 1: cold})
    second = _draw_frame(180, 320, 24 * 4, 24, request, plan, {0: warm, 1: cold})
    first_mean = first.mean(axis=(0, 1))
    second_mean = second.mean(axis=(0, 1))
    assert np.linalg.norm(first_mean - second_mean) > 35


@pytest.mark.skipif(shutil.which("ffmpeg") is None, reason="FFmpeg is not installed")
def test_ai_keyframe_assets_render_to_audited_mp4(tmp_path):
    request = VideoRequest(
        prompt="یک فیلم درباره سازه و طبیعت بساز",
        duration=5,
        fps=24,
        resolution="540p",
        visual_engine="nano_banana",
        music_style="mellow",
        render_quality="fast",
        show_grid=False,
    )
    plan = VideoPlan(scenes=[
        Scene(title="سازه", kind="intro", duration=2, motion="slow_zoom", composition="left"),
        Scene(title="طبیعت", kind="outro", duration=3, motion="pan", composition="right"),
    ])
    first = Image.new("RGB", (720, 1280), (146, 62, 35))
    first_draw = __import__("PIL.ImageDraw", fromlist=["ImageDraw"]).Draw(first)
    first_draw.polygon([(80, 1150), (360, 160), (640, 1150)], fill=(225, 174, 92))
    second = Image.new("RGB", (720, 1280), (24, 92, 76))
    second_draw = __import__("PIL.ImageDraw", fromlist=["ImageDraw"]).Draw(second)
    second_draw.ellipse((80, 230, 650, 960), fill=(118, 192, 134))
    first_path, second_path = tmp_path / "first.webp", tmp_path / "second.webp"
    first.save(first_path, "WEBP")
    second.save(second_path, "WEBP")
    report = {"requested_engine": "nano_banana", "generated": 2, "fallback_scenes": [], "warnings": []}
    output = tmp_path / "ai-keyframes.mp4"
    metadata = render_video(request, plan, output, scene_assets={0: first_path, 1: second_path}, asset_report=report)
    assert output.exists() and output.stat().st_size > 1000
    assert metadata["visual_engine_used"] == "ai_keyframes"
    assert metadata["ai_keyframes_loaded"] == 2
    assert metadata["quality_report"]["passed"] is True
    assert metadata["probe"]["frame_count"] == 120


def test_layered_music_is_stereo_dynamic_and_peak_safe(tmp_path):
    import wave

    from app.audio import create_ambient_track

    output = tmp_path / "directed-score.wav"
    report = create_ambient_track(
        output,
        duration=2,
        style="cinematic",
        volume=32,
        sample_rate=8000,
        block_seconds=1,
        tempo=104,
        seed=77,
        energy_curve=[0.15, 0.45, 0.95, 0.35],
        sound_events=[
            {"time_seconds": 0.65, "kind": "whoosh", "intensity": 0.5, "duration": 0.7, "pan": -0.4},
            {"time_seconds": 1.35, "kind": "soft_hit", "intensity": 0.35, "duration": 0.4, "pan": 0.3},
        ],
    )
    with wave.open(str(output), "rb") as wav:
        assert wav.getnchannels() == 2
        assert wav.getframerate() == 8000
        assert wav.getnframes() == 16000
        samples = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2").reshape(-1, 2)
    assert np.max(np.abs(samples.astype(np.int32))) <= 32767
    assert np.sqrt(np.mean(samples.astype(np.float64) ** 2)) > 10
    assert report["bpm"] == 104
    assert report["sound_events"] == 2
    assert report["energy_curve_points"] == 4
    assert report["peak_safe"] is True


def test_music_silence_mode_remains_bit_silent_even_with_events(tmp_path):
    import wave

    output = tmp_path / "silent-with-events.wav"
    create_ambient_track(
        output, duration=1, style="none", volume=0, sample_rate=8000,
        sound_events=[{"time_seconds": 0.2, "kind": "impact", "intensity": 1.0}],
    )
    with wave.open(str(output), "rb") as wav:
        samples = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2")
    assert samples.size == 16000
    assert np.count_nonzero(samples) == 0


def test_music_mood_inference_uses_request_semantics():
    from app.audio import infer_music_style

    assert infer_music_style("روایت مرموز و تاریک از یک شهر متروکه", "auto") == "dark"
    assert infer_music_style("یک فیلم درباره موفقیت و آینده", "auto") == "hopeful"
    assert infer_music_style("یک مستند آموزشی با لحن خنثی", "auto") == "documentary"
    assert infer_music_style("هر متنی", "cinematic") == "cinematic"


def test_nestapi_voice_catalogue_uses_documented_voices_action(monkeypatch):
    from app.audio import fetch_nestapi_voices

    captured = {}

    class FakeResponse:
        def raise_for_status(self):
            return None

        def json(self):
            return {
                "success": True,
                "data": {
                    "voices": [
                        {"ShortName": "fa-IR-DilaraNeural", "FriendlyName": "Dilara", "Locale": "fa-IR", "Gender": "Female"},
                        {"ShortName": "fa-IR-FaridNeural", "FriendlyName": "Farid", "Locale": "fa-IR", "Gender": "Male"},
                    ]
                },
            }

    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def get(self, endpoint, params, headers):
            captured.update(endpoint=endpoint, params=params, headers=headers)
            return FakeResponse()

    monkeypatch.setattr("app.audio.httpx.Client", FakeClient)
    voices = fetch_nestapi_voices(locale="fa", gender="Female")
    assert captured["endpoint"].endswith("/apis-1/text-to-speech")
    assert captured["params"] == {"action": "voices", "locale": "fa", "gender": "Female"}
    assert voices == [{"id": "fa-IR-DilaraNeural", "label": "Dilara", "locale": "fa-IR", "gender": "Female"}, {"id": "fa-IR-FaridNeural", "label": "Farid", "locale": "fa-IR", "gender": "Male"}]


def test_mixed_persian_latin_title_uses_font_with_both_script_sets():
    from app.renderer import _font, _wrap_title

    font = _font(28, bold=True, arabic=True, mixed=True)
    assert getattr(font, "path", "").endswith("DejaVuSans-Bold.ttf")
    image = Image.new("RGB", (500, 180), (5, 10, 20))
    draw = __import__("PIL.ImageDraw", fromlist=["ImageDraw"]).Draw(image)
    shaped, selected = _wrap_title(draw, "جرقه بصری: A cinematic idea", 470, 32)
    draw.multiline_text((8, 8), shaped, font=selected, fill=(255, 255, 255))
    assert image.getbbox() is not None
