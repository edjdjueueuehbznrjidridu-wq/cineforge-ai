from __future__ import annotations

import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from pydantic import ValidationError

from app.config import OUTPUT_DIR
from app.planner import create_plan
from app.renderer import render_video
from app.visual_assets import enforce_visual_coverage, prepare_scene_assets
from app.schemas import VideoRequest
from app.storage import get_provider_settings, save_provider_settings


def env_choice(name: str, allowed: set[str], default: str) -> str:
    value = os.getenv(name, default).strip().lower()
    return value if value in allowed else default


def env_int(name: str, default: int, allowed: set[int]) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError as exc:
        raise SystemExit(f"{name} must be an integer") from exc
    if value not in allowed:
        raise SystemExit(f"{name} must be one of {sorted(allowed)}")
    return value


prompt = os.getenv("DEMO_PROMPT", "A cinematic motion graphics film about ideas and technology").strip()
try:
    duration = int(os.getenv("DEMO_DURATION", "20"))
except ValueError as exc:
    raise SystemExit("DEMO_DURATION must be an integer") from exc
if not 5 <= duration <= 600:
    raise SystemExit("DEMO_DURATION must be between 5 and 600 seconds")

style = env_choice("DEMO_STYLE", {"cinematic", "minimal", "documentary", "motion", "cyberpunk", "retro", "luxury", "nature", "corporate", "dream"}, "cinematic")
resolution = env_choice("DEMO_RESOLUTION", {"540p", "720p", "1080p"}, "720p")
provider = env_choice("DEMO_PROVIDER", {"nestapi", "gemini", "local"}, "nestapi")
model = os.getenv("DEMO_AI_MODEL", "gpt5" if provider == "nestapi" else "gemini-3.8-flash").strip()
if not model or len(model) > 100:
    raise SystemExit("DEMO_AI_MODEL must contain a valid model identifier")
fps = env_int("DEMO_FPS", 24, {24, 30, 60})
aspect = env_choice("DEMO_ASPECT", {"9:16", "16:9", "1:1"}, "9:16")
quality = env_choice("DEMO_QUALITY", {"fast", "balanced", "high", "ultra"}, "balanced")
music = env_choice("DEMO_MUSIC", {"auto", "none", "mellow", "cinematic", "pulse", "ambient", "hopeful", "dark", "epic", "focus", "playful", "tension", "dreamy", "emotional", "electronic", "documentary"}, "auto")
music_volume = env_int("DEMO_MUSIC_VOLUME", 22, set(range(0, 41)))
visual_engine = env_choice("DEMO_VISUAL_ENGINE", {"ensemble", "nano_banana", "ai_image_generator", "procedural"}, "procedural")
image_quality = env_choice("DEMO_IMAGE_QUALITY", {"standard", "high"}, "high")
upscale_images = os.getenv("DEMO_UPSCALE_IMAGES", "true").strip().lower() in {"1", "true", "yes", "on"}
upscale_scale = env_int("DEMO_UPSCALE_SCALE", 2, {2, 3, 4})

# Workflow secrets are injected only into the runner process. They are never written to source.
gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
if gemini_key:
    settings = get_provider_settings()
    save_provider_settings(
        provider="gemini" if provider == "gemini" else settings["provider"],
        nestapi_model=settings["nestapi_model"],
        gemini_model=model if provider == "gemini" else settings["gemini_model"],
        api_key=gemini_key,
    )

try:
    request = VideoRequest(
        prompt=prompt,
        duration=duration,
        fps=fps,
        aspect_ratio=aspect,
        resolution=resolution,
        style=style,
        ai_provider=provider,
        ai_model=model,
        use_ai=provider != "local",
        music_style=music,
        music_volume=music_volume,
        multi_agent=os.getenv("DEMO_MULTI_AGENT", "true").strip().lower() in {"1", "true", "yes", "on"},
        refine_images=os.getenv("DEMO_REFINE_IMAGES", "false").strip().lower() in {"1", "true", "yes", "on"},
        music_tempo=int(os.getenv("DEMO_MUSIC_TEMPO", "0") or 0),
        voiceover_text=os.getenv("DEMO_VOICEOVER_TEXT", "").strip(),
        voiceover_voice=os.getenv("DEMO_VOICEOVER_VOICE", "auto").strip() or "auto",
        render_quality=quality,
        visual_engine=visual_engine,
        image_quality=image_quality,
        upscale_images=upscale_images,
        upscale_scale=upscale_scale,
        allow_procedural_fallback=os.getenv("DEMO_ALLOW_PROCEDURAL_FALLBACK", "false").strip().lower() in {"1", "true", "yes", "on"},
    )
except ValidationError as exc:
    errors = exc.errors()
    detail = errors[0].get("msg", "Invalid render settings") if errors else str(exc)
    raise SystemExit(
        "این ترکیب مدت، FPS و رزولوشن از بودجه امن رندر بیشتر است. "
        "کیفیت به‌صورت خودکار کاهش داده نمی‌شود؛ رزولوشن/FPS را کم کن یا ویدیو را بخش‌بندی کن.\n" + detail
    ) from exc

plan, planner, note, used_model, plan_audit = create_plan(request)
plan_path = OUTPUT_DIR / "cineforge-demo-plan.json"
plan_path.write_text(plan.model_dump_json(indent=2), encoding="utf-8")
output = OUTPUT_DIR / "cineforge-demo.mp4"
scene_assets, asset_report = prepare_scene_assets(
    request, plan, "github-demo",
    lambda done, total, message: print(f"ASSETS {done}/{total} - {message}"),
) if visual_engine != "procedural" else ({}, {"requested_engine": "procedural", "generated": 0, "reused": 0, "fallback_scenes": [], "warnings": []})
if visual_engine != "procedural":
    enforce_visual_coverage(request, plan, scene_assets, asset_report)
metadata = render_video(
    request, plan, output, lambda p, m: print(f"{p}% - {m}"),
    scene_assets=scene_assets, asset_report=asset_report,
)
print(f"Planner: {planner} | Provider: {provider} | Model: {used_model or 'local fallback'}")
print(f"Plan audit: {plan_audit.get('issue_count', 0)} issue(s), {plan_audit.get('warning_count', 0)} warning(s)")
print(f"Output: {output} | {metadata['bytes']} bytes | {metadata['width']}x{metadata['height']} | {metadata['duration']}s")
print(f"Visual assets: {asset_report}")
print(f"Render audit: {metadata.get('quality_report', {})}")
