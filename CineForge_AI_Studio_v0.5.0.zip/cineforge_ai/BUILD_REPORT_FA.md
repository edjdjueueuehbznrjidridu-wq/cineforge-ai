# گزارش ساخت و ممیزی CineForge AI Studio 0.5.0

## خلاصه نسخه

- نسخه: `0.5.0`
- رابط: PWA فارسی و راست‌به‌چپ با استوری‌بورد، کتابخانه پروژه‌ها، تنظیمات مدل و کنترل‌های صوتی
- Backend: FastAPI / Python
- تصویر: NestAPI Nano Banana + AI Image Generator در حالت Ensemble؛ Edit Image و Upscale اختیاری
- متن: NestAPI Chat AI یا Google Gemini Interactions
- تیم تخصصی: سه عامل موازی (روایت، تصویر/فیلم‌برداری، تدوین/صدا) و سپس کارگردان نهایی
- صوت: موسیقی procedural چندلایه استریو، رخدادهای صوتی زمان‌بندی‌شده، نریشن NestAPI TTS
- خروجی: FFmpeg H.264 / AAC، yuv420p، پوستر و ممیزی FFprobe
- حافظه: SQLite برای پروژه، نسخه‌ها، پیام‌ها، سناریو، شناسه ادامه مکالمه و تنظیمات ارائه‌دهنده

## ارتقاهای اصلی

1. سه عامل مستقل NestAPI یا Gemini به‌صورت موازی اجرا می‌شوند و تحویل‌دادنی‌هایشان به پرامپت کارگردان نهایی تزریق می‌شود.
2. حالت Image Ensemble برای هر صحنه دو سرویس تولید تصویر NestAPI را هم‌زمان اجرا می‌کند؛ کاندیدها انتخاب و سپس در صورت درخواست ویرایش و upscale می‌شوند.
3. امتیازدهی کاندیدها شاخص‌های exposure، contrast، edge detail و clipping را ترکیب می‌کند؛ این امتیاز فنی است نه داوری معنایی/زیبایی‌شناختی.
4. ممیزی تشابه pHash/DCT، dHash و هیستوگرام رنگ برای شناسایی keyframeهای بیش از حد مشابه وجود دارد.
5. قفل حداقل پوشش AI و retry به همراه گزارش fallback حفظ شده است؛ procedural fallback باید صریحاً مجاز شود.
6. موسیقی چندلایه استریو با pad، bass، arpeggio، pulse، بافت، LFO، هارمونی و limiter نرم ساخته می‌شود.
7. Director می‌تواند BPM، منحنی انرژی و sound eventهایی مثل whoosh، riser، soft_hit، tick و ambience در timeline بسازد.
8. TTS به‌روزرسانی شده و فهرست زنده صداها از `action=voices` بارگذاری می‌شود؛ نریشن با ducking به موسیقی افزوده می‌شود.
9. رابط استوری‌بورد، خلاصه موسیقی، BPM، منحنی انرژی و رخدادهای صوتی را نشان می‌دهد.
10. فونت ترکیبی فارسی/لاتین در پوسترهای رندرشده اصلاح شده است؛ عنوان فارسی خالص Noto Sans Arabic و عنوان ترکیبی فونت دارای پوشش هر دو خط می‌گیرد.
11. رندر MP4 با فایل موقت اتمیک انجام می‌شود و تنها پس از عبور از ممیزی فنی منتشر می‌شود.

## تست‌های محلی

- `pytest -q`: **85 passed** در اجرای کنترل‌شده با tracing plugin؛ exit code صفر
- `python -m compileall -q app scripts tests`: موفق
- `node --check web/app.js`: موفق
- سه فایل Workflow با PyYAML parse شده‌اند: موفق
- تست endpoint فهرست صداهای NestAPI با mock قرارداد `action=voices` و route برنامه: موفق
- تست سه عامل Gemini و سه مدل NestAPI موازی: موفق
- تست موتور صوتی استریو، منحنی انرژی، افکت و peak safety: موفق
- تست mixed Persian/Latin font fallback: موفق

## Smoke render واقعی موتور محلی

فایل آزمایشی `cineforge-demo.mp4` با موتور procedural و بدون ادعای تولید تصویر AI ساخته شد:

- مدت: ۶ ثانیه
- ابعاد: 540×960
- نرخ: 24 FPS
- فریم‌ها: ۱۴۴
- تصویر: H.264 / yuv420p
- صدا: AAC، استریو، 44.1 kHz
- مدت تأییدشده FFprobe: 6.000 ثانیه
- حجم: حدود 3.1 MB
- ممیزی فنی: موفق (dimensions، duration، frame count، pixel format، codec، audio presence)

این smoke render تنها سلامت موتور رندر و موسیقی را ثابت می‌کند؛ نمونه کیفیت تصویر زنده NestAPI نیست.

## قراردادهای API پیاده‌سازی‌شده

### NestAPI text

`GET /apis-1/chat-ai` با `q`، `model`، `length=detail`، `style=creativity`، `lang` و context اختیاری `conversation_id`/`id`.

### NestAPI image

- `GET /apis-1/nano-banana`: `prompt`، `ratio` و `quality`
- `GET /apis-1/ai-image-generator`: `prompt`
- `GET /apis-2/edit-image`: `url` و `prompt`
- `GET /apis-2/upscale-image`: `url`، `scale` و `format`

### NestAPI audio

- `GET /apis-1/text-to-speech?action=voices&locale=fa|en` برای دریافت فهرست صداها
- `GET /apis-1/text-to-speech` با `text`، `voice`، `action=synthesize`، `stream=true`، `download=false`، `rate`، `pitch`، `volume` و `format` برای نریشن

### Google Gemini

`POST https://generativelanguage.googleapis.com/v1beta/interactions` با `x-goog-api-key`، `model`، `input` و در صورت ادامه گفتگو `previous_interaction_id`. کلید در مرورگر نگهداری نمی‌شود؛ رمزگذاری سمت سرور انجام می‌شود.

## وضعیت اتصال زنده

در محیط ساخت این بسته، دامنه `open.nestapi.ir` به‌صورت پایدار resolve نشد؛ بنابراین هیچ فراخوانی زنده به NestAPI را در این گزارش موفق اعلام نمی‌کنیم. قرارداد پارامترها و پاسخ‌ها با تست‌های mock اعتبارسنجی شده‌اند. این محدودیت محیط توسعه است، نه شاهد خرابی NestAPI. بعد از اجرای Workflow روی GitHub، با گزینه Nano Banana/Ensemble و «آزمایش اتصال» در برنامه، Round-trip واقعی را بررسی کن.

کلید Gemini واقعی نیز در این محیط استفاده نشده؛ مسیر API و هدر با mock و تست امنیت ذخیره‌سازی رمز‌شده بررسی شده‌اند.

## محدودیت‌های باقی‌مانده

- موتور هنوز Text-to-Video کامل نیست. هر صحنه keyframe تصویر AI مستقل می‌گیرد؛ حرکت از دوربین مجازی، لایه‌ها و انتقال‌ها ساخته می‌شود، نه از حرکت مستقل سوژه توسط مدل ویدیوساز.
- امتیاز انتخاب تصویر فنی است؛ هنوز مدل vision مستقل برای تشخیص معنا، زیبایی‌شناسی، anatomy یا پیوستگی دقیق سوژه در فریم‌ها وجود ندارد.
- حافظه SQLite وقتی ماندگار است که فایل دیتابیس و کلید رمزگذاری روی volume پایدار نگهداری شوند. Runnerهای GitHub Actions موقت‌اند.
- وضعیت jobها فعلاً در حافظه process است، نه صف توزیع‌شده پایدار. برای انتشار عمومی، احراز هویت، صف job پایدار، محدودیت نرخ، جداسازی فایل کاربران و volume/storage دائمی لازم است.
- Ensemble چند API call برای هر صحنه انجام می‌دهد؛ زمان اجرا و سهمیه سرویس بیشتر از حالت تک‌موتوره خواهد بود.

## راه‌اندازی

1. ZIP `CineForge_AI_Studio_v0.5.0.zip` را در ریشه مخزن GitHub قرار بده.
2. فایل `CINEFORGE_BOOTSTRAP_UPLOAD.yml` را در `.github/workflows/cineforge-bootstrap.yml` قرار بده.
3. Actions → **CineForge AI Studio 0.5.0 · Bootstrap, Test and Render** را اجرا کن.
4. بعد از استخراج و commit سورس، برای رندرهای بعدی از Workflow **CineForge AI Production Render** استفاده کن.
5. برای Gemini، `GEMINI_API_KEY` را در Repository Secrets قرار بده؛ NestAPI طبق قرارداد عمومی فعلی کلید ندارد.
