# CineForge AI Studio 0.5.0

استودیوی موبایل‌محور تولید ویدیو با کارگردان دومرحله‌ای، تولید تصویر مستقل برای هر صحنه از طریق NestAPI، حرکت دوربین مجازی، اصلاح رنگ، تایپوگرافی فارسی، حافظه پروژه، ویرایش مکالمه‌ای، رندر FFmpeg و ممیزی تنوع تصویری و فنی.

## جهش اصلی نسخه 0.5

- **ایده‌پردازی دومرحله‌ای:** مدل ابتدا مفهوم، پیام، استعاره بصری، ضرباهنگ و قواعد تداوم را طراحی می‌کند؛ سپس آن را به صحنه‌ها و مشخصات اجرایی تبدیل می‌کند.
- **طرح اجرایی به‌جای الگوی اسلایدی:** هر صحنه موتیف، نوع چیدمان، نقطه فوکوس، مقیاس شروع/پایان، حرکت دوربین، انتقال، میزان جزئیات و نقش رنگ مستقل دارد.
- **مقاومت در برابر تکرار:** ممیزی تنوع موتیف/حرکت/ترکیب‌بندی/یادداشت صحنه و اصلاح خودکار موارد تکراری.
- **حافظه پروژه:** SQLite با ثبت brief، تنظیمات، سناریو، گزارش ممیزی، پیام‌های ویرایش، نسخه‌ها و شناسه ادامه مکالمه ارائه‌دهنده.
- **ویرایش وابسته به آخرین نسخه:** دستورهایی مثل «صحنه دوم را خلوت‌تر کن» یا «پایان را عوض کن» با آخرین سناریوی ذخیره‌شده تطبیق داده می‌شوند؛ فایل قدیمی MP4 به‌عنوان بینایی ماشین تحلیل نمی‌شود.
- **دو ارائه‌دهنده متنی:** NestAPI عمومی براساس قرارداد GET مستندشده و Google Gemini Interactions با کلید دستی رمز‌شده در سرور.
- **بالابری وضوح:** NestAPI Upscale Image با انتخاب 2x/3x/4x؛ خطای این مرحله تصویر پایه را حذف نمی‌کند و به‌صورت هشدار گزارش می‌شود.
- **Quality Gate سخت‌گیرانه:** اگر پوشش keyframeهای AI کمتر از 75٪ باشد، رندر پیش‌فرض متوقف می‌شود تا خروجی عمدتاً procedural به‌اشتباه به‌عنوان ویدیوی AI تحویل نشود. فقط با فعال کردن «اجازه خروجی جایگزین» این قفل برداشته می‌شود.
- **شناسه مدل قابل تغییر:** شناسه مدل‌ها در تنظیمات ثابت و سخت‌کد نشده‌اند؛ مدل‌های پیش‌فرض و شناسه سفارشی قابل استفاده‌اند.
- **۱۰ سبک بصری، ۱۲ حرکت دوربین، ۱۹ موتیف، ۷ چیدمان و ۵ نوع انتقال.**
- **رندر دقیق:** زمان کل صحنه‌ها با روش Largest Remainder دقیقاً با مدت درخواستی برابر می‌شود. ابعاد، نرخ فریم و شمار فریم‌ها پیش از اجرا اعتبارسنجی می‌شوند.
- **کنترل بودجه به‌جای افت کیفیت پنهان:** ترکیب بیش از سقف محاسباتی رد می‌شود و کیفیت/رزولوشن خودکار پایین آورده نمی‌شود.
- **خروجی ویدیو:** فریم‌ها مستقیم از pipe به FFmpeg جریان می‌یابند؛ فایل موقت با پسوند partial ساخته و پس از تکمیل اتمیک به نام نهایی منتقل می‌شود.
- **پخش و دانلود مجزا:** مسیر inline برای پخش مرورگر و endpoint attachment برای دانلود وجود دارد.
- **فارسی‌نویسی:** شکل‌دهی راست‌به‌چپ با arabic-reshaper/python-bidi و انتخاب Noto/Vazirmatn در صورت نصب.

## مسیر تصویری نسخه 0.5: تصویر مستقل، بزرگ‌نمایی و ممیزی هر صحنه

نسخه 0.3 از تصویرسازی procedural استفاده می‌کرد و همان زبان هندسی را در بسیاری از صحنه‌ها تکرار می‌کرد. در نسخه 0.5 مسیر پیش‌فرض تغییر کرده است:

1. مدیر خلاق برای هر صحنه یک `image_prompt` انگلیسی مستقل تولید می‌کند؛ شامل موضوع، کنش، محیط، فاصله و زاویه دوربین، نور، مواد، چیدمان و فضای امن متن.
2. NestAPI Nano Banana برای هر صحنه یک تصویر جداگانه می‌سازد. موتور جایگزین `ai-image-generator` هم قابل انتخاب است.
3. تصویرها دانلود، اعتبارسنجی، به WEBP نرمال و با کلید SHA-256 از روی prompt، مدل/موتور، کیفیت و نسبت تصویر cache می‌شوند.
4. موتور Pillow روی هر keyframe حرکت دوربین مجازی، crop/zoom/pan easing، اصلاح رنگ، vignette و texture کنترل‌شده اجرا می‌کند؛ سپس متن فارسی، transition و صدا به MP4 اضافه می‌شوند.
5. تصویرها با ترکیب dHash، pHash مبتنی بر DCT و شباهت histogram رنگ برای تشخیص خروجی‌های تقریباً تکراری سنجیده می‌شوند. در صورت تشابه بالا یک بار prompt صحنه با دستور تنوع بیشتر دوباره تولید می‌شود. اگر همچنان مشابه بماند، در گزارش به‌عنوان unresolved ثبت می‌شود.
6. در صورت روشن بودن گزینه افزایش وضوح، تصویر از مسیر NestAPI `apis-2/upscale-image` با scale انتخابی 2، 3 یا 4 عبور می‌کند. اگر این مرحله خطا دهد، فایل اصلی حفظ و هشدار ثبت می‌شود؛ رندر به‌خاطر upscaler متوقف نمی‌شود.

این مسیر نسبت به الگوی صرفاً هندسی قبلی تنوع بصری بیشتری می‌دهد، اما هنوز Text-to-Video واقعی نیست: هر صحنه با یک تصویر ثابت ساخته می‌شود و حرکت آن از دوربین مجازی و لایه‌های گرافیکی می‌آید. برای حرکت مستقل اجزای سوژه یا ویدیوی مولد واقعی، بعداً باید سرویس Text/Image-to-Video اضافه شود.

### Endpointهای تصویری NestAPI

- Nano Banana: `GET https://open.nestapi.ir/apis-1/nano-banana` با `prompt`، `ratio` و `quality`؛ نسبت‌های 9:16، 16:9، 1:1 و چند نسبت دیگر و کیفیت‌های `standard` یا `high` در مستندات آمده‌اند.
- Image Generator: `GET https://open.nestapi.ir/apis-1/ai-image-generator` با پارامتر `prompt`؛ مستندات این سرویس تولید تصویر با prompt را معرفی می‌کند.

در تنظیمات، Nano Banana برای کنترل نسبت تصویر گزینه پیش‌فرض است. Image Generator به‌علت نداشتن پارامتر نسبت در مستندات، تصویر را تولید می‌کند و Pillow آن را با crop مناسب قاب خروجی تطبیق می‌دهد.

**تست اتصال واقعی:** در محیط ساخت این نسخه، DNS به `open.nestapi.ir` resolve نشد؛ بنابراین درخواست زنده از این محیط موفقیت‌آمیز نبود. قرارداد درخواست و parser پاسخ مطابق مستندات نوشته شده و با mock تست شده است. پس از استقرار، اولین تولید تصویر باید در GitHub Actions یا Codespaces از نظر شبکه/سهمیه بررسی شود.


## نسخه 0.5.0 — موتور تولید چندعاملی و طراحی صدای هدایت‌شده

- سه عامل مستقل در NestAPI (GPT-5، Claude 4.5، Gemini 3) یا سه نقش موازی با مدل انتخابی Gemini: معمار روایت، مدیر تصویر/فیلم‌برداری، و تدوینگر/طراح صدا. خروجی‌های اجرایی این عامل‌ها به پرامپت کارگردان نهایی تزریق می‌شوند؛ این‌ها سه درخواست مستقل واقعی‌اند، نه سه عنوان نمایشی.
- موتور تصویر `ensemble` برای هر صحنه Nano Banana و AI Image Generator را هم‌زمان فراخوانی می‌کند، فایل‌های تصویری را دریافت و نرمال می‌کند، کاندیدها را بر اساس شاخص‌های فنی پایه مرتب می‌کند و سپس مرحله ویرایش تصویر و upscale اختیاری را اجرا می‌کند.
- فهرست زنده صداهای TTS از همان endpoint با `action=voices` قابل دریافت است. ساخت نریشن با `action=synthesize` و جریان صوتی انجام می‌شود؛ برای مسیر دقیق پارامترها به مستندات NestAPI رجوع کن.
- موسیقی پس‌زمینه به شکل WAV استریوی مولد ساخته می‌شود: آکوردهای چندصدایی، پد، بیس، آرپژ، پالس، بافت و افکت‌های گذار. کارگردان می‌تواند BPM، منحنی انرژی و رخدادهای صوتی زمان‌بندی‌شده بدهد. این موسیقی procedural و اصیل است، نه خروجی یک سرویس تولید آهنگ AI.
- صفحه استوری‌بورد اکنون نقشه موسیقی، BPM و منحنی انرژی را نشان می‌دهد؛ فهرست صداهای TTS نیز از API خود NestAPI بارگذاری می‌شود.
- اصلاح فونت مختلط فارسی/لاتین در پوسترهای رندرشده: رشته‌های فارسی خالص از Noto Arabic و رشته‌های ترکیبی از DejaVu با پوشش هر دو خط استفاده می‌کنند.

### قراردادهای صوتی NestAPI

`GET /apis-1/text-to-speech?action=voices&locale=fa` فهرست گویندگان را می‌گیرد. برای ساخت گفتار، `text`، `voice`، `action=synthesize`، `stream=true` و پارامترهای مجاز `rate`، `pitch`، `volume` و `format` ارسال می‌شوند. این endpoint متن را تا ۵۰۰۰ نویسه می‌پذیرد.

منابع رسمی: [NestAPI TTS](https://nestapi.ir/docs/apis/ai/text-to-speech/)، [Nano Banana](https://nestapi.ir/docs/apis/ai/nano-banana/)، [Image Generator](https://nestapi.ir/docs/apis/ai/ai-image-generator/)، [Edit Image](https://nestapi.ir/docs/apis-2/ai/edit-image/)، [Upscale Image](https://nestapi.ir/docs/apis-2/tools/upscale-image/).

## معماری

```text
Mobile PWA
  └── FastAPI
       ├── Project Memory (SQLite WAL)
       ├── Provider Adapters
       │    ├── NestAPI GET + conversation_id/id
       │    └── Gemini Interactions + previous_interaction_id
       ├── Concept Director (concept JSON)
       ├── Scene Director (executable storyboard JSON)
       ├── Pydantic Schema + Exact Timeline Normalizer
       ├── Preflight Audit + Safe Plan Repair
       ├── Scene-specific Image Provider (Nano Banana / AI Image Generator)
       ├── Asset Cache + AI Image Upscale (2x/3x/4x)
       ├── Visual QA (dHash + DCT pHash + RGB histogram + image metrics)
       ├── Minimum AI Keyframe Coverage Gate (75%)
       ├── Pillow/NumPy Keyframe Camera & Typography Engine
       ├── Multi-layer Stereo Score + NestAPI TTS
       ├── FFmpeg H.264/AAC Renderer
       └── Post-render Audit + Poster + Playback/Download
```

## ارائه‌دهندگان و مدل‌ها

### NestAPI

Endpoint استفاده‌شده:

`GET https://open.nestapi.ir/apis-1/chat-ai`

پارامترها:

- `q`: دستور کامل مدیر خلاق/سناریونویس
- `model`: شناسه مدل (پیش‌فرض `gpt5`؛ فهرست منتشرشده شامل `gpt4o`، `claude45`، `gemini3` و `grok41` نیز هست)
- `length=detail`, `style=creativity`, `lang=fa|en`
- `conversation_id` و `id` برای ادامه زمینه، در صورت برگرداندن این مقادیر از سرویس

طبق مستندات عمومی NestAPI، endpoint عمومی AI به کلید نیاز ندارد. مدل سفارشی نیز از تنظیمات قابل واردکردن است؛ پشتیبانی واقعی آن به فهرست مدل‌های سرویس وابسته است.

### NestAPI audio and voice catalogue

- TTS voice catalogue: `GET https://open.nestapi.ir/apis-1/text-to-speech?action=voices&locale=fa`؛ برای انگلیسی `locale=en` و در صورت نیاز فیلتر gender.
- Synthesis: همان endpoint با `action=synthesize`، `text`، `voice` و `stream=true`؛ `rate`، `pitch`، `volume` و `format` اختیاری‌اند.
- پاسخ voice catalogue از مسیر `/api/audio/voices` در برنامه به UI منتقل می‌شود؛ UI فقط نام/شناسه صدا را دریافت می‌کند و کلیدها در آن نگهداری نمی‌شوند.

### Google Gemini

از Google AI Studio کلید بگیر و در صفحه **تنظیمات → ارائه‌دهنده و مدل** ذخیره کن. ارتباط از سمت Python سرور به Gemini Interactions API انجام می‌شود؛ کلید به JavaScript/browser برگردانده نمی‌شود. شناسه تعامل قبلی با `previous_interaction_id` برای ادامه مکالمه پروژه ذخیره می‌شود.

مدل پیش‌فرض `gemini-3.8-flash` است. کاتالوگ انتخاب سریع با مدل‌های فعلی مستندشده از جمله `gemini-4-hydrogen`، `gemini-4-carbon`، `gemini-4-argon`، `gemini-4-neon`، `gemini-3.8-flash`، `gemini-3.6-flash`، `gemini-3.1-pro-preview`، `gemini-3.5-flash-lite`، `gemini-3.1-flash-lite` و `gemini-2.5-pro/flash` به‌روز شده است. فیلد مدل آزاد است و شناسه‌های دیگر را نیز می‌توان وارد کرد؛ دسترسی واقعی هر مدل به پروژه، منطقه، سطح دسترسی و سهمیه حساب Google وابسته است.

کلید Gemini در SQLite به‌صورت رمز‌شده ذخیره می‌شود. فایل `data/.secret.key` یا مقدار `CINEFORGE_MASTER_KEY` برای رمزگشایی لازم است. در استقرار پایدار، `CINEFORGE_MASTER_KEY` را به‌عنوان secret محیطی ذخیره کن تا با جابه‌جایی volume کلید رمزگشایی گم نشود.

منابع:
- NestAPI Image: https://nestapi.ir/docs/apis/ai/ai-image-generator/
- NestAPI Nano Banana: https://nestapi.ir/docs/apis/ai/nano-banana/
- NestAPI Upscale Image: https://nestapi.ir/docs/apis-2/tools/upscale-image/
- NestAPI: https://nestapi.ir/docs/apis/ai/chat-ai/
- Google Gemini Interactions: https://ai.google.dev/gemini-api/docs/interactions
- Google AI Studio: https://aistudio.google.com/app/apikey

## تنظیمات و بودجه رندر

- مدت: 5 تا 600 ثانیه، با کنترل بودجه
- نسبت تصویر: 9:16، 16:9، 1:1
- وضوح: 540p، 720p، 1080p
- FPS: 24، 30، 60
- کیفیت کدگذاری: fast، balanced، high، ultra
- موسیقی: none، mellow، cinematic، pulse
- سبک بصری: 10 مورد
- موتور تصویرسازی صحنه: Nano Banana، NestAPI Image Generator یا حالت procedural
- کیفیت تصویر AI: standard یا high (گزینه ultra در API مستند نشده و عمداً به‌عنوان کیفیت جعلی نمایش داده نمی‌شود)
- افزایش وضوح AI: خاموش/روشن، 2x، 3x یا 4x از طریق NestAPI Upscale Image
- در حالت AI برای هر صحنه یک درخواست تصویر مستقل ساخته می‌شود؛ تعداد درخواست‌ها برابر تعداد صحنه‌هاست مگر آنکه از cache استفاده شود.
- بزرگ‌نمایی تصویر: اختیاری، 2x/3x/4x، پیش‌فرض 2x؛ در صورت خرابی سرویس تصویر اصلی حفظ می‌شود.
- حداقل پوشش AI: 75٪ keyframeها؛ زیر این میزان رندر متوقف می‌شود مگر گزینه fallback به‌صورت صریح فعال شود.

دو حد محافظتی در schema فعلی:

- حداکثر فریم: 18,000
- حداکثر محاسبه پیکسل-فریم: 8,000,000,000

فرمول:

`pixel_frames = width × height × fps × duration_seconds`

نمونه: 720×1280، 24 FPS، 60 ثانیه = 1,327,104,000 پیکسل-فریم. مدت 600 ثانیه فقط با وضوح/نرخ فریم سبک‌تر و در محدوده بودجه ممکن است. ترکیب سنگین رد می‌شود؛ موتور به‌صورت پنهانی 1080p را به 720p تبدیل نمی‌کند.

مدت طولانی‌تر لزوماً به معنی افت کیفیت نیست؛ اما هزینه محاسبات، حافظه، زمان Runner و حجم خروجی را افزایش می‌دهد. برای 1080p و 60FPS بهتر است کلیپ به بخش‌های کنترل‌شده تقسیم و بعد مونتاژ شود.

## اجرا در GitHub Codespaces

نیازها: Python 3.11+، FFmpeg و فونت Noto/Vazirmatn.

```bash
sudo apt-get update
sudo apt-get install -y ffmpeg fonts-dejavu-core fonts-noto-core
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

پورت 8000 را در تب Ports باز کن و URL عمومی Codespaces را روی گوشی باز کن. برای نصب PWA به HTTPS نیاز است.

## نصب اولیه فقط با گوشی

1. یک مخزن GitHub بساز و ZIP `CineForge_AI_Studio_v0.5.0.zip` را در ریشه آپلود کن.
2. فایل `CINEFORGE_BOOTSTRAP_UPLOAD.yml` را در مسیر `.github/workflows/cineforge-bootstrap.yml` آپلود کن.
3. Actions → **CineForge AI Studio 0.5.0 · Bootstrap, Test and Render** → Run workflow.
4. تنظیمات را انتخاب کن. برای Gemini باید secret مخزن به نام `GEMINI_API_KEY` ایجاد شده باشد؛ در غیر این صورت از NestAPI یا Local استفاده کن.
5. اجرای موفق، ZIP را امن استخراج می‌کند، تست‌ها را اجرا می‌کند، سورس را commit/push می‌کند و MP4، poster و plan را به Artifact می‌فرستد.
6. دفعات بعد از Workflow **CineForge AI Production Render** استفاده کن.

## نکته مهم درباره ماندگاری

SQLite و نسخه‌های پروژه در `data/cineforge.sqlite3` ذخیره می‌شوند. این حافظه در یک دیسک/volume پایدار به‌خوبی باقی می‌ماند. GitHub Actions runner موقت است؛ بعد از اتمام job، دیتابیس و کلید رمزگذاری آن را به‌عنوان حافظه دائمی نگه نمی‌دارد. Artifact ویدیوی خروجی را نگه می‌دارد اما برای تاریخچه و ویرایش مکالمه‌ای بعدی، سرور/volume پایدار لازم است.

## اجرای تست‌ها

```bash
python -m compileall -q app scripts tests
pytest -q
node --check web/app.js
```

## واقعیت و محدودیت‌های تولید رسانه

این نسخه از دو سطح AI استفاده می‌کند: AI متنی برای مفهوم، سناریو، تصویرنامه و ویرایش؛ و AI تصویری برای تولید keyframe مستقل هر صحنه. سپس Pillow/NumPy keyframe را با حرکت دوربین مجازی، grading و تایپوگرافی به فریم‌های ویدیو تبدیل می‌کند و FFmpeg آن‌ها را مونتاژ می‌کند.

این یک پیشرفت جدی نسبت به پس‌زمینه procedural تکراری است، اما نباید آن را Text-to-Video واقعی نامید. سوژه‌ها داخل هر keyframe حرکت مستقل ندارند؛ فقط تصویر از طریق camera move و overlay متحرک می‌شود. همچنین ممیزی تصویری فعلی تکراری بودن تصاویر را با dHash بررسی می‌کند و ممیزی فنی فایل را با FFprobe؛ هنوز یک مدل بینایی مستقل برای قضاوت معنایی یا زیبایی‌شناختی فریم‌ها وجود ندارد.

حافظه پروژه، آخرین سناریو، promptهای صحنه، نسخه‌ها و شناسه ادامه مکالمه را نگه می‌دارد. در ویرایش، prompt صحنه‌های تغییرنکرده cache hit می‌شوند و promptهای تغییرکرده تصویر جدید می‌گیرند. خود MP4 هنوز توسط مدل بینایی دیده نمی‌شود.

## ساختار پروژه

```text
app/
  config.py       # مسیرها، بودجه‌ها و آدرس ارائه‌دهندگان
  schemas.py      # قرارداد درخواست/صحنه/طرح و محدودیت منابع
  prompts.py      # دستورالعمل جامع مدیر خلاق/کارگردان
  providers.py    # NestAPI GET و Gemini Interactions
  planner.py      # ایده‌پردازی دومرحله‌ای و نرمال‌سازی timeline
  audit.py        # ممیزی و اصلاح طرح و ممیزی خروجی
  storage.py      # SQLite، نسخه‌ها و کلید رمز‌شده
  renderer.py     # Pillow/NumPy و انتقال/حرکت دوربین
  audio.py        # موسیقی چندلایه استریو و TTS
  main.py         # FastAPI، پروژه‌ها، Job و تحویل فایل
web/
  index.html      # رابط Studio فارسی
  style.css       # طراحی واکنش‌گرا
  app.js          # ناوبری، پروژه‌ها، تنظیمات و پخش/دانلود
  sw.js           # cache نسخه PWA
scripts/render_demo.py
.github/workflows/
tests/
docs/VIDEO_DIRECTOR_ALGORITHM_FA.md
```
