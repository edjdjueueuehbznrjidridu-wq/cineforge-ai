from __future__ import annotations

import json
import os
import re
import shutil
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .audit import audit_plan, repair_plan
from .config import APP_NAME, APP_VERSION, MAX_ACTIVE_JOBS, OUTPUT_DIR
from .planner import create_plan
from .renderer import render_video
from .visual_assets import enforce_visual_coverage, prepare_scene_assets
from .schemas import AISettingsUpdate, JobCreated, JobStatus, PlanResponse, ProjectEditRequest, VideoRequest
from .storage import (
    append_message, create_project, delete_project, get_project, get_provider_settings,
    init_storage, list_projects, save_draft, save_provider_settings, save_version,
)

WEB_DIR = Path(__file__).resolve().parents[1] / "web"
init_storage()

app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description="Persistent AI-directed video studio with per-scene AI keyframes, image upscaling, motion rendering and visual QA.",
)
app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")

_jobs: dict[str, dict[str, Any]] = {}
_jobs_lock = threading.RLock()
_executor = ThreadPoolExecutor(max_workers=MAX_ACTIVE_JOBS, thread_name_prefix="cineforge-render")


def _set_job(job_id: str, **changes) -> None:
    with _jobs_lock:
        if job_id in _jobs:
            _jobs[job_id].update(changes)


def _safe_output_path(path_value: str | None) -> Path | None:
    if not path_value:
        return None
    candidate = Path(path_value).resolve()
    try:
        candidate.relative_to(OUTPUT_DIR.resolve())
    except ValueError:
        return None
    return candidate


def _run_job(job_id: str, request: VideoRequest, user_instruction: str = "ساخت اولیه") -> None:
    try:
        _set_job(job_id, status="planning", progress=2, message="در حال بازیابی زمینه پروژه و ممیزی سناریو")
        project = get_project(request.project_id) if request.project_id else None
        previous_plan = project.get("latest_plan_json") if project else None
        recent_messages = project.get("messages", []) if project else None
        plan, planner, note, model, plan_audit = create_plan(
            request,
            previous_plan=previous_plan if not request.plan_override else None,
            recent_messages=recent_messages,
        )
        plan, plan_audit = repair_plan(request, plan)
        _set_job(
            job_id, plan=plan.model_dump(), planner=planner, model=model, note=note,
            audit=plan_audit, status="rendering", progress=5,
            message="نقشه صحنه‌ها تأیید شد؛ در حال آماده‌سازی تصاویر مستقل صحنه‌ها.",
        )
        partial_path = OUTPUT_DIR / f"{job_id}.partial.mp4"
        final_path = OUTPUT_DIR / f"{job_id}.mp4"

        def update_progress(progress: int, message: str) -> None:
            _set_job(job_id, progress=min(98, max(5, progress)), message=message)

        scene_assets: dict[int, Path] = {}
        asset_report: dict[str, Any] = {"requested_engine": request.visual_engine, "generated": 0, "reused": 0, "fallback_scenes": [], "warnings": []}
        if request.visual_engine != "procedural":
            def asset_progress(done: int, total: int, message: str) -> None:
                stage_progress = 5 + int(22 * done / max(1, total))
                update_progress(stage_progress, message)

            scene_assets, asset_report = prepare_scene_assets(
                request, plan, request.project_id or "unassigned", asset_progress
            )
            enforce_visual_coverage(request, plan, scene_assets, asset_report)
            if len(scene_assets) < len(plan.scenes):
                _set_job(
                    job_id,
                    message=f"{len(scene_assets)} تصویر اختصاصی آماده شد؛ {len(plan.scenes)-len(scene_assets)} صحنه از موتور جایگزین استفاده می‌کند.",
                    progress=27,
                )
        else:
            update_progress(10, "موتور procedural به انتخاب کاربر فعال است.")

        def render_progress(progress: int, message: str) -> None:
            update_progress(28 + int(progress * 0.69), message)

        metadata = render_video(
            request, plan, partial_path, render_progress,
            scene_assets=scene_assets, asset_report=asset_report,
        )
        os.replace(partial_path, final_path)
        partial_poster = partial_path.with_suffix(".jpg")
        final_poster = final_path.with_suffix(".jpg")
        if partial_poster.exists():
            os.replace(partial_poster, final_poster)
        metadata["path"] = str(final_path)
        metadata["poster_path"] = str(final_poster)
        version = save_version(
            request.project_id,
            user_instruction,
            request.model_dump(mode="json", exclude={"plan_override"}),
            plan.model_dump(mode="json"),
            plan_audit,
            str(final_path),
            metadata,
        )
        fallback_count = len((metadata.get("asset_report") or {}).get("fallback_scenes", []))
        duplicate_count = len((metadata.get("asset_report") or {}).get("unresolved_duplicates", []))
        completion_message = "ویدیو رندر و از نظر فنی ممیزی شد؛ آماده پخش و دریافت است."
        if fallback_count:
            completion_message += f" هشدار: تصویر AI برای {fallback_count} صحنه آماده نشد و آن صحنه‌ها با موتور جایگزین ساخته شدند."
        if duplicate_count:
            completion_message += f" هشدار تنوع بصری: {duplicate_count} صحنه پس از تلاش مجدد هنوز مشابه تشخیص داده شد."
        unresolved_quality = len((metadata.get("asset_report") or {}).get("unresolved_quality_scenes", []))
        if unresolved_quality:
            completion_message += f" هشدار کیفیت تصویر: شاخص پایه {unresolved_quality} صحنه همچنان نیازمند بازبینی است."
        upscale_failures = len((metadata.get("asset_report") or {}).get("upscale_failures", []))
        if upscale_failures:
            completion_message += f" هشدار افزایش وضوح: سرویس upscale برای {upscale_failures} صحنه در دسترس نبود؛ تصاویر اصلی استفاده شدند."
        _set_job(
            job_id, status="completed", progress=100, message=completion_message,
            download_url=f"/api/jobs/{job_id}/download", metadata=metadata,
            completed_at=datetime.now(timezone.utc).isoformat(), version_number=version,
        )
    except Exception as exc:
        try:
            (OUTPUT_DIR / f"{job_id}.partial.mp4").unlink(missing_ok=True)
            (OUTPUT_DIR / f"{job_id}.partial.jpg").unlink(missing_ok=True)
        except OSError:
            pass
        _set_job(
            job_id, status="failed", progress=0, message="ساخت ویدیو کامل نشد.",
            error=f"{type(exc).__name__}: {str(exc)[:450]}",
        )


@app.get("/api/health")
def health():
    settings = get_provider_settings()
    return {
        "ok": True,
        "app": APP_NAME,
        "version": APP_VERSION,
        "providers": {
            "nestapi": {"available": True, "models": ["auto", "gpt5", "gpt4o", "claude45", "gemini3", "grok41"]},
            "gemini": {"available": settings["gemini_configured"], "model": settings["gemini_model"], "current_suggested": ["gemini-4-carbon", "gemini-4-neon", "gemini-4-hydrogen", "gemini-4-argon", "gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.1-pro-preview", "gemini-2.5-pro", "gemini-2.5-flash"]},
            "local": {"available": True},
        },
        "renderer": ["Pillow", "NumPy", "FFmpeg"],
        "visual_engines": ["ensemble", "nano_banana", "ai_image_generator", "procedural"],
        "image_generation": {
            "ensemble": ["/apis-1/nano-banana", "/apis-1/ai-image-generator"],
            "refinement": "/apis-2/edit-image",
            "upscale": "/apis-2/upscale-image",
            "parallel_candidates": 2,
        },
        "text_agents": {"enabled": True, "parallel_roles": ["story_architect", "cinematography_art_director", "editor_sound_designer"]},
        "audio_engine": {"styles": ["auto", "none", "mellow", "cinematic", "pulse", "ambient", "hopeful", "dark", "epic", "focus", "playful", "tension", "dreamy", "emotional", "electronic", "documentary"], "stereo": True, "layers": ["pad", "bass", "arpeggio", "pulse", "texture", "transition_fx"], "tts": "/apis-1/text-to-speech", "voice_catalogue": "/api/audio/voices"},
        "image_upscaler": {"provider": "nestapi", "available": True, "scales": [2, 3, 4]},
        "per_scene_keyframes": True,
        "visual_similarity_audit": {"algorithms": ["dhash", "phash_dct", "rgb_histogram"], "retry_limit": 1},
        "persistent_memory": True,
    }


@app.get("/api/audio/voices")
def audio_voices(locale: str = "fa", gender: str | None = None):
    from .audio import fetch_nestapi_voices
    try:
        voices = fetch_nestapi_voices(locale=locale, gender=gender)
        return {"provider": "nestapi", "locale": locale, "count": len(voices), "voices": voices}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"دریافت فهرست صداهای NestAPI ناموفق بود: {str(exc)[:220]}") from exc


@app.get("/api/settings/ai")
def get_ai_settings():
    settings = get_provider_settings()
    return {
        "provider": settings["provider"],
        "nestapi_model": settings["nestapi_model"],
        "gemini_model": settings["gemini_model"],
        "gemini_configured": settings["gemini_configured"],
        "key_masked": "••••••••" if settings["gemini_configured"] else "",
    }


@app.post("/api/settings/ai")
def update_ai_settings(payload: AISettingsUpdate):
    save_provider_settings(
        payload.provider, payload.nestapi_model, payload.gemini_model, payload.gemini_api_key
    )
    settings = get_provider_settings()
    return {
        "ok": True,
        "provider": settings["provider"],
        "nestapi_model": settings["nestapi_model"],
        "gemini_model": settings["gemini_model"],
        "gemini_configured": settings["gemini_configured"],
        "message": "تنظیمات ذخیره شد؛ کلید فقط در سرور نگهداری می‌شود و به مرورگر بازگردانده نمی‌شود.",
    }


@app.post("/api/settings/ai/test")
def test_ai_provider(payload: AISettingsUpdate):
    # Save supplied settings first, then perform a minimal provider round-trip.
    save_provider_settings(payload.provider, payload.nestapi_model, payload.gemini_model, payload.gemini_api_key)
    settings = get_provider_settings()
    from .providers import complete_text
    model = settings["gemini_model"] if settings["provider"] == "gemini" else settings["nestapi_model"]
    try:
        answer, _ = complete_text(settings["provider"], model, "فقط عبارت CINEFORGE_OK را برگردان.", "fa", settings["gemini_api_key"])
        return {"ok": True, "provider": settings["provider"], "model": model, "sample": answer[:120]}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"آزمون اتصال ناموفق بود: {str(exc)[:250]}") from exc


@app.post("/api/plan", response_model=PlanResponse)
def make_plan(request: VideoRequest):
    project_id = request.project_id
    project = get_project(project_id) if project_id else None
    if project_id and project is None:
        raise HTTPException(status_code=404, detail="پروژه انتخاب‌شده در حافظه پیدا نشد.")
    if not project_id:
        project_id = create_project(request.prompt, request.model_dump(mode="json", exclude={"plan_override"}))
        project = get_project(project_id)
    previous = project.get("latest_plan_json") if project else None
    messages = project.get("messages", []) if project else None
    planning_request = request.model_copy(update={"plan_override": None, "project_id": project_id})
    plan, planner, note, model, report = create_plan(planning_request, previous_plan=previous, recent_messages=messages)
    plan, report = repair_plan(planning_request, plan)
    save_draft(project_id, request.prompt, planning_request.model_dump(mode="json", exclude={"plan_override"}), plan.model_dump(mode="json"), report)
    return PlanResponse(plan=plan, planner=planner, model=model, provider=request.ai_provider, note=note, project_id=project_id, audit=report)


@app.post("/api/projects/{project_id}/edit", response_model=PlanResponse)
def edit_project(project_id: str, payload: ProjectEditRequest):
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="پروژه پیدا نشد.")
    try:
        request_data = dict(project.get("request_json") or {})
        # Last request is the source of truth for visual settings; edit text is a separate instruction.
        request_data["project_id"] = project_id
        request_data["plan_override"] = None
        request_data["use_ai"] = True
        if payload.provider:
            request_data["ai_provider"] = payload.provider
        if payload.model:
            request_data["ai_model"] = payload.model
        request = VideoRequest.model_validate(request_data)
    except Exception as exc:
        raise HTTPException(status_code=409, detail=f"تنظیمات پروژه برای ویرایش قابل بازیابی نیست: {exc}") from exc
    append_message(project_id, "user", payload.instruction, int(project.get("version_number", 0)))
    # Keep the original creative brief stable. Each edit is a separate conversational
    # instruction, so repeated edits do not permanently append into the prompt field.
    base_brief = request.prompt
    planning_request = request.model_copy(update={"prompt": base_brief, "project_id": project_id})
    plan, planner, note, model, report = create_plan(
        planning_request,
        previous_plan=project.get("latest_plan_json"),
        edit_instruction=payload.instruction,
        recent_messages=project.get("messages", []),
    )
    plan, report = repair_plan(planning_request, plan)
    save_draft(project_id, base_brief, planning_request.model_dump(mode="json", exclude={"plan_override"}), plan.model_dump(mode="json"), report)
    return PlanResponse(plan=plan, planner=planner, model=model, provider=request.ai_provider, note="ویرایش بر اساس آخرین سناریوی ذخیره‌شده آماده شد. " + note, project_id=project_id, audit=report)


@app.get("/api/projects")
def projects():
    return {"projects": list_projects(60)}


@app.get("/api/projects/{project_id}")
def project_detail(project_id: str):
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="پروژه پیدا نشد.")
    latest_path = _safe_output_path(project.get("latest_output"))
    return {
        "project_id": project_id,
        "title": project["title"],
        "brief": project["brief"],
        "request": project.get("request_json"),
        "plan": project.get("latest_plan_json"),
        "audit": project.get("latest_audit_json"),
        "version_number": project.get("version_number", 0),
        "created_at": project["created_at"],
        "updated_at": project["updated_at"],
        "video_url": f"/api/projects/{project_id}/play" if latest_path and latest_path.exists() else None,
        "download_url": f"/api/projects/{project_id}/download" if latest_path and latest_path.exists() else None,
        "versions": [
            {"version_number": v["version_number"], "user_instruction": v["user_instruction"], "created_at": v["created_at"], "metadata": v["metadata_json"]}
            for v in project["versions"]
        ],
        "messages": project["messages"],
    }


@app.delete("/api/projects/{project_id}")
def remove_project(project_id: str):
    deleted = delete_project(project_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="پروژه پیدا نشد.")
    return {"ok": True}


@app.post("/api/jobs", response_model=JobCreated)
def create_job(request: VideoRequest):
    project_id = request.project_id
    if project_id and not get_project(project_id):
        raise HTTPException(status_code=404, detail="پروژه انتخاب‌شده پیدا نشد؛ ابتدا سناریو را ذخیره کن.")
    if not project_id:
        project_id = create_project(request.prompt, request.model_dump(mode="json", exclude={"plan_override"}))
        request = request.model_copy(update={"project_id": project_id})
    with _jobs_lock:
        active = sum(1 for item in _jobs.values() if item["status"] in {"queued", "planning", "rendering"})
        if active >= MAX_ACTIVE_JOBS:
            raise HTTPException(status_code=429, detail="موتور مشغول رندر پروژه دیگری است. پس از پایان آن دوباره تلاش کن.")
        job_id = uuid.uuid4().hex[:12]
        _jobs[job_id] = {
            "job_id": job_id, "project_id": project_id, "status": "queued", "progress": 0,
            "message": "پروژه در صف تولید قرار گرفت.", "created_at": datetime.now(timezone.utc).isoformat(),
            "download_url": None, "error": None, "plan": None, "planner": None, "model": None,
            "note": None, "metadata": None, "audit": None,
        }
    _executor.submit(_run_job, job_id, request, "رندر از سناریوی تأییدشده")
    return JobCreated(job_id=job_id, status="queued", project_id=project_id)


@app.get("/api/jobs/{job_id}", response_model=JobStatus)
def job_status(job_id: str):
    with _jobs_lock:
        item = _jobs.get(job_id)
        if not item:
            raise HTTPException(status_code=404, detail="شناسه کار پیدا نشد؛ پروژه‌های ذخیره‌شده را از کتابخانه باز کن.")
        return JobStatus(
            job_id=job_id, status=item["status"], progress=item["progress"], message=item["message"],
            download_url=item.get("download_url"),
            video_url=f"/api/jobs/{job_id}/play" if item["status"] == "completed" else None,
            error=item.get("error"), plan=item.get("plan"), planner=item.get("planner"), note=item.get("note"),
            poster_url=f"/api/jobs/{job_id}/poster" if item["status"] == "completed" else None,
            metadata={k: v for k, v in (item.get("metadata") or {}).items() if k not in {"path", "poster_path"}} or None,
            project_id=item.get("project_id"), audit=item.get("audit"),
        )


def _job_completed_path(job_id: str) -> Path:
    if not re.fullmatch(r"[a-f0-9]{12}", job_id):
        raise HTTPException(status_code=404, detail="شناسه پروژه معتبر نیست.")
    with _jobs_lock:
        item = _jobs.get(job_id)
        if not item or item.get("status") != "completed":
            raise HTTPException(status_code=404, detail="ویدیو هنوز آماده نیست.")
        path = _safe_output_path((item.get("metadata") or {}).get("path"))
    if not path or not path.is_file():
        raise HTTPException(status_code=410, detail="فایل ویدیو دیگر در فضای ذخیره‌سازی نیست.")
    return path


@app.get("/api/jobs/{job_id}/poster")
def job_poster(job_id: str):
    path = _job_completed_path(job_id).with_suffix(".jpg")
    if not path.is_file():
        raise HTTPException(status_code=404, detail="پوستر آماده نیست.")
    return FileResponse(path, media_type="image/jpeg", content_disposition_type="inline")


@app.get("/api/jobs/{job_id}/play")
def play_job(job_id: str):
    path = _job_completed_path(job_id)
    return FileResponse(path, media_type="video/mp4", filename=path.name, content_disposition_type="inline")


@app.get("/api/jobs/{job_id}/download")
def download_job(job_id: str):
    path = _job_completed_path(job_id)
    return FileResponse(path, media_type="video/mp4", filename=f"cineforge-{job_id}.mp4", content_disposition_type="attachment")


def _project_video_path(project_id: str) -> Path:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="پروژه پیدا نشد.")
    path = _safe_output_path(project.get("latest_output"))
    if not path or not path.is_file():
        raise HTTPException(status_code=404, detail="هنوز ویدیوی نهایی برای این پروژه ذخیره نشده است.")
    return path


@app.get("/api/projects/{project_id}/play")
def play_project(project_id: str):
    path = _project_video_path(project_id)
    return FileResponse(path, media_type="video/mp4", filename=path.name, content_disposition_type="inline")


@app.get("/api/projects/{project_id}/download")
def download_project(project_id: str):
    path = _project_video_path(project_id)
    return FileResponse(path, media_type="video/mp4", filename=f"cineforge-{project_id}.mp4", content_disposition_type="attachment")


@app.get("/")
def home():
    return FileResponse(WEB_DIR / "index.html")


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(WEB_DIR / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
def service_worker():
    return FileResponse(WEB_DIR / "sw.js", media_type="application/javascript")


@app.exception_handler(Exception)
async def generic_error_handler(request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": "خطای داخلی موتور رخ داد.", "type": type(exc).__name__})
