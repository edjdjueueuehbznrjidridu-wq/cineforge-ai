"""Provider adapters: NestAPI's documented GET contract and Google's Gemini Interactions REST API."""
from __future__ import annotations

import json
import time
from typing import Any

import httpx

from .config import GEMINI_INTERACTIONS_URL, NESTAPI_CHAT_URL, NESTAPI_RETRIES, NESTAPI_TIMEOUT_SECONDS


class ProviderError(RuntimeError):
    pass


def _deep_text(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts = [_deep_text(x) for x in value]
        return "\n".join(x for x in parts if x)
    if isinstance(value, dict):
        for key in ("output_text", "answer", "response", "text", "content", "message", "output", "result"):
            if key in value:
                found = _deep_text(value[key])
                if found:
                    return found
        for key in ("data", "steps", "choices", "parts"):
            if key in value:
                found = _deep_text(value[key])
                if found:
                    return found
        if value.get("type") in {"text", "model_output"}:
            return _deep_text(value.get("content", value.get("text", "")))
    return ""


def _nestapi_complete(prompt: str, model: str, language: str, context: dict[str, Any] | None = None) -> tuple[str, dict[str, Any]]:
    params: dict[str, Any] = {
        "q": prompt,
        "model": model or "auto",
        "length": "detail",
        "style": "creativity",
        "lang": language if language in {"fa", "en"} else "fa",
    }
    context = context or {}
    if context.get("conversation_id"):
        params["conversation_id"] = str(context["conversation_id"])
    previous_id = context.get("message_id")
    if previous_id is not None:
        try:
            params["id"] = int(previous_id)
        except (TypeError, ValueError):
            pass
    last_error: Exception | None = None
    for attempt in range(NESTAPI_RETRIES + 1):
        try:
            with httpx.Client(timeout=NESTAPI_TIMEOUT_SECONDS, follow_redirects=True) as client:
                response = client.get(NESTAPI_CHAT_URL, params=params)
            response.raise_for_status()
            try:
                payload = response.json()
            except ValueError as exc:
                raise ProviderError("NestAPI پاسخ JSON معتبر برنگرداند.") from exc
            if isinstance(payload, dict) and payload.get("success") is False:
                error = payload.get("error") or {}
                code = error.get("code", "API_ERROR") if isinstance(error, dict) else "API_ERROR"
                raise ProviderError(f"NestAPI error: {code}")
            text = _deep_text(payload)
            if not text:
                raise ProviderError("پاسخ متنی در ساختار JSON نست‌API پیدا نشد.")
            meta: dict[str, Any] = {}
            if isinstance(payload, dict):
                nested = payload.get("data") if isinstance(payload.get("data"), dict) else {}
                conversation_id = payload.get("conversation_id") or nested.get("conversation_id")
                message_id = payload.get("id") or nested.get("id")
                if conversation_id:
                    meta["conversation_id"] = str(conversation_id)
                if message_id is not None:
                    meta["message_id"] = message_id
            return text, meta
        except (httpx.TimeoutException, httpx.TransportError, httpx.HTTPStatusError, ProviderError) as exc:
            last_error = exc
            status = getattr(getattr(exc, "response", None), "status_code", None)
            retryable = status is None or status == 429 or (status is not None and status >= 500)
            if attempt >= NESTAPI_RETRIES or not retryable:
                break
            time.sleep(0.45 * (2 ** attempt))
    if isinstance(last_error, ProviderError):
        raise last_error
    if isinstance(last_error, httpx.HTTPStatusError):
        raise ProviderError(f"NestAPI HTTP {last_error.response.status_code}") from last_error
    raise ProviderError(f"ارتباط با NestAPI ناموفق بود: {type(last_error).__name__ if last_error else 'Unknown'}")


def _gemini_complete(prompt: str, model: str, api_key: str, context: dict[str, Any] | None = None) -> tuple[str, dict[str, Any]]:
    if not api_key:
        raise ProviderError("کلید Gemini در تنظیمات ذخیره نشده است.")
    body = {"model": model or "gemini-3.8-flash", "input": prompt, "store": True}
    previous_interaction = (context or {}).get("interaction_id")
    if previous_interaction:
        body["previous_interaction_id"] = str(previous_interaction)
    # Google documents the Interactions REST API with this API-key header;
    # avoid sending an undocumented revision header that could break proxies.
    headers = {
        "x-goog-api-key": api_key,
        "Content-Type": "application/json",
    }
    try:
        with httpx.Client(timeout=120, follow_redirects=True) as client:
            response = client.post(GEMINI_INTERACTIONS_URL, headers=headers, json=body)
        response.raise_for_status()
        payload = response.json()
    except httpx.HTTPStatusError as exc:
        try:
            detail = exc.response.json().get("error", {}).get("message", "")
        except Exception:
            detail = ""
        raise ProviderError(f"Gemini API HTTP {exc.response.status_code}: {detail[:250]}") from exc
    except (httpx.TimeoutException, httpx.TransportError, ValueError) as exc:
        raise ProviderError(f"ارتباط با Gemini ناموفق بود: {type(exc).__name__}") from exc
    text = _deep_text(payload)
    if not text:
        raise ProviderError("پاسخ متنی از Gemini دریافت نشد.")
    return text, {"interaction_id": payload.get("id") if isinstance(payload, dict) else None}


def complete_text(provider: str, model: str, prompt: str, language: str = "fa", api_key: str = "", context: dict[str, Any] | None = None) -> tuple[str, dict[str, Any]]:
    """Run one text turn, optionally continuing a provider-side conversation."""
    if provider == "nestapi":
        return _nestapi_complete(prompt, model, language, context)
    if provider == "gemini":
        return _gemini_complete(prompt, model, api_key, context)
    raise ProviderError("برنامه‌ریز محلی API خارجی استفاده نمی‌کند.")


def complete_nestapi_ensemble(
    prompt: str,
    language: str = "fa",
    models: tuple[str, ...] = ("gpt5", "claude45", "gemini3"),
) -> list[dict[str, str]]:
    """Run specialist creative agents concurrently through documented NestAPI chat-ai.

    Each agent gets an independent request/conversation to avoid mixing provider
    continuation IDs across different underlying models. The final director
    merges only their authored deliverables, not hidden reasoning.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    roles = [
        (models[0], "STORY ARCHITECT", "قوس روایی، پیام مرکزی، کشش، ترتیب افشا و پایان را طراحی کن."),
        (models[1], "CINEMATOGRAPHY & ART DIRECTOR", "زبان تصویر، لنز، فاصله نما، قاب، نور، رنگ، بافت و تنوع واقعی نماها را طراحی کن."),
        (models[2], "EDITOR & SOUND DESIGNER", "ضرباهنگ، نقاط اوج، زمان هر بیت، انتقال‌ها، موسیقی و صداهای محیطی هماهنگ با حس درخواست را طراحی کن."),
    ]

    def run(role: tuple[str, str, str]) -> dict[str, str]:
        model, title, task = role
        role_prompt = (
            "تو یک متخصص مستقل در تیم تولید ویدیو هستی. فقط تحویل‌دادنی حرفه‌ای بده؛ زنجیره فکر خصوصی را ننویس. "
            "به این درخواست پاسخ بده و از الگوهای عمومی و تکراری دوری کن.\n"
            f"ROLE: {title}\nTASK: {task}\n"
            f"PROJECT BRIEF AND CONSTRAINTS:\n{prompt}\n"
            "خروجی کوتاه اما دقیق با بخش‌های تصمیم‌های اصلی، پیشنهادهای اجرایی، ریسک‌ها و مواردی که باید اجتناب شوند."
        )
        result, _ = _nestapi_complete(role_prompt, model, language)
        return {"role": title, "model": model, "deliverable": result[:5000]}

    results: list[dict[str, str]] = []
    failures: list[str] = []
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="cineforge-agent") as pool:
        futures = {pool.submit(run, role): role for role in roles}
        for future in as_completed(futures):
            role = futures[future]
            try:
                results.append(future.result())
            except Exception as exc:
                failures.append(f"{role[1]} / {role[0]}: {type(exc).__name__}")
    results.sort(key=lambda item: next((i for i, role in enumerate(roles) if role[1] == item["role"]), 99))
    if len(results) < 2:
        raise ProviderError("برای حالت چندعاملی حداقل دو نظر مستقل لازم بود؛ " + "; ".join(failures))
    return results



def complete_gemini_ensemble(
    prompt: str,
    model: str,
    api_key: str,
    language: str = "fa",
) -> list[dict[str, str]]:
    """Run three independent Gemini specialist turns in parallel.

    Each role uses a fresh interaction so their context IDs cannot collide. The
    production director later synthesizes their explicit deliverables.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    roles = [
        ("STORY ARCHITECT", "قوس روایی، پیام محوری، کشش، ترتیب افشا و پایان را طراحی کن."),
        ("CINEMATOGRAPHY & ART DIRECTOR", "زبان تصویر، قاب، زاویه دوربین، نور، رنگ، متریال و تفاوت واقعی نماها را طراحی کن."),
        ("EDITOR & SOUND DESIGNER", "ضرباهنگ، نقاط اوج، BPM، منحنی انرژی موسیقی، هارمونی و رخدادهای صوتی زمان‌بندی‌شده را طراحی کن."),
    ]

    def run(role: tuple[str, str]) -> dict[str, str]:
        title, task = role
        role_prompt = (
            "تو یک متخصص مستقل در تیم تولید ویدیو هستی. فقط تصمیم‌ها و تحویل‌دادنی اجرایی را بده؛ "
            "زنجیره فکر خصوصی را افشا نکن. از الگوهای عمومی و تکراری دوری کن.\n"
            f"ROLE: {title}\nTASK: {task}\nLANGUAGE: {language}\nPROJECT BRIEF:\n{prompt}\n"
            "خروجی باید کوتاه، دقیق و قابل استفاده توسط ابزارهای تولید باشد و شامل تصمیم‌های اصلی، "
            "اقدام‌های اجرایی، ریسک‌ها و مواردی باشد که باید اجتناب شوند."
        )
        result, _ = _gemini_complete(role_prompt, model, api_key, None)
        return {"role": title, "model": model, "deliverable": result[:5000]}

    results: list[dict[str, str]] = []
    failures: list[str] = []
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="cineforge-gemini-agent") as pool:
        futures = {pool.submit(run, role): role for role in roles}
        for future in as_completed(futures):
            role = futures[future]
            try:
                results.append(future.result())
            except Exception as exc:
                failures.append(f"{role[0]}: {type(exc).__name__}")
    results.sort(key=lambda item: next((i for i, role in enumerate(roles) if role[0] == item["role"]), 99))
    if len(results) < 2:
        raise ProviderError("برای تیم Gemini حداقل دو عامل مستقل لازم بود؛ " + "; ".join(failures))
    return results
