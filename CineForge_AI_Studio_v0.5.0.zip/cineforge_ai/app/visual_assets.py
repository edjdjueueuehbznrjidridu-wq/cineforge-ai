"""Per-scene AI keyframes through documented NestAPI image endpoints."""
from __future__ import annotations
import hashlib, ipaddress, time, math, shutil, tempfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache
from typing import Any, Callable
from urllib.parse import urljoin, urlparse
import httpx
import numpy as np
from PIL import Image, ImageOps
from .config import ASSETS_DIR
from .schemas import VideoPlan, VideoRequest

NESTAPI_NANO_BANANA = "https://open.nestapi.ir/apis-1/nano-banana"
NESTAPI_IMAGE_GENERATOR = "https://open.nestapi.ir/apis-1/ai-image-generator"
NESTAPI_UPSCALE_IMAGE = "https://open.nestapi.ir/apis-2/upscale-image"
NESTAPI_EDIT_IMAGE = "https://open.nestapi.ir/apis-2/edit-image"
MAX_IMAGE_BYTES = 25 * 1024 * 1024
STYLE_EN = {
    "cinematic": "cinematic dramatic film still", "minimal": "minimal fine-art editorial still",
    "documentary": "natural documentary photography", "motion": "premium dimensional motion-design key visual",
    "cyberpunk": "cinematic neon-noir science fiction still", "retro": "analog film still with tasteful vintage texture",
    "luxury": "luxury editorial still with restrained lighting", "nature": "immersive nature cinematography",
    "corporate": "premium commercial campaign photography", "dream": "surreal poetic fine-art cinematic still",
}


def _walk_urls(value: Any):
    if isinstance(value, dict):
        preferred = ("image_url", "imageUrl", "url", "output_url", "outputUrl", "download_url", "image", "output", "result", "file", "asset", "data")
        for key in preferred:
            if key in value:
                yield from _walk_urls(value[key])
        for key, child in value.items():
            if key not in preferred:
                yield from _walk_urls(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk_urls(child)
    elif isinstance(value, str) and value.strip().startswith(("https://", "http://")):
        yield value.strip()


def extract_image_url(payload: Any) -> str:
    """Read the documented NestAPI success/data envelope without mistaking source links for assets."""
    if isinstance(payload, dict):
        if payload.get("success") is False:
            error = payload.get("error") or {}
            code = error.get("code", "API_ERROR") if isinstance(error, dict) else "API_ERROR"
            message = error.get("message", "") if isinstance(error, dict) else ""
            raise RuntimeError(f"NestAPI image generation failed: {code} {message}".strip())
        if payload.get("success") is True and "data" in payload:
            candidates = list(_walk_urls(payload.get("data")))
        else:
            candidates = list(_walk_urls(payload))
    else:
        candidates = list(_walk_urls(payload))
    for candidate in candidates:
        parsed = urlparse(candidate)
        if parsed.scheme in {"https", "http"} and parsed.netloc:
            return candidate
    raise RuntimeError("NestAPI پاسخ موفق داد اما URL تصویر در فیلد data پیدا نشد.")


def _validate_external_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname:
        raise RuntimeError("نشانی تصویر باید HTTPS باشد.")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".local", ".internal")):
        raise RuntimeError("مقصد دانلود تصویر مجاز نیست.")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address and (address.is_private or address.is_loopback or address.is_link_local or address.is_reserved):
        raise RuntimeError("نشانی شبکه خصوصی برای دریافت تصویر پذیرفته نیست.")


def download_and_normalize_image(url: str, destination: Path) -> dict[str, Any]:
    current = url
    headers = {"User-Agent": "CineForge-Studio/0.4", "Accept": "image/avif,image/webp,image/png,image/jpeg,*/*;q=0.5"}
    with httpx.Client(timeout=httpx.Timeout(connect=20, read=120, write=20, pool=20), follow_redirects=False) as client:
        for redirect_index in range(4):
            _validate_external_url(current)
            response = client.get(current, headers=headers)
            if response.status_code in {301, 302, 303, 307, 308}:
                location = response.headers.get("location")
                if not location or redirect_index == 3:
                    raise RuntimeError("مسیر دانلود تصویر بیش از حد تغییر مسیر داد.")
                current = urljoin(current, location)
                continue
            response.raise_for_status()
            content_type = response.headers.get("content-type", "").split(";", 1)[0].lower()
            if not content_type.startswith("image/"):
                raise RuntimeError(f"خروجی سرویس تصویر نیست: {content_type or 'unknown'}")
            data = response.content
            if not data or len(data) > MAX_IMAGE_BYTES:
                raise RuntimeError("حجم تصویر خالی یا بیشتر از ۲۵ مگابایت است.")
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_suffix(".tmp.webp")
            try:
                from io import BytesIO
                with Image.open(BytesIO(data)) as source:
                    source = ImageOps.exif_transpose(source)
                    source.load()
                    if source.width < 256 or source.height < 256:
                        raise RuntimeError("وضوح تصویر برای keyframe کافی نیست.")
                    image = source.convert("RGB")
                    image.save(temporary, format="WEBP", quality=93, method=5)
                temporary.replace(destination)
            except Exception:
                temporary.unlink(missing_ok=True)
                raise
            return {"bytes": destination.stat().st_size, "width": image.width, "height": image.height, "content_type": content_type}
    raise RuntimeError("دانلود تصویر کامل نشد.")


def build_scene_image_prompt(request: VideoRequest, plan: VideoPlan, scene_index: int) -> str:
    scene = plan.scenes[scene_index]
    style = STYLE_EN.get(request.style, STYLE_EN["cinematic"])
    shot_map = {
        "center": "centered hero composition with generous breathing room",
        "upper": "subject placed in upper third, clean lower negative space",
        "lower": "subject placed low in frame, open upper atmosphere",
        "left": "subject anchored left with intentional open right-side negative space",
        "right": "subject anchored right with intentional open left-side negative space",
        "split": "asymmetric split composition with two visually related zones",
        "diagonal": "dynamic diagonal composition with clear visual direction",
        "fullbleed": "immersive edge-to-edge environmental composition",
    }
    base = scene.image_prompt.strip() or (
        f"A distinctive cinematic still showing {scene.title}. {scene.subtitle}. "
        f"Subject context: {request.prompt[:500]}"
    )
    continuity = " ".join(x for x in (plan.visual_bible, plan.subject_anchor) if x)
    palette_map = {
        "auto": "a coherent cinematic palette chosen to match the subject",
        "ocean": "deep blue, teal, restrained cyan highlights",
        "violet": "violet, indigo and muted lavender accents",
        "amber": "warm amber, burnt gold and deep shadow",
        "emerald": "emerald green, moss and natural dark neutrals",
        "rose": "muted rose, burgundy and warm neutral highlights",
        "mono": "controlled monochrome with a single tonal accent",
    }
    palette = palette_map.get(request.accent_palette, palette_map["auto"])
    if request.accent_color:
        palette += f" with restrained accent color {request.accent_color}"
    prompt = (
        f"{style}. Original scene-specific production still for a coherent short film. "
        f"PROJECT WORLD: {continuity[:800]}. SHOT {scene_index + 1}/{len(plan.scenes)} of {len(plan.scenes)}. "
        f"SCENE PURPOSE: {scene.kind}. SHOT BRIEF: {base}. "
        f"FRAMING: {shot_map.get(scene.composition, shot_map['center'])}. "
        f"MOTIF LANGUAGE: {scene.motif}. CAMERA INTENTION: {scene.camera_path or scene.motion}. "
        f"VISUAL EVENT: {scene.visual_note[:450]}. COLOR SCRIPT: {palette}. "
        "Keep the same core subject identity as other shots, but make this shot's camera distance, camera height, lens feel, environment, lighting direction, and visible action clearly distinct from adjacent scenes. "
        "Do not default to a centered glowing orb, concentric rings, generic circuit grid, HUD, or abstract dashboard; use these only if the scene brief explicitly requires them. "
        "Physically coherent perspective, believable scale, tactile materials, layered depth, deliberate subject separation, professional lensing and motivated lighting. "
        "No typography, words, letters, subtitles, UI, logo, watermark, or picture frame. "
        "Compose with a clean title-safe region that does not cover the main subject."
    )
    return prompt[:7600]


def _asset_cache_key(engine: str, quality: str, ratio: str, prompt: str, upscale: bool = True, upscale_scale: int = 2) -> str:
    material = "|".join(("cineforge-image-v3", engine, quality, ratio, str(upscale), str(upscale_scale), prompt))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _request_json_url(endpoint: str, params: dict[str, str], timeout: int = 300) -> str:
    """Call a documented NestAPI JSON endpoint and return its output image URL."""
    with httpx.Client(timeout=httpx.Timeout(connect=20, read=timeout, write=30, pool=30), follow_redirects=True) as client:
        response = client.get(endpoint, params=params, headers={"Accept": "application/json", "User-Agent": "CineForge-Studio/0.5"})
    response.raise_for_status()
    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError("NestAPI پاسخ JSON معتبر برنگرداند.") from exc
    return extract_image_url(payload)


def _request_upscale(image_url: str, scale: int) -> str:
    """Request NestAPI's documented image upscaler; returns a new image URL."""
    _validate_external_url(image_url)
    return _request_json_url(
        NESTAPI_UPSCALE_IMAGE,
        {"url": image_url, "scale": str(scale), "format": "auto"},
        timeout=240,
    )


def _request_edit(image_url: str, prompt: str) -> str:
    """Run the documented edit-image endpoint on a publicly reachable source image."""
    _validate_external_url(image_url)
    if not prompt.strip():
        return image_url
    return _request_json_url(
        NESTAPI_EDIT_IMAGE,
        {"url": image_url, "prompt": prompt[:3000]},
        timeout=300,
    )


def _request_generation(engine: str, prompt: str, ratio: str, quality: str) -> str:
    endpoint = NESTAPI_NANO_BANANA if engine == "nano_banana" else NESTAPI_IMAGE_GENERATOR
    params: dict[str, str] = {"prompt": prompt}
    if engine == "nano_banana":
        params.update({"ratio": ratio, "quality": quality})
    return _request_json_url(endpoint, params, timeout=300)


def _candidate_score(path: Path) -> tuple[float, dict[str, float]]:
    """Technical candidate ranking only; it does not claim semantic understanding."""
    metrics = _image_quality_metrics(path)
    brightness = metrics["brightness"]
    contrast = metrics["contrast"]
    edge = metrics["edge_energy"]
    clipped = metrics["clipped_fraction"]
    # A soft target, not a harsh universal aesthetic rule: avoid blank, crushed,
    # blown-out or nearly textureless candidates while preserving dark film looks.
    exposure_score = max(0.0, 1.0 - abs(brightness - 0.43) / 0.52)
    contrast_score = min(1.0, contrast / 0.22)
    detail_score = min(1.0, edge / 0.045)
    clipping_score = max(0.0, 1.0 - clipped * 1.7)
    score = 0.27 * exposure_score + 0.27 * contrast_score + 0.30 * detail_score + 0.16 * clipping_score
    return round(score, 5), metrics


def _generate_one(
    engine: str,
    prompt: str,
    ratio: str,
    quality: str,
    destination: Path,
    *,
    upscale: bool = True,
    upscale_scale: int = 2,
    refine: bool = False,
) -> dict[str, Any]:
    """Generate one keyframe, optionally in parallel through both image APIs.

    `ensemble` fires Nano Banana and AI Image Generator concurrently, scores
    downloaded candidates, then keeps one. Edit-image and upscaler are applied
    only after selection to avoid wasting calls on a discarded candidate.
    """
    if engine not in {"nano_banana", "ai_image_generator", "ensemble"}:
        raise RuntimeError(f"موتور تصویر ناشناخته است: {engine}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    candidate_meta: list[dict[str, Any]] = []
    chosen_url = ""
    chosen_engine = engine
    last_error: Exception | None = None

    if engine == "ensemble":
        endpoints = ("nano_banana", "ai_image_generator")
        with tempfile.TemporaryDirectory(prefix="cineforge-candidates-") as temp_dir:
            temp_root = Path(temp_dir)
            future_map = {}
            with ThreadPoolExecutor(max_workers=2, thread_name_prefix="cineforge-image") as pool:
                for candidate_engine in endpoints:
                    future = pool.submit(_request_generation, candidate_engine, prompt, ratio, quality)
                    future_map[future] = candidate_engine
                urls: dict[str, str] = {}
                for future in as_completed(future_map):
                    candidate_engine = future_map[future]
                    try:
                        urls[candidate_engine] = future.result()
                    except Exception as exc:
                        last_error = exc
                        candidate_meta.append({"engine": candidate_engine, "status": "failed", "error": f"{type(exc).__name__}: {str(exc)[:140]}"})
            for candidate_engine in endpoints:
                if candidate_engine not in urls:
                    continue
                candidate_path = temp_root / f"{candidate_engine}.webp"
                try:
                    info = download_and_normalize_image(urls[candidate_engine], candidate_path)
                    score, metrics = _candidate_score(candidate_path)
                    candidate_meta.append({"engine": candidate_engine, "status": "ok", "score": score, "metrics": metrics, "url": urls[candidate_engine], "path": candidate_path})
                except Exception as exc:
                    last_error = exc
                    candidate_meta.append({"engine": candidate_engine, "status": "failed", "error": f"{type(exc).__name__}: {str(exc)[:140]}"})
            viable = [item for item in candidate_meta if item.get("status") == "ok"]
            if not viable:
                raise RuntimeError(f"هر دو موتور تصویر ناموفق بودند: {type(last_error).__name__ if last_error else 'Unknown'}")
            chosen = max(viable, key=lambda item: float(item.get("score", 0.0)))
            chosen_engine = str(chosen["engine"])
            chosen_url = str(chosen["url"])
            shutil.copyfile(chosen["path"], destination)
            candidate_meta = [
                {k: v for k, v in item.items() if k not in {"path", "url"}}
                for item in candidate_meta
            ]
    else:
        chosen_engine = engine
        chosen_url = _request_generation(engine, prompt, ratio, quality)

    # Refine with the image-editing API only when explicitly requested. This is
    # a separate call from generation and is recorded independently in metadata.
    edit_applied = False
    edit_warning = None
    if refine:
        try:
            refinement_prompt = (
                "Improve this existing cinematic still without changing its central subject, identity, or scene meaning. "
                "Correct exposure, tonal separation, realistic material detail, edge clarity, and local contrast. "
                "Remove malformed or incoherent artifacts. Preserve the original composition and color direction."
            )
            chosen_url = _request_edit(chosen_url, refinement_prompt)
            edit_applied = True
        except Exception as exc:
            edit_warning = f"Image edit skipped: {type(exc).__name__}: {str(exc)[:150]}"

    upscale_applied = False
    upscale_warning = None
    if upscale:
        try:
            chosen_url = _request_upscale(chosen_url, upscale_scale)
            upscale_applied = True
        except Exception as exc:
            upscale_warning = f"Upscale skipped: {type(exc).__name__}: {str(exc)[:160]}"

    # If ensemble already wrote the selected candidate and no postprocess ran,
    # keep it; otherwise fetch the final transformed image atomically.
    if engine != "ensemble" or refine and edit_applied or upscale and upscale_applied:
        info = download_and_normalize_image(chosen_url, destination)
    else:
        info = download_and_normalize_image(chosen_url, destination)
    info.update({
        "endpoint": chosen_engine,
        "ensemble_candidates": candidate_meta,
        "candidate_count": len(candidate_meta) if engine == "ensemble" else 1,
        "edit_applied": edit_applied,
        "upscale_applied": upscale_applied,
    })
    if upscale_warning:
        info["upscale_warning"] = upscale_warning
    if edit_warning:
        info["edit_warning"] = edit_warning
    return info


def _difference_hash(path: Path) -> int:
    """Small perceptual fingerprint used to catch near-identical generated shots."""
    with Image.open(path) as image:
        gray = image.convert("L").resize((9, 8), Image.Resampling.LANCZOS)
        pixels = np.asarray(gray, dtype=np.uint8).reshape(-1).tolist()
    value = 0
    bit = 0
    for row in range(8):
        for col in range(8):
            left = pixels[row * 9 + col]
            right = pixels[row * 9 + col + 1]
            if left > right:
                value |= 1 << bit
            bit += 1
    return value


def _hamming_distance(a: int, b: int) -> int:
    return (a ^ b).bit_count()


@lru_cache(maxsize=1)
def _dct_basis(size: int = 32) -> np.ndarray:
    coordinates = np.arange(size, dtype=np.float32)
    frequencies = coordinates[:, None]
    basis = np.cos((math.pi / size) * (coordinates[None, :] + 0.5) * frequencies)
    basis[0, :] *= 1.0 / math.sqrt(2.0)
    return basis * math.sqrt(2.0 / size)


def _perceptual_hash(path: Path) -> int:
    """DCT perceptual hash, less sensitive than dHash to small local changes."""
    with Image.open(path) as image:
        gray = np.asarray(image.convert("L").resize((32, 32), Image.Resampling.LANCZOS), dtype=np.float32)
    basis = _dct_basis()
    transformed = basis @ gray @ basis.T
    low = transformed[:8, :8].reshape(-1)
    median = float(np.median(low[1:]))
    value = 0
    for bit, coefficient in enumerate(low[1:]):
        if coefficient > median:
            value |= 1 << bit
    return value


def _color_histogram(path: Path) -> np.ndarray:
    with Image.open(path) as image:
        rgb = np.asarray(image.convert("RGB").resize((96, 96), Image.Resampling.BILINEAR), dtype=np.uint8)
    channels = []
    for channel in range(3):
        hist, _ = np.histogram(rgb[..., channel], bins=16, range=(0, 256), density=False)
        hist = hist.astype(np.float32)
        hist /= max(1.0, float(hist.sum()))
        channels.append(hist)
    return np.concatenate(channels)


def _histogram_similarity(first: np.ndarray, second: np.ndarray) -> float:
    return float(1.0 - 0.5 * np.abs(first - second).sum() / 3.0)


def _near_duplicate(path: Path, previous_signatures: list[tuple[int, int, np.ndarray]], max_distance: int = 4) -> bool:
    """Compare structure and palette; one weak cue alone does not flag a duplicate."""
    try:
        current = (_difference_hash(path), _perceptual_hash(path), _color_histogram(path))
    except Exception:
        return False
    for old_dhash, old_phash, old_hist in previous_signatures:
        color_match = _histogram_similarity(current[2], old_hist) >= 0.94
        structure_match = (
            _hamming_distance(current[0], old_dhash) <= max_distance
            or _hamming_distance(current[1], old_phash) <= 6
        )
        if structure_match and color_match:
            return True
    return False


def _image_quality_metrics(path: Path) -> dict[str, float]:
    """Measure coarse exposure, contrast and detail without claiming semantic understanding."""
    with Image.open(path) as image:
        gray = np.asarray(image.convert("L").resize((160, 160), Image.Resampling.LANCZOS), dtype=np.float32)
    dx = np.abs(np.diff(gray, axis=1)).mean() if gray.shape[1] > 1 else 0.0
    dy = np.abs(np.diff(gray, axis=0)).mean() if gray.shape[0] > 1 else 0.0
    return {
        "brightness": round(float(gray.mean() / 255.0), 4),
        "contrast": round(float(gray.std() / 255.0), 4),
        "edge_energy": round(float((dx + dy) / 510.0), 5),
        "clipped_fraction": round(float(((gray <= 5) | (gray >= 250)).mean()), 4),
    }


def _image_quality_issues(metrics: dict[str, float]) -> list[str]:
    issues = []
    if metrics["brightness"] < 0.035:
        issues.append("بیش از حد تیره")
    if metrics["brightness"] > 0.975:
        issues.append("بیش از حد روشن")
    if metrics["contrast"] < 0.018:
        issues.append("کنتراست بسیار کم")
    if metrics["edge_energy"] < 0.0025:
        issues.append("جزئیات لبه‌ای بسیار کم")
    if metrics["clipped_fraction"] > 0.82:
        issues.append("سطح زیادی از تصویر به سیاهی/سفیدی خالص بریده شده")
    return issues


def enforce_visual_coverage(
    request: VideoRequest,
    plan: VideoPlan,
    assets: dict[int, Path],
    report: dict[str, Any],
    minimum_coverage: float = 0.75,
) -> dict[str, Any]:
    """Stop a nominally AI-generated job from silently degrading into mostly procedural output."""
    total = max(1, len(plan.scenes))
    coverage = len(assets) / total
    report["ai_asset_coverage"] = round(coverage, 4)
    report["minimum_ai_asset_coverage"] = minimum_coverage
    report["visual_audit_passed"] = bool(report.get("visual_audit_passed", True)) and coverage >= minimum_coverage
    if request.visual_engine == "procedural":
        return report
    if coverage < minimum_coverage and not request.allow_procedural_fallback:
        needed = int(np.ceil(total * minimum_coverage))
        raise RuntimeError(
            f"ممیزی کیفیت اجازه رندر نداد: فقط {len(assets)} از {total} صحنه تصویر AI معتبر دارند؛ "
            f"حداقل {needed} صحنه لازم است. اتصال/سهمیه تصویرساز را بررسی کن یا گزینه اجازه fallback را فعال کن."
        )
    if coverage < 1.0:
        report.setdefault("warnings", []).append(
            f"پوشش تصویر AI برابر {coverage:.0%} است؛ {total-len(assets)} صحنه از موتور procedural استفاده می‌کند."
        )
    return report


def prepare_scene_assets(
    request: VideoRequest,
    plan: VideoPlan,
    project_id: str,
    on_progress: Callable[[int, int, str], None] | None = None,
) -> tuple[dict[int, Path], dict[str, Any]]:
    """Generate/cache one AI keyframe per scene; failed scenes fall back explicitly."""
    if request.visual_engine == "procedural":
        return {}, {"requested_engine": "procedural", "generated": 0, "reused": 0, "fallback_scenes": [], "warnings": []}
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    engine = request.visual_engine
    quality = request.image_quality
    assets: dict[int, Path] = {}
    generated = reused = 0
    warnings: list[str] = []
    fallback_scenes: list[int] = []
    duplicate_retries: list[int] = []
    unresolved_duplicates: list[int] = []
    quality_retry_scenes: list[int] = []
    unresolved_quality_scenes: list[int] = []
    upscaled_scenes: list[int] = []
    upscale_failures: list[int] = []
    scene_metrics: dict[str, dict[str, float]] = {}
    scene_endpoints: dict[str, str] = {}
    scene_candidates: dict[str, list[dict[str, Any]]] = {}
    refined_scenes: list[int] = []
    previous_hashes: list[tuple[int, int, np.ndarray]] = []
    total = len(plan.scenes)
    for index, scene in enumerate(plan.scenes):
        prompt = build_scene_image_prompt(request, plan, index)
        key = _asset_cache_key(engine, quality, request.aspect_ratio, prompt, request.upscale_images, request.upscale_scale)
        destination = ASSETS_DIR / key[:2] / f"{key}.webp"
        cache_hit = False
        if destination.is_file() and destination.stat().st_size > 2048:
            try:
                with Image.open(destination) as image:
                    image.verify()
                cache_hit = True
                cached_metrics = _image_quality_metrics(destination)
                cached_quality_issues = _image_quality_issues(cached_metrics)
                if _near_duplicate(destination, previous_hashes) or cached_quality_issues:
                    # A cached duplicate or technically extreme image is regenerated, not silently reused.
                    cache_hit = False
                    destination.unlink(missing_ok=True)
            except Exception:
                destination.unlink(missing_ok=True)
        if cache_hit:
            assets[index] = destination
            reused += 1
            previous_hashes.append((_difference_hash(destination), _perceptual_hash(destination), _color_histogram(destination)))
            scene_metrics[str(index + 1)] = cached_metrics
            if on_progress:
                on_progress(index + 1, total, f"تصویر اختصاصی صحنه {index + 1} از حافظه آماده شد.")
            continue
        try:
            generation_kwargs = {"upscale": request.upscale_images, "upscale_scale": request.upscale_scale}
            if request.refine_images:
                generation_kwargs["refine"] = True
            generation_info = _generate_one(
                engine, prompt, request.aspect_ratio, quality, destination,
                **generation_kwargs,
            )
            if generation_info.get("upscale_applied"):
                upscaled_scenes.append(index + 1)
            if generation_info.get("edit_applied"):
                refined_scenes.append(index + 1)
            if generation_info.get("endpoint"):
                scene_endpoints[str(index + 1)] = str(generation_info["endpoint"])
            if generation_info.get("ensemble_candidates"):
                scene_candidates[str(index + 1)] = generation_info["ensemble_candidates"]
            if generation_info.get("upscale_warning"):
                upscale_failures.append(index + 1)
                warnings.append(f"صحنه {index + 1}: {generation_info['upscale_warning']}")
            duplicate_found = _near_duplicate(destination, previous_hashes)
            first_metrics = _image_quality_metrics(destination)
            first_quality_issues = _image_quality_issues(first_metrics)
            if duplicate_found or first_quality_issues:
                if duplicate_found:
                    duplicate_retries.append(index + 1)
                if first_quality_issues:
                    quality_retry_scenes.append(index + 1)
                retry_prompt = prompt + "\n"
                if duplicate_found:
                    retry_prompt += (
                        "CRITICAL DIFFERENT-SHOT REQUIREMENT: The previous generated shot was too visually similar to another scene. "
                        "Keep the exact subject identity and project world, but change the physical setting, camera height, focal length, "
                        "shot distance, dominant silhouette, light direction, and visible action. Do not use concentric rings, a centered orb, "
                        "a generic grid, or the same central composition unless explicitly required by this scene. Produce a clearly different frame. "
                    )
                if first_quality_issues:
                    retry_prompt += (
                        "QUALITY RECOVERY: The previous result had these technical image issues: " + ", ".join(first_quality_issues) + ". "
                        "Create a crisp, well-exposed, detailed production still with balanced highlights and shadows, clear subject separation, "
                        "natural texture and controlled contrast. Avoid flat blank surfaces and crushed blacks or blown highlights. "
                    )
                retry_key = _asset_cache_key(engine, quality, request.aspect_ratio, retry_prompt, request.upscale_images, request.upscale_scale)
                retry_destination = ASSETS_DIR / retry_key[:2] / f"{retry_key}.webp"
                retry_kwargs = {"upscale": request.upscale_images, "upscale_scale": request.upscale_scale}
                if request.refine_images:
                    retry_kwargs["refine"] = True
                retry_info = _generate_one(
                    engine, retry_prompt, request.aspect_ratio, quality, retry_destination,
                    **retry_kwargs,
                )
                if retry_info.get("upscale_applied") and index + 1 not in upscaled_scenes:
                    upscaled_scenes.append(index + 1)
                if retry_info.get("edit_applied") and index + 1 not in refined_scenes:
                    refined_scenes.append(index + 1)
                if retry_info.get("endpoint"):
                    scene_endpoints[str(index + 1)] = str(retry_info["endpoint"])
                if retry_info.get("ensemble_candidates"):
                    scene_candidates[str(index + 1)] = retry_info["ensemble_candidates"]
                if retry_info.get("upscale_warning"):
                    if index + 1 not in upscale_failures:
                        upscale_failures.append(index + 1)
                    warnings.append(f"صحنه {index + 1}: {retry_info['upscale_warning']}")
                if retry_destination != destination:
                    retry_destination.replace(destination)
                if _near_duplicate(destination, previous_hashes):
                    unresolved_duplicates.append(index + 1)
                    warnings.append(f"صحنه {index + 1}: تصویر دوم هم از نظر الگوی کلی به صحنه قبلی نزدیک است؛ نیازمند بازبینی هنری.")
            metrics = _image_quality_metrics(destination)
            remaining_issues = _image_quality_issues(metrics)
            scene_metrics[str(index + 1)] = metrics
            if remaining_issues:
                unresolved_quality_scenes.append(index + 1)
                warnings.append(f"صحنه {index + 1}: پس از تلاش مجدد، شاخص تصویری نیازمند بازبینی است: {', '.join(remaining_issues)}.")
            assets[index] = destination
            generated += 1
            previous_hashes.append((_difference_hash(destination), _perceptual_hash(destination), _color_histogram(destination)))
            message = f"تصویر اختصاصی صحنه {index + 1} تولید و از نظر تکرار و کیفیت پایه بررسی شد."
        except Exception as exc:
            fallback_scenes.append(index + 1)
            warnings.append(f"صحنه {index + 1}: {type(exc).__name__}: {str(exc)[:180]}")
            message = f"تولید تصویر صحنه {index + 1} ناموفق بود؛ fallback procedural فعال شد."
        if on_progress:
            on_progress(index + 1, total, message)
    return assets, {
        "requested_engine": engine,
        "image_strategy": "parallel_ensemble" if engine == "ensemble" else "single_provider",
        "scene_endpoints": scene_endpoints,
        "scene_candidates": scene_candidates,
        "refined_scenes": refined_scenes,
        "refine_images_enabled": request.refine_images,
        "upscale_enabled": request.upscale_images,
        "upscale_scale": request.upscale_scale if request.upscale_images else None,
        "upscaled_scenes": upscaled_scenes,
        "upscale_failures": upscale_failures,
        "generated": generated,
        "reused": reused,
        "fallback_scenes": fallback_scenes,
        "duplicate_retries": duplicate_retries,
        "unresolved_duplicates": unresolved_duplicates,
        "quality_retry_scenes": quality_retry_scenes,
        "unresolved_quality_scenes": unresolved_quality_scenes,
        "scene_metrics": scene_metrics,
        "visual_diversity_passed": not unresolved_duplicates,
        "visual_audit_passed": not unresolved_duplicates and not unresolved_quality_scenes and not fallback_scenes and not upscale_failures,
        "warnings": warnings,
        "scene_assets": {str(index + 1): path.name for index, path in assets.items()},
    }
