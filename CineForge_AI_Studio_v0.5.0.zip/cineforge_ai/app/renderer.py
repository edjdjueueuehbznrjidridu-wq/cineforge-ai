from __future__ import annotations

import hashlib
import json
import math
import shutil
import subprocess
import tempfile
from functools import lru_cache
from pathlib import Path
from typing import Callable

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

from .audio import create_ambient_track, generate_nestapi_voiceover, infer_music_style
from .audit import audit_render_metadata
from .schemas import VideoPlan, VideoRequest

ProgressCallback = Callable[[int, str], None]

STYLE_PALETTES: dict[str, dict[str, tuple[int, int, int]]] = {
    "cinematic": {"bg": (5, 12, 25), "mid": (10, 30, 49), "accent": (82, 195, 245), "secondary": (118, 148, 195)},
    "minimal": {"bg": (11, 14, 20), "mid": (28, 31, 39), "accent": (227, 205, 151), "secondary": (165, 171, 181)},
    "documentary": {"bg": (7, 20, 19), "mid": (17, 42, 37), "accent": (132, 207, 171), "secondary": (129, 171, 154)},
    "motion": {"bg": (4, 13, 28), "mid": (12, 38, 67), "accent": (69, 177, 255), "secondary": (108, 139, 224)},
    "cyberpunk": {"bg": (18, 7, 27), "mid": (39, 12, 51), "accent": (244, 88, 205), "secondary": (92, 224, 245)},
    "retro": {"bg": (28, 16, 10), "mid": (58, 31, 18), "accent": (242, 148, 72), "secondary": (95, 201, 191)},
    "luxury": {"bg": (14, 12, 13), "mid": (35, 29, 25), "accent": (218, 184, 111), "secondary": (169, 150, 125)},
    "nature": {"bg": (5, 19, 15), "mid": (13, 43, 31), "accent": (129, 210, 133), "secondary": (100, 177, 149)},
    "corporate": {"bg": (7, 15, 28), "mid": (18, 37, 58), "accent": (94, 164, 238), "secondary": (125, 171, 211)},
    "dream": {"bg": (13, 12, 31), "mid": (35, 29, 67), "accent": (176, 152, 255), "secondary": (113, 202, 230)},
}
ACCENTS = {
    "ocean": (75, 190, 245), "violet": (177, 130, 255), "amber": (242, 171, 84),
    "emerald": (104, 207, 150), "rose": (244, 112, 166), "mono": (215, 225, 235),
}


def _has_arabic(text: str) -> bool:
    return any("\u0600" <= char <= "\u06ff" for char in text)


def _has_latin(text: str) -> bool:
    return any(("a" <= char.lower() <= "z") for char in text)


def _font(size: int, bold: bool = False, arabic: bool = False, mixed: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    noto = "/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf" if bold else "/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf"
    dejavu = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    liberation = "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"
    # Noto Arabic is preferred for Persian-only glyph runs. It intentionally
    # does not contain Latin letters, so mixed Persian/English strings must use
    # a font with both scripts to prevent tofu boxes in generated posters.
    if mixed:
        candidates = [dejavu, liberation, noto]
    else:
        candidates = [noto, dejavu, liberation] if arabic else [dejavu, liberation, noto]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size=size)
    return ImageFont.load_default()


def _shape_text(text: str) -> str:
    if any("\u0600" <= char <= "\u06ff" for char in text):
        try:
            import arabic_reshaper
            from bidi.algorithm import get_display
            return get_display(arabic_reshaper.reshape(text))
        except ImportError:
            return text
    return text


def _hex_to_rgb(value: str | None) -> tuple[int, int, int] | None:
    if not value:
        return None
    try:
        return tuple(int(value[i:i + 2], 16) for i in (1, 3, 5))  # type: ignore[return-value]
    except (ValueError, IndexError):
        return None


def _palette(request: VideoRequest) -> dict[str, tuple[int, int, int]]:
    palette = dict(STYLE_PALETTES[request.style])
    if request.accent_palette != "auto":
        palette["accent"] = ACCENTS[request.accent_palette]
    custom = _hex_to_rgb(request.accent_color)
    if custom:
        palette["accent"] = custom
    return palette


def _fit_font(draw: ImageDraw.ImageDraw, text: str, max_width: int, start_size: int, bold: bool = True):
    shaped = _shape_text(text)
    arabic = _has_arabic(text)
    mixed = arabic and _has_latin(text)
    size = start_size
    while size > 14:
        font = _font(size, bold=bold, arabic=arabic, mixed=mixed)
        box = draw.textbbox((0, 0), shaped, font=font, stroke_width=0)
        if box[2] - box[0] <= max_width:
            return shaped, font
        size -= 2
    return shaped, _font(14, bold=bold, arabic=arabic, mixed=mixed)


def _wrap_title(draw: ImageDraw.ImageDraw, text: str, max_width: int, start_size: int, max_lines: int = 2):
    words = text.split()
    if not words:
        return "", _font(start_size, True)
    arabic = _has_arabic(text)
    mixed = arabic and _has_latin(text)
    for size in range(start_size, 15, -2):
        font = _font(size, True, arabic=arabic, mixed=mixed)
        lines: list[str] = []
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip()
            shaped = _shape_text(candidate)
            if current and draw.textbbox((0, 0), shaped, font=font)[2] > max_width:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)
        if len(lines) <= max_lines and all(draw.textbbox((0, 0), _shape_text(line), font=font)[2] <= max_width for line in lines):
            return "\n".join(_shape_text(line) for line in lines), font
    return _shape_text(text), _font(16, True, arabic=arabic, mixed=mixed)


def _ease(value: float) -> float:
    """Quintic smootherstep with zero velocity/acceleration at endpoints."""
    value = min(1.0, max(0.0, value))
    return value * value * value * (value * (value * 6.0 - 15.0) + 10.0)


def _ease_out_cubic(value: float) -> float:
    value = min(1.0, max(0.0, value))
    return 1.0 - (1.0 - value) ** 3


@lru_cache(maxsize=12)
def _coordinate_fields(width: int, height: int):
    """Cache normalized coordinate grids to reduce per-frame CPU allocations."""
    x = np.linspace(0.0, 1.0, width, dtype=np.float32)[None, :]
    y = np.linspace(0.0, 1.0, height, dtype=np.float32)[:, None]
    grad = np.clip(y * 0.78 + x * 0.12, 0.0, 1.0)[..., None]
    return x, y, grad


def _scene_for_time(plan: VideoPlan, time_seconds: float):
    cursor = 0.0
    for index, scene in enumerate(plan.scenes):
        end = cursor + scene.duration
        if time_seconds < end or index == len(plan.scenes) - 1:
            return index, scene, cursor, end
        cursor = end
    scene = plan.scenes[-1]
    return len(plan.scenes) - 1, scene, 0.0, float(scene.duration)


def _draw_glow(image: Image.Image, center: tuple[int, int], radius: int, accent: tuple[int, int, int], alpha: int = 65) -> Image.Image:
    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer, "RGBA")
    x, y = center
    draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill=(*accent, alpha))
    layer = layer.filter(ImageFilter.GaussianBlur(max(8, radius // 2)))
    return Image.alpha_composite(image.convert("RGBA"), layer)


@lru_cache(maxsize=32)
def _particle_field(prompt: str, width: int, height: int, count: int):
    seed = int.from_bytes(hashlib.sha256(prompt.encode("utf-8")).digest()[:4], "big")
    rng = np.random.default_rng(seed)
    return (
        rng.uniform(0, width, count),
        rng.uniform(0, height, count),
        rng.uniform(5, 28, count),
        rng.uniform(0, math.tau, count),
    )


def _render_keyframe_background(
    source: Image.Image,
    width: int,
    height: int,
    scene,
    progress: float,
    t: float,
    scene_index: int,
    request: VideoRequest,
    palette: dict[str, tuple[int, int, int]],
) -> Image.Image:
    """Animate an AI-generated scene still with a bounded virtual camera and grade."""
    progress_eased = _ease(progress)
    zoom = scene.scale_from + (scene.scale_to - scene.scale_from) * progress_eased
    intensity = {"low": 0.60, "normal": 1.0, "high": 1.28}[request.motion_intensity]
    phase = progress * math.tau
    dx = dy = 0.0
    if scene.motion in {"pan", "sweep"}:
        dx = (progress_eased - 0.5) * 0.12
    elif scene.motion in {"drift", "float"}:
        dx = 0.025 * math.sin(t * 0.38 * intensity + scene_index)
        dy = 0.018 * math.cos(t * 0.31 * intensity + scene_index * 0.4)
    elif scene.motion == "orbit":
        dx = 0.032 * math.cos(phase * 0.72) * intensity
        dy = 0.022 * math.sin(phase * 0.72) * intensity
    elif scene.motion == "rise":
        dy = -0.075 * progress_eased
    elif scene.motion == "parallax":
        dx = 0.035 * math.sin(t * 0.19 * intensity + scene_index)
        dy = 0.018 * math.cos(t * 0.17 * intensity)
    elif scene.motion == "ken_burns":
        dx = 0.055 * (progress_eased - 0.5)
        dy = -0.035 * (progress_eased - 0.5)
    elif scene.motion == "pulse":
        zoom *= 1.0 + 0.018 * math.sin(phase * 2.0) * intensity
    elif scene.motion == "reveal":
        zoom *= 0.96 + 0.08 * _ease_out_cubic(min(1.0, progress * 1.5))
    elif scene.motion == "elastic":
        zoom *= 1.0 + 0.025 * math.sin(progress_eased * math.pi) * (1.0 - progress_eased)
    elif scene.motion == "slow_zoom":
        zoom *= 0.99 + 0.035 * progress_eased

    # Overscan gives the camera room to pan without exposing empty edges.
    overscan = 1.48
    canvas = ImageOps.fit(
        source.convert("RGB"),
        (max(width + 8, int(width * overscan)), max(height + 8, int(height * overscan))),
        method=Image.Resampling.LANCZOS,
        centering=(scene.focal_x, scene.focal_y),
    )
    crop_w = min(canvas.width, max(width, int(width * 1.24 / max(0.78, zoom))))
    crop_h = min(canvas.height, max(height, int(height * 1.24 / max(0.78, zoom))))
    cx = canvas.width * (0.5 + dx)
    cy = canvas.height * (0.5 + dy)
    left = int(min(canvas.width - crop_w, max(0, cx - crop_w / 2)))
    top = int(min(canvas.height - crop_h, max(0, cy - crop_h / 2)))
    frame = canvas.crop((left, top, left + crop_w, top + crop_h)).resize((width, height), Image.Resampling.LANCZOS)

    # Per-style grading keeps the generated asset inside the chosen art direction.
    saturation = {"minimal": 0.72, "documentary": 0.88, "retro": 0.90, "luxury": 0.78, "nature": 1.06, "cyberpunk": 1.20, "dream": 1.08}.get(request.style, 1.0)
    frame = ImageEnhance.Color(frame).enhance(saturation)
    frame = ImageEnhance.Contrast(frame).enhance(1.06 if request.style in {"cinematic", "cyberpunk"} else 1.025)
    frame = ImageEnhance.Sharpness(frame).enhance(1.08)

    # Soft palette glaze and vignette are composited in pixel space, not painted as a generic grid.
    arr = np.asarray(frame, dtype=np.float32)
    x, y, _ = _coordinate_fields(width, height)
    radius = ((x - 0.5) ** 2 + (y - 0.48) ** 2)
    vignette = np.clip(1.0 - np.maximum(0.0, radius - 0.12) * 0.58, 0.72, 1.0)[..., None]
    bottom = np.clip((y - 0.56) / 0.44, 0.0, 1.0)
    top = np.clip((0.22 - y) / 0.22, 0.0, 1.0)
    arr *= vignette
    arr *= (1.0 - bottom[..., None] * 0.24)
    arr *= (1.0 - top[..., None] * 0.07)
    tint = np.asarray(palette["accent"], dtype=np.float32)[None, None, :]
    tint_strength = 0.025 if request.style in {"minimal", "documentary"} else 0.042
    arr = arr * (1.0 - tint_strength) + tint * tint_strength
    # Fine, restrained film texture changes with time so the image does not feel frozen.
    grain = (np.sin(x * 997.0 + t * 13.0) * np.cos(y * 811.0 - t * 7.0) * 0.75)[..., None]
    arr = np.clip(arr + grain, 0, 255).astype(np.uint8)
    return Image.fromarray(arr, mode="RGB").convert("RGBA")


def _draw_frame_core(width: int, height: int, frame_index: int, fps: int, request: VideoRequest, plan: VideoPlan, scene_images: dict[int, Image.Image] | None = None) -> np.ndarray:
    t = frame_index / fps
    scene_index, scene, scene_start, scene_end = _scene_for_time(plan, t)
    scene_progress = min(1.0, max(0.0, (t - scene_start) / max(0.001, scene.duration)))
    total_progress = min(1.0, t / max(1, request.duration))
    palette = _palette(request)
    bg = np.array(palette["bg"], dtype=np.float32)
    mid = np.array(palette["mid"], dtype=np.float32)
    accent = palette["accent"]
    secondary = palette["secondary"]

    scene_asset = (scene_images or {}).get(scene_index)
    if scene_asset is not None:
        image = _render_keyframe_background(scene_asset, width, height, scene, scene_progress, t, scene_index, request, palette)
    else:
        # Offline fallback: procedural atmosphere when no AI keyframe is available.
        x, y, grad = _coordinate_fields(width, height)
        field = bg[None, None, :] * (1.0 - grad) + mid[None, None, :] * grad
        cx = 0.50 + 0.12 * math.sin(t * 0.19)
        cy = 0.34 + 0.035 * math.cos(t * 0.24)
        radius = (x - cx) ** 2 + (y - cy) ** 2
        glow = np.exp(-radius * (12.0 if request.style in {"dream", "luxury"} else 18.0))[..., None]
        field = field + glow * np.array(accent, dtype=np.float32)[None, None, :] * 0.16
        texture = (np.sin((x * 2.6 + y * 1.7 + t * 0.09) * math.pi) * 1.8)[..., None]
        base = np.clip(field + texture, 0, 255).astype(np.uint8)
        image = Image.fromarray(base, mode="RGB").convert("RGBA")
    draw = ImageDraw.Draw(image, "RGBA")

    intensity = {"low": 0.58, "normal": 1.0, "high": 1.35}[request.motion_intensity]
    entrance = _ease(min(1.0, scene_progress * 2.8))

    if scene_asset is None and request.show_grid and request.style not in {"minimal", "nature", "luxury"}:
        grid_step = max(36, width // (16 if width > 700 else 12))
        drift = int((t * 12 * intensity) % grid_step)
        grid_alpha = 14 if request.style in {"documentary", "corporate"} else 21
        for gx in range(-grid_step, width + grid_step, grid_step):
            draw.line((gx - drift, 0, gx - drift, height), fill=(*secondary, grid_alpha), width=1)
        for gy in range(0, height + grid_step, grid_step):
            draw.line((0, gy, width, gy), fill=(*secondary, grid_alpha), width=1)

    # Art-direction overlays make the selected styles structurally distinct,
    # not just different color filters.
    if scene_asset is None and request.style == "retro":
        scan_step = max(5, height // 180)
        for sy in range(0, height, scan_step):
            draw.line((0, sy, width, sy), fill=(*secondary, 13), width=1)
        side = int(width * 0.055)
        draw.line((side, 0, side, height), fill=(*accent, 55), width=2)
        draw.line((width-side, 0, width-side, height), fill=(*accent, 55), width=2)
    elif scene_asset is None and request.style == "cyberpunk":
        corner = int(width * 0.10)
        edge = int(height * 0.12)
        for x0, direction in ((corner, 1), (width-corner, -1)):
            draw.line((x0, edge, x0 + direction * corner * 0.48, edge), fill=(*accent, 125), width=2)
            draw.line((x0, edge, x0, edge + int(height * 0.045)), fill=(*accent, 125), width=2)
        glitch_y = int(height * (0.20 + 0.20 * (0.5 + 0.5 * math.sin(t * 1.7))))
        draw.line((int(width*0.12), glitch_y, int(width*0.35), glitch_y), fill=(*secondary, 95), width=2)
    elif scene_asset is None and request.style == "luxury":
        inset = int(width * 0.055)
        draw.rounded_rectangle((inset, int(height*0.035), width-inset, int(height*0.965)), radius=max(8, width//65), outline=(*accent, 75), width=1)
        for sign in (-1, 1):
            x0 = inset + 15 if sign == 1 else width-inset-15
            draw.ellipse((x0-3, int(height*.16)-3, x0+3, int(height*.16)+3), fill=(*accent, 170))
    elif scene_asset is None and request.style == "nature":
        for wave_index in range(4):
            wave_points = []
            for point_index in range(32):
                px = int(width * point_index / 31)
                py = int(height * (0.20 + wave_index*0.035) + math.sin(point_index*0.23 + t*0.32*intensity + wave_index)*height*0.018)
                wave_points.append((px, py))
            draw.line(wave_points, fill=(*accent, 36 + wave_index*8), width=max(1, width//600))
    elif scene_asset is None and request.style == "corporate":
        panel_y = int(height * 0.17)
        for card_index in range(3):
            x0 = int(width * (0.13 + card_index * 0.25))
            x1 = x0 + int(width * 0.18)
            draw.rounded_rectangle((x0, panel_y, x1, panel_y + int(height*0.07)), radius=7, outline=(*secondary, 55), fill=(*secondary, 10), width=1)
            draw.rounded_rectangle((x0+9, panel_y+11, x0+int(width*0.08), panel_y+15), radius=2, fill=(*accent, 125))
            draw.rounded_rectangle((x0+9, panel_y+23, x1-10, panel_y+26), radius=2, fill=(*secondary, 65))
    elif scene_asset is None and request.style == "documentary":
        rail_x = int(width * 0.09)
        draw.line((rail_x, int(height*0.18), rail_x, int(height*0.42)), fill=(*accent, 75), width=1)
        for tick in range(7):
            yy = int(height * (0.19 + tick*0.035))
            draw.line((rail_x, yy, rail_x + (14 if tick % 2 == 0 else 7), yy), fill=(*accent, 100), width=1)
    elif scene_asset is None and request.style == "dream":
        for ring_i in range(3):
            rx = int(width * (0.22 + ring_i*0.09))
            ry = int(height * (0.045 + ring_i*0.02))
            y0 = int(height * 0.31 + math.sin(t*0.18 + ring_i)*height*0.012)
            draw.ellipse((width//2-rx, y0-ry, width//2+rx, y0+ry), outline=(*secondary, 32 + ring_i*8), width=1)
    elif scene_asset is None and request.style == "minimal":
        inset = int(width * 0.075)
        draw.line((inset, int(height*0.16), width-inset, int(height*0.16)), fill=(*secondary, 32), width=1)
        draw.line((inset, int(height*0.84), width-inset, int(height*0.84)), fill=(*secondary, 32), width=1)

    # Scene motion presets alter the focal composition, not only the title position.
    motion_phase = scene_progress * math.tau
    focus_x, focus_y = scene.focal_x, scene.focal_y
    progress_eased = _ease(scene_progress)
    zoom = scene.scale_from + (scene.scale_to - scene.scale_from) * progress_eased
    if scene.motion == "slow_zoom":
        zoom *= 0.985 + 0.045 * progress_eased
    elif scene.motion == "pan":
        focus_x += 0.11 * (progress_eased - 0.5)
    elif scene.motion == "pulse":
        zoom *= 1.0 + 0.022 * math.sin(motion_phase * 2.0) * intensity
    elif scene.motion == "reveal":
        zoom *= 0.78 + 0.22 * _ease_out_cubic(min(1.0, scene_progress * 1.7))
    elif scene.motion in {"drift", "float"}:
        focus_x += 0.022 * math.sin(t * 0.43 * intensity + scene_index)
        focus_y += 0.014 * math.cos(t * 0.37 * intensity + scene_index * 0.7)
    elif scene.motion == "orbit":
        focus_x += 0.033 * math.cos(motion_phase * 0.85) * intensity
        focus_y += 0.025 * math.sin(motion_phase * 0.85) * intensity
    elif scene.motion == "rise":
        focus_y -= 0.055 * progress_eased
    elif scene.motion == "parallax":
        focus_x += 0.032 * math.sin(t * 0.19 * intensity + scene_index)
        focus_y += 0.016 * math.cos(t * 0.17 * intensity)
    elif scene.motion == "sweep":
        focus_x += 0.12 * (progress_eased - 0.5)
        zoom *= 0.99 + 0.035 * progress_eased
    elif scene.motion == "ken_burns":
        focus_x += 0.045 * (progress_eased - 0.5)
        focus_y -= 0.028 * (progress_eased - 0.5)
    elif scene.motion == "elastic":
        overshoot = math.sin(progress_eased * math.pi) * (1.0 - progress_eased)
        zoom *= 1.0 + 0.035 * overshoot
    composition_offsets = {
        "center": (0.0, 0.0), "upper": (0.0, -0.05), "lower": (0.0, 0.07),
        "left": (-0.08, 0.015), "right": (0.08, 0.015), "split": (-0.045, 0.0),
        "diagonal": (0.055, -0.035), "fullbleed": (0.0, 0.0),
    }
    ox, oy = composition_offsets.get(scene.composition, (0.0, 0.0))
    focus_x = min(0.92, max(0.08, focus_x + ox))
    focus_y = min(0.88, max(0.08, focus_y + oy))
    center_x = int(width * focus_x)
    center_y = int(height * focus_y)
    ring_radius = int(min(width, height) * (0.145 * zoom + 0.008 * math.sin(t * 0.7 * intensity)))
    # Semantic motif engine. The planner selects a distinct geometry language for each scene.
    motif = scene.motif
    if motif == "auto":
        motif = {"data": "waveform", "technology": "network", "quote": "typography", "abstract": "ribbon", "intro": "radial", "outro": "constellation", "process": "timeline", "detail": "architecture"}.get(scene.kind, "orbit")
    # A generic orbit is no longer stamped onto every shot. AI keyframes receive only
    # motif-specific accents; the procedural fallback retains its geometric vocabulary.
    if scene_asset is None or motif in {"orbit", "concentric", "radial", "constellation"}:
        ring_count = (2 if request.style == "minimal" else 4) if scene_asset is None else 2
        for ring in range(ring_count):
            r = ring_radius + ring * max(15, width // 34)
            alpha = max(8, int((48 - ring * 8) * intensity * (0.42 if scene_asset is not None else 1.0)))
            draw.ellipse((center_x - r, center_y - r, center_x + r, center_y + r), outline=(*accent, alpha), width=max(1, width // 600))

    if request.show_particles:
        count = ({"minimal": 7, "standard": 16, "rich": 28} if scene_asset is not None else {"minimal": 28, "standard": 68, "rich": 118})[request.text_density]
        pxs, pys, base_speeds, phases = _particle_field(request.prompt, width, height, count)
        speeds = base_speeds * intensity
        for px, py, speed, phase in zip(pxs, pys, speeds, phases):
            yy = (py - t * speed) % height
            xx = px + math.sin(t * 0.4 + phase) * 8 * intensity
            alpha = int(28 + 44 * (0.5 + 0.5 * math.sin(t * 0.7 + phase)))
            r = 1 if width < 700 else 2
            draw.ellipse((xx-r, yy-r, xx+r, yy+r), fill=(*accent, alpha))

    mx, my = center_x, center_y
    line_w = max(1, width // (520 if request.render_quality in {"high", "ultra"} else 420))
    detail = max(1, min(4, scene.detail_level))
    if scene_asset is None and motif in {"network", "nodes"}:
        node_count = 7 + detail * 3
        positions = []
        for i in range(node_count):
            angle = math.tau * i / node_count + 0.18 * math.sin(t * 0.21 + i)
            radius = min(width, height) * (0.16 + 0.015 * (i % 3))
            positions.append((int(mx + math.cos(angle) * radius), int(my + math.sin(angle) * radius * 0.72)))
        for i, (ax, ay) in enumerate(positions):
            for bx, by in positions[i+1:]:
                distance = math.hypot(ax-bx, ay-by)
                if distance < min(width, height) * 0.24:
                    alpha = max(14, int(105 * (1-distance/(min(width,height)*0.34))))
                    draw.line((ax, ay, bx, by), fill=(*secondary, alpha), width=line_w)
        for i, (px, py) in enumerate(positions):
            r = max(3, int(width * (0.004 + (i % 3) * 0.001)))
            pulse = 0.5 + 0.5 * math.sin(t * 1.2 + i * 1.7)
            draw.ellipse((px-r*2, py-r*2, px+r*2, py+r*2), fill=(*accent, int(18 + 26*pulse)))
            draw.ellipse((px-r, py-r, px+r, py+r), fill=(*accent, int(145 + 80*pulse)), outline=(245,250,255,120), width=1)
    elif scene_asset is None and motif in {"waveform", "flow", "ribbon"}:
        for lane in range(2 + detail):
            points=[]
            base_y = my + (lane - (1+detail)/2) * height * 0.035
            amplitude = height * (0.025 + lane * 0.007)
            for k in range(72):
                u=k/71
                px=int(width*(0.10+0.80*u))
                wave=math.sin(u*math.tau*(1.2+lane*0.12)+t*0.72*intensity+lane*0.78)
                envelope=0.45+0.55*math.sin(math.pi*u)
                points.append((px,int(base_y+wave*amplitude*envelope)))
            color = accent if lane % 2 == 0 else secondary
            draw.line(points, fill=(*color, max(28,118-lane*16)), width=max(1,line_w+(1 if lane==0 else 0)), joint="curve")
    elif scene_asset is None and motif in {"bars", "timeline"}:
        left,right=int(width*.12),int(width*.88)
        count=7 if motif=="bars" else 6
        for i in range(count):
            u=i/max(1,count-1)
            phase=_ease(min(1.0,max(0.0,scene_progress*1.5-u*.45)))
            x0=left+int((right-left)*u)
            if motif=="bars":
                bh=int(height*(.07+.17*(.5+.5*math.sin(i*1.37+scene_index)))*phase)
                y0=my+int(height*.14)
                draw.rounded_rectangle((x0-5,y0-bh,x0+5,y0),radius=5,fill=(*accent,170),outline=(*secondary,90),width=1)
            else:
                y0=my+int((i%2-.5)*height*.10)
                draw.ellipse((x0-5,y0-5,x0+5,y0+5),fill=(*accent,int(90+120*phase)))
                if i<count-1:
                    nx=left+int((right-left)*(i+1)/max(1,count-1))
                    draw.line((x0,y0,nx,y0),fill=(*secondary,90),width=line_w)
    elif scene_asset is None and motif in {"orbit", "concentric", "radial", "constellation"}:
        for ring in range(3+detail):
            angle=t*(9 if request.motion_intensity=="high" else 4)*(-1 if ring%2 else 1)+ring*29
            rx=int(min(width,height)*(.105+ring*.052))
            ry=int(rx*(.48 if request.style in {"dream","luxury"} else .72))
            box=(mx-rx,my-ry,mx+rx,my+ry)
            color=accent if ring%2==0 else secondary
            draw.arc(box,start=int(angle),end=int(angle+210+30*math.sin(t*.3+ring)),fill=(*color,max(25,110-ring*12)),width=max(1,line_w))
            dx=mx+math.cos(math.radians(angle))*rx
            dy=my+math.sin(math.radians(angle))*ry
            rr=max(2,width//260)
            draw.ellipse((dx-rr,dy-rr,dx+rr,dy+rr),fill=(*accent,210))
    elif scene_asset is None and motif in {"architecture", "topography", "contour", "maplines"}:
        for layer in range(3+detail):
            pts=[]
            for k in range(64):
                u=k/63
                px=int(width*(.07+.86*u))
                wave=math.sin(u*math.tau*1.35+t*.22*intensity+layer*.48)
                wave2=math.cos(u*math.tau*.62-t*.18+layer)
                py=int(my+(layer-(2+detail)/2)*height*.036+wave*height*.025+wave2*height*.014)
                pts.append((px,py))
            color=accent if layer%2==0 else secondary
            draw.line(pts,fill=(*color,max(20,100-layer*10)),width=line_w)
    elif scene_asset is None and motif == "spiral":
        points=[]
        for k in range(220):
            u=k/219
            angle=u*math.tau*(2.3+detail*.2)+t*.38
            radius=min(width,height)*(.015+u*.22)
            points.append((int(mx+math.cos(angle)*radius),int(my+math.sin(angle)*radius*.72)))
        draw.line(points,fill=(*accent,175),width=max(1,line_w+1),joint="curve")
    elif scene_asset is None and motif == "typography":
        qfont=_font(max(24,int(width*.18)),True,arabic=False)
        draw.text((int(width*.10),int(my-height*.12)),"01",font=qfont,fill=(*accent,28))
        draw.line((int(width*.15),my+int(height*.06),int(width*.85),my+int(height*.06)),fill=(*accent,110),width=max(2,line_w))
        for k in range(4):
            y0=my+int(height*(.10+.035*k))
            draw.rounded_rectangle((int(width*.18),y0,int(width*(.42+.08*(k%2))),y0+max(2,width//180)),radius=3,fill=(*secondary,80-k*12))
    elif scene_asset is None and motif == "particles":
        pxs,pys,speeds,phases=_particle_field(request.prompt+str(scene_index),width,height,90+detail*20)
        for px,py,speed,phase in zip(pxs,pys,speeds,phases):
            xx=(px+math.sin(t*.34+phase)*width*.025)%width
            yy=(py-t*speed*.65)%height
            r=max(1,int(width*.0025))
            draw.ellipse((xx-r,yy-r,xx+r,yy+r),fill=(*accent,int(75+75*(.5+.5*math.sin(t+phase)))))

    # A restrained bloom layer adds depth without sacrificing edge sharpness.
    if request.style in {"cinematic", "cyberpunk", "dream", "luxury"} and (scene_asset is None or motif in {"radial", "orbit", "concentric"}):
        image = _draw_glow(image, (center_x, center_y), max(26, ring_radius // 2), accent, 13 if scene_asset is not None else (20 if request.motion_intensity == "low" else 31))
        draw = ImageDraw.Draw(image, "RGBA")

    # Apply the virtual camera transform to the complete graphic scene, not just rings.
    # The affine map keeps the selected focal point stable while zooming smoothly.
    if scene_asset is None and abs(zoom - 1.0) > 0.002:
        inv_zoom = 1.0 / max(0.70, min(1.40, zoom))
        image = image.transform(
            (width, height), Image.Transform.AFFINE,
            (inv_zoom, 0, center_x - center_x * inv_zoom,
             0, inv_zoom, center_y - center_y * inv_zoom),
            resample=Image.Resampling.BICUBIC,
            fillcolor=(*tuple(int(v) for v in bg), 255),
        )
        draw = ImageDraw.Draw(image, "RGBA")

    # Editorial typography now follows scene composition instead of a fixed center-bottom template.
    margin = int(width * 0.095)
    title = scene.title or plan.project_title
    composition = scene.composition
    title_y = int(height * 0.66)
    align = "center"
    if composition == "upper":
        title_y, align = int(height * 0.22), "center"
    elif composition == "lower":
        title_y, align = int(height * 0.73), "center"
    elif composition == "left":
        title_y, align = int(height * 0.66), "left"
    elif composition == "right":
        title_y, align = int(height * 0.62), "right"
    elif composition == "diagonal":
        title_y, align = int(height * 0.72), "left"
    elif composition == "split":
        title_y, align = int(height * 0.58), "right"
    movement = int(height * 0.042 * (1 - entrance))
    if scene.motion in {"reveal", "rise"}:
        title_y += movement
    elif scene.motion == "slow_zoom":
        title_y += int(movement * 0.45)
    elif scene.motion == "drift":
        title_y += int(math.sin(t * 1.1 * intensity) * height * 0.006)

    title_width = int(width * (0.70 if composition in {"left", "right", "split"} else 0.82))
    title_text, title_font = _wrap_title(draw, title, title_width, max(28, int(width * 0.066)), max_lines=2)
    title_box = draw.multiline_textbbox((0, 0), title_text, font=title_font, spacing=max(4, int(title_font.size * 0.18)), align=align, stroke_width=0)
    title_height = title_box[3] - title_box[1]
    rendered_title_width = title_box[2] - title_box[0]
    if align == "center":
        title_x = (width - rendered_title_width) // 2
    elif align == "right":
        title_x = width - margin - rendered_title_width
    else:
        title_x = margin

    sub_text = ""
    sub_font = None
    sub_height = 0
    sub_width = 0
    if scene.subtitle and request.text_density != "minimal":
        sub_text, sub_font = _fit_font(draw, scene.subtitle, title_width, max(16, int(width * 0.026)), False)
        sub_box = draw.textbbox((0, 0), sub_text, font=sub_font)
        sub_width = sub_box[2] - sub_box[0]
        sub_height = sub_box[3] - sub_box[1]
    text_gap = int(height * 0.022) if sub_text else 0
    safe_top = int(height * 0.15)
    safe_bottom = int(height * (0.81 if request.text_density == "rich" else 0.85))
    title_y = max(safe_top, min(title_y, safe_bottom - title_height - sub_height - text_gap))
    title_alpha = int(250 * min(1.0, max(0.0, entrance)))

    # A restrained soft shadow and a short accent rule establish a clear typographic hierarchy.
    draw.multiline_text((title_x + 2, title_y + 3), title_text, font=title_font, fill=(0, 0, 0, int(115 * entrance)), spacing=max(4, int(title_font.size * 0.18)), align=align)
    draw.multiline_text((title_x, title_y), title_text, font=title_font, fill=(248, 250, 255, title_alpha), spacing=max(4, int(title_font.size * 0.18)), align=align, stroke_width=0)
    rule_width = max(34, int(width * 0.075))
    if align == "center":
        rule_x = (width - rule_width) // 2
    elif align == "right":
        rule_x = width - margin - rule_width
    else:
        rule_x = margin
    rule_y = title_y + title_height + max(7, int(height * 0.012))
    draw.rounded_rectangle((rule_x, rule_y, rule_x + rule_width, rule_y + max(2, width // 420)), radius=3, fill=(*accent, int(210 * entrance)))

    if sub_text and sub_font is not None:
        sub_y = rule_y + max(10, int(height * 0.018))
        if align == "center":
            sub_x = (width - sub_width) // 2
        elif align == "right":
            sub_x = width - margin - sub_width
        else:
            sub_x = margin
        draw.text((sub_x, sub_y), sub_text, font=sub_font, fill=(225, 232, 241, int(235 * entrance)))

    if request.include_branding and request.text_density != "minimal":
        brand = _shape_text(request.brand_label or "CINEFORGE STUDIO")
        brand_font = _font(max(13, int(width * 0.021)), bold=True, arabic=_has_arabic(request.brand_label))
        draw.text((margin, int(height * 0.055)), brand, font=brand_font, fill=(*secondary, 210))
        draw.rounded_rectangle((margin, int(height * 0.095), margin + max(32, int(width * 0.11)), int(height * 0.098)), radius=2, fill=(*accent, 180))

    if request.text_density == "rich":
        marker = f"{scene_index + 1:02d} / {len(plan.scenes):02d}"
        meta_font = _font(max(12, int(width * 0.018)), arabic=False)
        draw.text((margin, int(height * 0.14)), _shape_text(marker), font=meta_font, fill=(*secondary, 155))
        if scene.visual_note:
            note = scene.visual_note[:46]
            note_text, note_font = _fit_font(draw, note, width - 2 * margin, max(11, int(width * 0.015)), False)
            note_box = draw.textbbox((0, 0), note_text, font=note_font)
            draw.text(((width - (note_box[2] - note_box[0])) // 2, int(height * 0.86)), note_text, font=note_font, fill=(*secondary, 145))

    if request.show_progress:
        bar_y = int(height * 0.93)
        draw.rounded_rectangle((margin, bar_y, width - margin, bar_y + max(3, width // 280)), radius=3, fill=(*secondary, 52))
        draw.rounded_rectangle((margin, bar_y, margin + int((width - 2 * margin) * total_progress), bar_y + max(3, width // 280)), radius=3, fill=(*accent, 230))

    if scene.kind == "outro" and request.closing_text:
        closing, closing_font = _fit_font(draw, request.closing_text, width - 2 * margin, max(16, int(width * 0.034)), True)
        closing_box = draw.textbbox((0, 0), closing, font=closing_font)
        draw.text(((width - (closing_box[2] - closing_box[0])) // 2, int(height * 0.85)), closing, font=closing_font, fill=(*accent, 225))

    # Fade the complete frame at the very beginning and very end.
    fade_in = min(1.0, t / 0.65)
    fade_out = min(1.0, max(0.0, (request.duration - t) / 0.7))
    fade = min(fade_in, fade_out)
    if fade < 1:
        black = Image.new("RGBA", image.size, (0, 0, 0, 255))
        image = Image.blend(black, image, fade)
    return np.asarray(image.convert("RGB"), dtype=np.uint8)



def _draw_frame(width: int, height: int, frame_index: int, fps: int, request: VideoRequest, plan: VideoPlan, scene_images: dict[int, Image.Image] | None = None) -> np.ndarray:
    """Render a frame and blend short, eased scene transitions."""
    t = frame_index / fps
    current_index, current_scene, scene_start, _ = _scene_for_time(plan, t)
    current = _draw_frame_core(width, height, frame_index, fps, request, plan, scene_images)
    if current_index <= 0 or current_scene.transition == "cut":
        return current
    transition_seconds = min(0.65, max(0.22, current_scene.duration * 0.12))
    elapsed = t - scene_start
    if elapsed < 0 or elapsed >= transition_seconds:
        return current
    old_t = max(0.0, scene_start - transition_seconds + elapsed)
    old_frame_index = min(max(0, int(round(old_t * fps))), max(0, request.duration * fps - 1))
    previous = _draw_frame_core(width, height, old_frame_index, fps, request, plan, scene_images)
    progress = _ease(elapsed / transition_seconds)
    old_image = Image.fromarray(previous, mode="RGB")
    new_image = Image.fromarray(current, mode="RGB")
    transition = current_scene.transition
    if transition == "slide":
        # Move the incoming image from the right; canvas is filled by the outgoing image.
        canvas = old_image.copy()
        offset = int(width * (1.0 - progress))
        canvas.paste(new_image.crop((0, 0, width - offset, height)), (offset, 0))
        return np.asarray(canvas, dtype=np.uint8)
    if transition == "wipe":
        # Feathered vertical reveal avoids a harsh binary edge at any FPS.
        edge = int(width * progress)
        feather = max(2, int(width * 0.025))
        mask = np.zeros((height, width), dtype=np.float32)
        xs = np.arange(width, dtype=np.float32)[None, :]
        mask[:] = np.clip((edge - xs + feather) / (2.0 * feather), 0.0, 1.0)
        blended = np.asarray(old_image, dtype=np.float32) * (1.0-mask[..., None]) + np.asarray(new_image, dtype=np.float32) * mask[..., None]
        return np.clip(blended, 0, 255).astype(np.uint8)
    if transition == "lightleak":
        blended = Image.blend(old_image, new_image, progress)
        flare = Image.new("RGB", (width, height), (255, 204, 132))
        flare_alpha = int(48 * math.sin(math.pi * progress))
        return np.asarray(Image.blend(blended, flare, flare_alpha / 255.0), dtype=np.uint8)
    return np.asarray(Image.blend(old_image, new_image, progress), dtype=np.uint8)


def _probe_video(path: Path) -> dict:
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return {}
    completed = subprocess.run(
        [ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
        capture_output=True,
        text=True,
        timeout=30,
        check=True,
    )
    raw = json.loads(completed.stdout)
    streams = raw.get("streams", [])
    video = next((item for item in streams if item.get("codec_type") == "video"), None)
    audio = next((item for item in streams if item.get("codec_type") == "audio"), None)
    if not video:
        raise RuntimeError("کنترل کیفیت: جریان ویدیویی در MP4 پیدا نشد.")
    try:
        frame_count = int(video.get("nb_frames") or 0)
    except (TypeError, ValueError):
        frame_count = 0
    return {
        "video_codec": video.get("codec_name"),
        "audio_codec": audio.get("codec_name") if audio else None,
        "width": video.get("width"),
        "height": video.get("height"),
        "duration": float((raw.get("format") or {}).get("duration", 0) or 0),
        "frame_rate": video.get("avg_frame_rate") or video.get("r_frame_rate"),
        "frame_count": frame_count,
        "pixel_format": video.get("pix_fmt"),
        "has_audio": audio is not None,
    }


def render_video(request: VideoRequest, plan: VideoPlan, output_path: Path, on_progress: ProgressCallback | None = None, scene_assets: dict[int, Path] | None = None, asset_report: dict | None = None) -> dict:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("FFmpeg نصب نیست یا در PATH قرار ندارد.")

    width, height = request.dimensions()
    fps = request.fps
    total_frames = request.duration * fps
    output_path.parent.mkdir(parents=True, exist_ok=True)
    loaded_assets: dict[int, Image.Image] = {}
    for index, asset_path in (scene_assets or {}).items():
        try:
            with Image.open(asset_path) as source:
                source.load()
                loaded_assets[int(index)] = source.convert("RGB")
        except Exception as exc:
            # A damaged keyframe must not corrupt the whole render; it is reported.
            if asset_report is not None:
                asset_report.setdefault("warnings", []).append(f"تصویر صحنه {int(index)+1} قابل خواندن نبود: {type(exc).__name__}")

    # CRF defines visual quality; preset mainly trades encode time against file size.
    # Keep CPU use bounded in phone-managed cloud runners rather than oversubscribing
    # every virtual core. High quality therefore remains CRF 18 without a slow preset.
    crf, preset, threads = {
        "fast": (25, "ultrafast", 2),
        "balanced": (22, "veryfast", 2),
        "high": (18, "veryfast", 2),
        "ultra": (16, "fast", 2),
    }[request.render_quality]

    requested_music = request.music_style if request.music_style != "auto" else plan.music_mood
    music_style_used = infer_music_style(request.prompt + " " + plan.music_direction, requested_music)
    transition_events: list[float] = []
    scene_cursor = 0.0
    for scene_index, scene in enumerate(plan.scenes):
        if scene_index > 0 and scene.transition != "cut":
            transition_events.append(scene_cursor)
        scene_cursor += scene.duration
    sound_events = [event.model_dump() for event in plan.sound_events]
    # Director-scripted events take precedence. For older plans, derive restrained
    # whooshes from transitions as a compatible fallback.
    if sound_events:
        transition_events = []
    else:
        sound_events = [
            {"time_seconds": stamp, "kind": "whoosh", "intensity": 0.20, "duration": 0.55, "pan": (-0.25 if i % 2 else 0.25)}
            for i, stamp in enumerate(transition_events)
        ]
        transition_events = []

    with tempfile.TemporaryDirectory(prefix="cineforge-") as tmp_dir:
        audio_path = Path(tmp_dir) / "music.wav"
        audio_report = create_ambient_track(
            audio_path,
            request.duration,
            music_style_used,
            request.music_volume,
            tempo=request.music_tempo or plan.music_tempo_bpm,
            seed=request.music_seed if request.music_seed is not None else hashlib.sha256((request.prompt + plan.music_direction).encode("utf-8")).hexdigest()[:12],
            prompt=request.prompt + " " + plan.music_direction,
            transition_events=transition_events,
            energy_curve=plan.music_energy_curve,
            sound_events=sound_events,
        )
        voiceover_path = None
        voiceover_report = None
        if request.voiceover_text.strip():
            voiceover_path = Path(tmp_dir) / "voiceover.mp3"
            if on_progress:
                on_progress(3, "در حال تولید نریشن از سرویس گفتار NestAPI")
            voiceover_report = generate_nestapi_voiceover(
                voiceover_path,
                request.voiceover_text,
                request.voiceover_voice,
            )

        command = [
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
            "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{width}x{height}",
            "-r", str(fps), "-i", "pipe:0",
            "-i", str(audio_path),
        ]
        if voiceover_path:
            # Voiceover side-chain ducks the music gently, then is mixed back in.
            # This keeps speech intelligible without manually flattening the score.
            command += [
                "-i", str(voiceover_path),
                "-filter_complex",
                "[1:a]volume=0.82[bg];[2:a]aresample=44100,volume=1.0[vo];"
                "[bg][vo]sidechaincompress=threshold=0.025:ratio=5:attack=25:release=320[duckbg];"
                "[duckbg][vo]amix=inputs=2:duration=longest:normalize=0[aout]",
                "-map", "0:v:0", "-map", "[aout]",
            ]
        else:
            command += ["-map", "0:v:0", "-map", "1:a:0"]
        command += [
            "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
            "-threads", str(threads), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
            "-t", str(request.duration), "-shortest", "-movflags", "+faststart", str(output_path),
        ]
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        try:
            assert process.stdin is not None
            for frame_index in range(total_frames):
                frame = _draw_frame(width, height, frame_index, fps, request, plan, loaded_assets)
                process.stdin.write(frame.tobytes())
                if on_progress and (frame_index % max(1, fps // 2) == 0 or frame_index == total_frames - 1):
                    percent = int((frame_index + 1) * 95 / total_frames)
                    on_progress(percent, f"در حال ساخت فریم {frame_index + 1:,} از {total_frames:,}")
            process.stdin.close()
            stderr = process.stderr.read().decode("utf-8", errors="replace") if process.stderr else ""
            code = process.wait(timeout=max(300, request.duration * 12))
            if code != 0:
                raise RuntimeError(f"FFmpeg خطا داد: {stderr[-1200:]}")
        except Exception:
            if process.poll() is None:
                process.kill()
            process.wait()
            raise

    if not output_path.exists() or output_path.stat().st_size < 1000:
        raise RuntimeError("فایل خروجی ساخته نشد یا ناقص است.")

    poster_path = output_path.with_suffix(".jpg")
    poster_frame = _draw_frame(width, height, min(total_frames - 1, fps), fps, request, plan, loaded_assets)
    Image.fromarray(poster_frame, mode="RGB").save(poster_path, format="JPEG", quality=88, optimize=True)

    probe = _probe_video(output_path)
    if probe:
        if probe.get("width") != width or probe.get("height") != height:
            raise RuntimeError("ممیزی نهایی: ابعاد خروجی با تنظیمات پروژه برابر نیست.")
        if abs(float(probe.get("duration", 0)) - request.duration) > max(0.20, 1 / fps):
            raise RuntimeError("ممیزی نهایی: مدت MP4 با زمان درخواستی اختلاف دارد.")
        if probe.get("video_codec") != "h264":
            raise RuntimeError("ممیزی نهایی: کدک تصویر خروجی H.264 نیست.")
        if probe.get("audio_codec") not in {"aac", None}:
            raise RuntimeError("ممیزی نهایی: کدک صوتی خروجی AAC نیست.")
    effective = probe or {
        "width": width, "height": height, "duration": request.duration,
        "video_codec": "h264", "audio_codec": "aac", "has_audio": request.music_style != "none"
    }
    quality_report = audit_render_metadata(request, effective)
    if not quality_report["passed"]:
        raise RuntimeError("ممیزی خروجی ناموفق بود: " + "؛ ".join(quality_report["issues"]))

    if on_progress:
        on_progress(100, "رندر، صداگذاری، ممیزی و کنترل کیفیت کامل شد.")
    return {
        "path": str(output_path),
        "poster_path": str(poster_path),
        "bytes": output_path.stat().st_size,
        "width": width,
        "height": height,
        "fps": fps,
        "duration": request.duration,
        "frames": total_frames,
        "style": request.style,
        "render_quality": request.render_quality,
        "music_style": music_style_used,
        "music_report": audio_report,
        "music_direction": plan.music_direction,
        "music_sound_design_notes": plan.sound_design_notes,
        "voiceover_enabled": bool(request.voiceover_text.strip()),
        "voiceover_report": voiceover_report,
        "video_codec": effective.get("video_codec"),
        "audio_codec": effective.get("audio_codec"),
        "has_audio": effective.get("has_audio", False),
        "quality_report": quality_report,
        "visual_engine_requested": request.visual_engine,
        "visual_engine_used": (
            "ai_keyframes" if len(loaded_assets) == len(plan.scenes)
            else "ai_keyframes_mixed" if loaded_assets
            else "procedural_fallback"
        ),
        "ai_keyframes_loaded": len(loaded_assets),
        "scene_count": len(plan.scenes),
        "asset_report": asset_report or {},
        "probe": probe,
    }
