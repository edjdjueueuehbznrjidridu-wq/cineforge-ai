"""Persistent project/version/message storage and encrypted provider secrets."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from .config import DATA_DIR, DB_PATH

_lock = threading.RLock()
_fernet: Fernet | None = None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH, timeout=20)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=20000")
    return connection


def init_storage() -> None:
    with _lock, _connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS projects (
          project_id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          brief TEXT NOT NULL,
          request_json TEXT NOT NULL,
          latest_plan_json TEXT,
          latest_audit_json TEXT,
          latest_output TEXT,
          provider_context_json TEXT NOT NULL DEFAULT '{}',
          version_number INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS versions (
          version_id TEXT PRIMARY KEY,
          project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
          version_number INTEGER NOT NULL,
          user_instruction TEXT NOT NULL,
          request_json TEXT NOT NULL,
          plan_json TEXT NOT NULL,
          audit_json TEXT NOT NULL,
          output_path TEXT,
          metadata_json TEXT,
          created_at TEXT NOT NULL,
          UNIQUE(project_id, version_number)
        );
        CREATE TABLE IF NOT EXISTS project_messages (
          message_id INTEGER PRIMARY KEY AUTOINCREMENT,
          project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
          role TEXT NOT NULL CHECK(role IN ('user','assistant','system')),
          content TEXT NOT NULL,
          version_number INTEGER,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        """)
        columns = {row["name"] for row in db.execute("PRAGMA table_info(projects)").fetchall()}
        if "provider_context_json" not in columns:
            db.execute("ALTER TABLE projects ADD COLUMN provider_context_json TEXT NOT NULL DEFAULT '{}'")
        db.executescript("""
        CREATE INDEX IF NOT EXISTS idx_projects_updated ON projects(updated_at DESC);
        CREATE INDEX IF NOT EXISTS idx_versions_project ON versions(project_id, version_number DESC);
        CREATE INDEX IF NOT EXISTS idx_messages_project ON project_messages(project_id, message_id);
        """)


def _cipher() -> Fernet:
    global _fernet
    if _fernet is not None:
        return _fernet
    env_key = os.getenv("CINEFORGE_MASTER_KEY", "").strip()
    key_path = DATA_DIR / ".secret.key"
    if env_key:
        key = env_key.encode("ascii")
    else:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if key_path.exists():
            key = key_path.read_bytes().strip()
        else:
            key = Fernet.generate_key()
            key_path.write_bytes(key)
            try:
                key_path.chmod(0o600)
            except OSError:
                pass
    _fernet = Fernet(key)
    return _fernet


def save_provider_settings(provider: str, nestapi_model: str, gemini_model: str, api_key: str | None) -> None:
    payload: dict[str, Any] = {
        "provider": provider,
        "nestapi_model": nestapi_model,
        "gemini_model": gemini_model,
    }
    if api_key is not None:
        payload["gemini_key_enc"] = _cipher().encrypt(api_key.encode("utf-8")).decode("ascii") if api_key else ""
    with _lock, _connect() as db:
        for key, value in payload.items():
            db.execute(
                "INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                (key, json.dumps(value), utc_now()),
            )


def get_provider_settings() -> dict[str, Any]:
    with _connect() as db:
        rows = db.execute("SELECT key,value FROM settings WHERE key IN ('provider','nestapi_model','gemini_model','gemini_key_enc')").fetchall()
    values = {row["key"]: json.loads(row["value"]) for row in rows}
    encrypted = values.get("gemini_key_enc", "")
    api_key = ""
    if encrypted:
        try:
            api_key = _cipher().decrypt(encrypted.encode("ascii")).decode("utf-8")
        except (InvalidToken, ValueError):
            api_key = ""
    return {
        "provider": values.get("provider", "nestapi"),
        "nestapi_model": values.get("nestapi_model", "gpt5"),
        "gemini_model": values.get("gemini_model", "gemini-3.8-flash"),
        "gemini_api_key": api_key,
        "gemini_configured": bool(api_key),
    }


def create_project(brief: str, request: dict, title: str = "پروژه جدید") -> str:
    project_id = uuid.uuid4().hex[:16]
    now = utc_now()
    with _lock, _connect() as db:
        db.execute(
            "INSERT INTO projects(project_id,title,brief,request_json,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            (project_id, title, brief, json.dumps(request, ensure_ascii=False), now, now),
        )
        db.execute(
            "INSERT INTO project_messages(project_id,role,content,created_at) VALUES(?,?,?,?)",
            (project_id, "user", brief, now),
        )
    return project_id


def save_draft(project_id: str, brief: str, request: dict, plan: dict, audit: dict) -> None:
    now = utc_now()
    with _lock, _connect() as db:
        db.execute(
            "UPDATE projects SET brief=?,request_json=?,latest_plan_json=?,latest_audit_json=?,title=?,updated_at=? WHERE project_id=?",
            (brief, json.dumps(request, ensure_ascii=False), json.dumps(plan, ensure_ascii=False), json.dumps(audit, ensure_ascii=False), plan.get("project_title") or "CineForge Project", now, project_id),
        )
        db.execute(
            "INSERT INTO project_messages(project_id,role,content,created_at) VALUES(?,?,?,?)",
            (project_id, "assistant", "سناریو طراحی شد و برای بازبینی آماده است.", now),
        )


def get_project_provider_context(project_id: str) -> dict[str, Any]:
    with _connect() as db:
        row = db.execute("SELECT provider_context_json FROM projects WHERE project_id=?", (project_id,)).fetchone()
    if not row or not row["provider_context_json"]:
        return {}
    try:
        value = json.loads(row["provider_context_json"])
        return value if isinstance(value, dict) else {}
    except (TypeError, json.JSONDecodeError):
        return {}


def save_project_provider_context(project_id: str, provider: str, context: dict[str, Any]) -> None:
    """Persist provider conversation handles, never API keys or raw credentials."""
    allowed = {key: value for key, value in context.items() if key in {"conversation_id", "message_id", "interaction_id"} and value is not None}
    current = get_project_provider_context(project_id)
    if allowed:
        current[provider] = allowed
    with _lock, _connect() as db:
        db.execute(
            "UPDATE projects SET provider_context_json=?,updated_at=? WHERE project_id=?",
            (json.dumps(current, ensure_ascii=False), utc_now(), project_id),
        )


def get_project(project_id: str) -> dict[str, Any] | None:
    with _connect() as db:
        row = db.execute("SELECT * FROM projects WHERE project_id=?", (project_id,)).fetchone()
        if not row:
            return None
        versions = db.execute("SELECT version_id,version_number,user_instruction,plan_json,audit_json,metadata_json,created_at FROM versions WHERE project_id=? ORDER BY version_number DESC", (project_id,)).fetchall()
        messages = db.execute("SELECT role,content,version_number,created_at FROM project_messages WHERE project_id=? ORDER BY message_id", (project_id,)).fetchall()
    result = dict(row)
    for field in ("request_json", "latest_plan_json", "latest_audit_json", "provider_context_json"):
        result[field] = json.loads(result[field]) if result.get(field) else ({} if field == "provider_context_json" else None)
    result["versions"] = [dict(v) for v in versions]
    for version in result["versions"]:
        version["plan_json"] = json.loads(version["plan_json"]) if version.get("plan_json") else None
        version["audit_json"] = json.loads(version["audit_json"]) if version.get("audit_json") else None
        version["metadata_json"] = json.loads(version["metadata_json"]) if version.get("metadata_json") else None
    result["messages"] = [dict(m) for m in messages]
    return result


def list_projects(limit: int = 50) -> list[dict[str, Any]]:
    with _connect() as db:
        rows = db.execute(
            "SELECT project_id,title,brief,version_number,latest_output,created_at,updated_at FROM projects ORDER BY updated_at DESC LIMIT ?",
            (max(1, min(100, limit)),),
        ).fetchall()
    return [dict(row) for row in rows]


def save_version(project_id: str, instruction: str, request: dict, plan: dict, audit: dict, output_path: str, metadata: dict) -> int:
    now = utc_now()
    with _lock, _connect() as db:
        row = db.execute("SELECT version_number FROM projects WHERE project_id=?", (project_id,)).fetchone()
        if not row:
            raise KeyError("پروژه در حافظه پایدار پیدا نشد.")
        number = int(row["version_number"]) + 1
        db.execute(
            "INSERT INTO versions(version_id,project_id,version_number,user_instruction,request_json,plan_json,audit_json,output_path,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (uuid.uuid4().hex, project_id, number, instruction, json.dumps(request, ensure_ascii=False), json.dumps(plan, ensure_ascii=False), json.dumps(audit, ensure_ascii=False), output_path, json.dumps(metadata, ensure_ascii=False), now),
        )
        db.execute(
            "UPDATE projects SET title=?,brief=?,request_json=?,latest_plan_json=?,latest_audit_json=?,latest_output=?,version_number=?,updated_at=? WHERE project_id=?",
            (plan.get("project_title") or "CineForge Project", instruction or request.get("prompt", ""), json.dumps(request, ensure_ascii=False), json.dumps(plan, ensure_ascii=False), json.dumps(audit, ensure_ascii=False), output_path, number, now, project_id),
        )
        db.execute(
            "INSERT INTO project_messages(project_id,role,content,version_number,created_at) VALUES(?,?,?,?,?)",
            (project_id, "assistant", f"نسخه {number} رندر و ممیزی شد.", number, now),
        )
    return number


def append_message(project_id: str, role: str, content: str, version_number: int | None = None) -> None:
    with _lock, _connect() as db:
        db.execute(
            "INSERT INTO project_messages(project_id,role,content,version_number,created_at) VALUES(?,?,?,?,?)",
            (project_id, role, content, version_number, utc_now()),
        )


def delete_project(project_id: str) -> bool:
    with _lock, _connect() as db:
        cursor = db.execute("DELETE FROM projects WHERE project_id=?", (project_id,))
        return cursor.rowcount > 0
