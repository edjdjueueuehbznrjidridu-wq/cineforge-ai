"""Deterministic storyboard and render-preflight audits with safe repair."""
from __future__ import annotations

import math
from collections import Counter
from typing import Any

from .schemas import Scene, VideoPlan, VideoRequest

MOTIF_ROTATION = [
    "network", "topography", "timeline", "waveform", "orbit", "bars", "concentric",
    "ribbon", "typography", "maplines", "nodes", "architecture", "particles",
    "spiral", "constellation", "flow", "contour", "radial",
]
MOTION_ROTATION = ["reveal", "parallax", "pan", "orbit", "rise", "drift", "slow_zoom", "sweep", "float", "ken_burns", "pulse", "elastic"]


def _similarity(a: str, b: str) -> float:
    aa = set((a or "").lower().split())
    bb = set((b or "").lower().split())
    return len(aa & bb) / max(1, len(aa | bb))


def _rgb_luminance(rgb: tuple[int, int, int]) -> float:
    values = []
    for component in rgb:
        channel = component / 255.0
        values.append(channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4)
    return 0.2126 * values[0] + 0.7152 * values[1] + 0.0722 * values[2]


def _contrast_ratio(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    light, dark = sorted((_rgb_luminance(a), _rgb_luminance(b)), reverse=True)
    return (light + 0.05) / (dark + 0.05)


def _style_background(style: str) -> tuple[int, int, int]:
    palettes = {
        "cinematic": (5, 12, 25), "minimal": (11, 14, 20), "documentary": (7, 20, 19),
        "motion": (4, 13, 28), "cyberpunk": (18, 7, 27), "retro": (28, 16, 10),
        "luxury": (14, 12, 13), "nature": (5, 19, 15), "corporate": (7, 15, 28), "dream": (13, 12, 31),
    }
    return palettes.get(style, palettes["cinematic"])


def audit_plan(request: VideoRequest, plan: VideoPlan) -> dict[str, Any]:
    issues: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []
    actual = sum(scene.duration for scene in plan.scenes)
    if actual != request.duration:
        issues.append({"code": "duration_mismatch", "message": f"مجموع زمان صحنه‌ها {actual} ثانیه است، نه {request.duration}."})
    if plan.music_tempo_bpm and not 60 <= plan.music_tempo_bpm <= 160:
        issues.append({"code": "music_tempo_range", "message": "سرعت موسیقی باید بین ۶۰ تا ۱۶۰ BPM باشد."})
    if len(plan.music_energy_curve) > 24 or any(not 0.0 <= point <= 1.0 for point in plan.music_energy_curve):
        issues.append({"code": "music_energy_curve", "message": "منحنی انرژی موسیقی خارج از محدوده مجاز است."})
    invalid_events = [event for event in plan.sound_events if event.time_seconds >= request.duration or event.time_seconds + event.duration > request.duration + 4.0]
    if invalid_events:
        warnings.append({"code": "sound_event_outside_timeline", "message": "حداقل یک افکت صوتی نزدیک یا خارج از انتهای ویدیو قرار دارد و ممکن است کوتاه شود."})
    if len(plan.sound_events) > 36:
        issues.append({"code": "too_many_sound_events", "message": "تعداد افکت‌های صوتی از سقف مجاز بیشتر است."})
    if plan.scenes[0].kind != "intro":
        warnings.append({"code": "missing_intro", "message": "صحنه آغازین به‌عنوان intro مشخص نشده است."})
    if len(plan.scenes) > 1 and plan.scenes[-1].kind != "outro":
        warnings.append({"code": "missing_outro", "message": "صحنه پایانی به‌عنوان outro مشخص نشده است."})
    motifs = [s.motif for s in plan.scenes if s.motif != "auto"]
    motions = [s.motion for s in plan.scenes]
    compositions = [s.composition for s in plan.scenes]
    image_prompts = [s.image_prompt.strip() for s in plan.scenes if s.image_prompt.strip()]
    unique_image_prompts = len(set(image_prompts))
    if len(image_prompts) > 1 and unique_image_prompts < len(image_prompts):
        warnings.append({"code": "duplicate_image_prompt", "message": "حداقل دو صحنه دستور تصویرسازی یکسان دارند؛ تنوع واقعی keyframeها ممکن است کاهش یابد."})
    if len(image_prompts) > 2:
        similar_pairs = []
        for i, prompt_a in enumerate(image_prompts):
            for j in range(i + 1, len(image_prompts)):
                if _similarity(prompt_a, image_prompts[j]) > 0.78:
                    similar_pairs.append((i + 1, j + 1))
        if similar_pairs:
            warnings.append({"code": "similar_image_prompts", "message": f"دستور تصویرسازی صحنه‌های {similar_pairs[0][0]} و {similar_pairs[0][1]} بیش از حد شبیه‌اند؛ تفاوت زاویه، کنش یا محیط را بیشتر کن."})
    if len(motifs) > 2 and len(set(motifs)) < len(motifs) * 0.55:
        warnings.append({"code": "motif_repetition", "message": "تنوع موتیف‌های بصری پایین است."})
    if len(motions) > 3 and len(set(motions)) < len(motions) * 0.50:
        warnings.append({"code": "motion_repetition", "message": "حرکت دوربین بیش از حد تکرار شده است."})
    if len(compositions) > 3 and len(set(compositions)) < len(compositions) * 0.40:
        warnings.append({"code": "composition_repetition", "message": "چیدمان قاب‌ها تنوع کافی ندارد."})
    bg = _style_background(request.style)
    white_contrast = _contrast_ratio((245, 249, 255), bg)
    if white_contrast < 7.0:
        warnings.append({"code": "text_contrast", "message": "کنتراست عنوان از هدف خوانایی بالا کمتر است؛ پس‌زمینه باید تاریک‌تر یا متن روشن‌تر شود."})
    for index, scene in enumerate(plan.scenes):
        if scene.duration < 2 and len(plan.scenes) > 2:
            warnings.append({"code": "short_scene", "message": f"صحنه {index + 1} کمتر از دو ثانیه است."})
        if len(scene.title) > (32 if request.duration < 30 else 48):
            warnings.append({"code": "title_density", "message": f"عنوان صحنه {index + 1} احتمالاً برای نمایش روان طولانی است."})
        if not (0.08 <= scene.focal_x <= 0.92 and 0.08 <= scene.focal_y <= 0.88):
            issues.append({"code": "unsafe_focal_point", "message": f"نقطه تمرکز صحنه {index + 1} خارج از محدوده امن است."})
        if scene.duration < 1:
            issues.append({"code": "invalid_scene_duration", "message": f"زمان صحنه {index + 1} نامعتبر است."})
        if not (0.70 <= scene.scale_from <= 1.40 and 0.70 <= scene.scale_to <= 1.40):
            issues.append({"code": "scale_out_of_range", "message": f"مقیاس حرکت صحنه {index + 1} خارج از بازه مجاز است."})
        if len(scene.subtitle) > (70 if request.text_density == "rich" else 48):
            warnings.append({"code": "subtitle_density", "message": f"زیرعنوان صحنه {index + 1} ممکن است بیش از حد متراکم باشد."})
        if index:
            previous = plan.scenes[index - 1]
            jump = math.hypot(scene.focal_x - previous.focal_x, scene.focal_y - previous.focal_y)
            if jump > 0.42 and scene.transition == "cut":
                warnings.append({"code": "focal_jump", "message": f"پرش نقطه تمرکز بین صحنه‌های {index} و {index + 1} زیاد است؛ یک انتقال نرم‌تر پیشنهاد می‌شود."})
    for i, scene in enumerate(plan.scenes):
        for j in range(i + 1, len(plan.scenes)):
            if _similarity(scene.visual_note, plan.scenes[j].visual_note) > 0.82 and len(scene.visual_note) > 20:
                warnings.append({"code": "similar_scene_notes", "message": f"توصیف صحنه‌های {i+1} و {j+1} بیش از حد مشابه است."})
    return {
        "passed": not issues,
        "issue_count": len(issues),
        "warning_count": len(warnings),
        "issues": issues,
        "warnings": warnings,
        "metrics": {
            "duration_requested": request.duration,
            "duration_planned": actual,
            "scene_count": len(plan.scenes),
            "unique_motifs": len(set(motifs)),
            "unique_motions": len(set(motions)),
            "unique_compositions": len(set(compositions)),
            "unique_image_prompts": unique_image_prompts,
            "image_prompt_count": len(image_prompts),
            "title_contrast_ratio": round(white_contrast, 2),
            "duration_variance": round(_variance([s.duration for s in plan.scenes]), 3),
            "music_mood": plan.music_mood,
            "music_tempo_bpm": plan.music_tempo_bpm,
            "music_energy_points": len(plan.music_energy_curve),
            "sound_event_count": len(plan.sound_events),
        },
    }


def _variance(values: list[int]) -> float:
    if not values:
        return 0.0
    mean = sum(values) / len(values)
    return sum((item - mean) ** 2 for item in values) / len(values)


def repair_plan(request: VideoRequest, plan: VideoPlan) -> tuple[VideoPlan, dict[str, Any]]:
    scenes = list(plan.scenes)
    if not scenes:
        return plan, audit_plan(request, plan)
    if len(scenes) > request.duration:
        scenes = scenes[:request.duration]
    # Ensure every scene is a distinct beat in the visual grammar.
    used_motifs: set[str] = set()
    used_motions: set[str] = set()
    for index, scene in enumerate(scenes):
        motif = scene.motif
        if motif == "auto" or motif in used_motifs:
            offset = (index * 3 + (sum(ord(c) for c in request.prompt[:16]) % len(MOTIF_ROTATION))) % len(MOTIF_ROTATION)
            for step in range(len(MOTIF_ROTATION)):
                candidate = MOTIF_ROTATION[(offset + step) % len(MOTIF_ROTATION)]
                if candidate not in used_motifs:
                    motif = candidate
                    break
        scene.motif = motif
        used_motifs.add(motif)
        if scene.motion in used_motions and len(scenes) > 2:
            offset = (index * 5 + 1) % len(MOTION_ROTATION)
            scene.motion = next((MOTION_ROTATION[(offset + k) % len(MOTION_ROTATION)] for k in range(len(MOTION_ROTATION)) if MOTION_ROTATION[(offset+k) % len(MOTION_ROTATION)] not in used_motions), scene.motion)
        used_motions.add(scene.motion)
        if index == 0:
            scene.kind = "intro"
        elif index == len(scenes) - 1 and len(scenes) > 1:
            scene.kind = "outro"
        # Composition should not be identical on each adjacent beat.
        if index and scene.composition == scenes[index-1].composition:
            scene.composition = ["left", "right", "diagonal", "split", "center", "lower"][index % 6]
    weights = [max(1.0, float(scene.duration)) for scene in scenes]
    if len(scenes) > request.duration:
        scenes = scenes[:request.duration]
    total_weight = sum(weights[:len(scenes)])
    raw = [request.duration * weight / total_weight for weight in weights[:len(scenes)]]
    durations = [max(1, int(value)) for value in raw]
    while sum(durations) > request.duration:
        ix = max((i for i, d in enumerate(durations) if d > 1), key=lambda i: durations[i] - raw[i], default=None)
        if ix is None:
            break
        durations[ix] -= 1
    remainder = request.duration - sum(durations)
    order = sorted(range(len(raw)), key=lambda i: (raw[i] - math.floor(raw[i]), -i), reverse=True)
    for k in range(remainder):
        durations[order[k % len(order)]] += 1
    for scene, duration in zip(scenes, durations):
        scene.duration = duration
    plan.scenes = scenes
    report = audit_plan(request, plan)
    return plan, report


def audit_render_metadata(request: VideoRequest, metadata: dict[str, Any]) -> dict[str, Any]:
    issues: list[str] = []
    expected_w, expected_h = request.dimensions()
    if metadata.get("width") != expected_w or metadata.get("height") != expected_h:
        issues.append("ابعاد خروجی با تنظیمات برابر نیست.")
    if abs(float(metadata.get("duration", 0)) - request.duration) > max(0.20, 1 / request.fps):
        issues.append("مدت خروجی با مدت درخواست‌شده مطابقت ندارد.")
    if metadata.get("video_codec") not in {None, "h264"}:
        issues.append("کدک تصویر خروجی H.264 نیست.")
    expected_frames = request.duration * request.fps
    actual_frames = int(metadata.get("frame_count") or 0)
    if actual_frames and abs(actual_frames - expected_frames) > max(1, request.fps // 2):
        issues.append("تعداد فریم‌های خروجی با FPS و مدت درخواست‌شده سازگار نیست.")
    pixel_format = metadata.get("pixel_format")
    if pixel_format and pixel_format not in {"yuv420p", "yuvj420p"}:
        issues.append("فرمت پیکسل خروجی برای پخش عمومی بهینه نیست.")
    if request.music_style != "none" and not metadata.get("has_audio", False):
        issues.append("موسیقی درخواست شده اما جریان صوتی وجود ندارد.")
    return {"passed": not issues, "issues": issues, "checks": ["dimensions", "duration", "frame_count", "pixel_format", "video_codec", "audio_presence"]}
