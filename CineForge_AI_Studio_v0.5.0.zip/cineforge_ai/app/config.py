from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[1]
load_dotenv(BASE_DIR / ".env")

DATA_DIR = Path(os.getenv("CINEFORGE_DATA_DIR", BASE_DIR / "data")).resolve()
OUTPUT_DIR = DATA_DIR / "outputs"
ASSETS_DIR = DATA_DIR / "assets"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
ASSETS_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "cineforge.sqlite3"
APP_NAME = "CineForge AI Studio"
APP_VERSION = "0.5.0"
NESTAPI_CHAT_URL = os.getenv("NESTAPI_CHAT_URL", "https://open.nestapi.ir/apis-1/chat-ai").strip()
NESTAPI_TIMEOUT_SECONDS = float(os.getenv("NESTAPI_TIMEOUT_SECONDS", "75"))
NESTAPI_RETRIES = max(0, min(3, int(os.getenv("NESTAPI_RETRIES", "2"))))
GEMINI_INTERACTIONS_URL = os.getenv("GEMINI_INTERACTIONS_URL", "https://generativelanguage.googleapis.com/v1beta/interactions").strip()
MAX_ACTIVE_JOBS = max(1, min(3, int(os.getenv("MAX_ACTIVE_JOBS", "1"))))
MAX_PIXEL_FRAMES = max(500_000_000, int(os.getenv("CINEFORGE_MAX_PIXEL_FRAMES", "8000000000")))
MAX_TOTAL_FRAMES = max(1000, int(os.getenv("CINEFORGE_MAX_TOTAL_FRAMES", "18000")))
