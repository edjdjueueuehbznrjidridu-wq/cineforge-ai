from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

AspectRatio = Literal["9:16", "16:9", "1:1"]
Resolution = Literal["540p", "720p", "1080p"]
Style = Literal[
    "cinematic", "minimal", "documentary", "motion", "cyberpunk",
    "retro", "luxury", "nature", "corporate", "dream"
]
Motion = Literal[
    "slow_zoom", "pan", "pulse", "reveal", "drift", "orbit", "rise", "parallax",
    "float", "sweep", "ken_burns", "elastic"
]
SceneKind = Literal["intro", "technology", "data", "quote", "abstract", "outro", "process", "detail"]
VisualMotif = Literal[
    "auto", "network", "topography", "timeline", "waveform", "orbit", "bars",
    "concentric", "ribbon", "typography", "maplines", "nodes", "architecture",
    "particles", "spiral", "constellation", "flow", "contour", "radial"
]
Composition = Literal["center", "upper", "lower", "left", "right", "split", "diagonal", "fullbleed"]
Transition = Literal["dissolve", "cut", "slide", "wipe", "lightleak"]
AccentPalette = Literal["auto", "ocean", "violet", "amber", "emerald", "rose", "mono"]
Intensity = Literal["low", "normal", "high"]
TextDensity = Literal["minimal", "standard", "rich"]
MusicStyle = Literal["auto", "none", "mellow", "cinematic", "pulse", "ambient", "hopeful", "dark", "epic", "focus", "playful", "tension", "dreamy", "emotional", "electronic", "documentary"]
AIProvider = Literal["nestapi", "gemini", "local"]
AIModel = str
VisualEngine = Literal["nano_banana", "ai_image_generator", "ensemble", "procedural"]
ImageQuality = Literal["standard", "high"]


class Scene(BaseModel):
    title: str = Field(default="", max_length=90)
    subtitle: str = Field(default="", max_length=180)
    kind: SceneKind = "technology"
    duration: int = Field(ge=1, le=600)
    motion: Motion = "slow_zoom"
    visual_note: str = Field(default="", max_length=500)
    motif: VisualMotif = "auto"
    composition: Composition = "center"
    transition: Transition = "dissolve"
    focal_x: float = Field(default=0.5, ge=0.08, le=0.92)
    focal_y: float = Field(default=0.39, ge=0.08, le=0.88)
    scale_from: float = Field(default=0.96, ge=0.70, le=1.40)
    scale_to: float = Field(default=1.04, ge=0.70, le=1.40)
    detail_level: int = Field(default=2, ge=1, le=4)
    accent_role: Literal["primary", "secondary", "warm", "cool"] = "primary"
    image_prompt: str = Field(default="", max_length=1800)
    camera_path: str = Field(default="", max_length=240)


class SoundEvent(BaseModel):
    """A timestamped, restrained sound-design event attached to the storyboard."""
    time_seconds: float = Field(ge=0, le=600)
    kind: Literal["impact", "soft_hit", "whoosh", "riser", "tick", "ambience"] = "whoosh"
    intensity: float = Field(default=0.35, ge=0.0, le=1.0)
    duration: float = Field(default=0.8, ge=0.08, le=4.0)
    pan: float = Field(default=0.0, ge=-1.0, le=1.0)


class VideoPlan(BaseModel):
    project_title: str = Field(default="CineForge Project", max_length=100)
    creative_direction: str = Field(default="Cinematic motion graphics", max_length=1200)
    narrative_arc: str = Field(default="", max_length=1000)
    director_notes: str = Field(default="", max_length=1600)
    visual_bible: str = Field(default="", max_length=1600)
    subject_anchor: str = Field(default="", max_length=800)
    music_mood: MusicStyle = "auto"
    music_tempo_bpm: int = Field(default=0, ge=0, le=160)
    music_direction: str = Field(default="", max_length=700)
    music_energy_curve: list[float] = Field(default_factory=list, max_length=24)
    sound_events: list[SoundEvent] = Field(default_factory=list, max_length=36)
    sound_design_notes: str = Field(default="", max_length=700)
    scenes: list[Scene] = Field(min_length=1, max_length=24)

    @field_validator("music_energy_curve")
    @classmethod
    def validate_energy_curve(cls, values: list[float]) -> list[float]:
        if any(not 0.0 <= value <= 1.0 for value in values):
            raise ValueError("سطح انرژی موسیقی باید بین صفر و یک باشد.")
        return values

    @field_validator("music_tempo_bpm")
    @classmethod
    def validate_music_tempo(cls, value: int) -> int:
        if value and not 60 <= value <= 160:
            raise ValueError("سرعت موسیقی باید صفر (خودکار) یا بین ۶۰ تا ۱۶۰ BPM باشد.")
        return value

    @model_validator(mode="after")
    def validate_scene_durations(self):
        if any(scene.duration < 1 for scene in self.scenes):
            raise ValueError("مدت هر صحنه باید حداقل یک ثانیه باشد.")
        return self


class VideoRequest(BaseModel):
    prompt: str = Field(min_length=5, max_length=10000)
    duration: int = Field(default=30, ge=5, le=600)
    fps: Literal[24, 30, 60] = 24
    aspect_ratio: AspectRatio = "9:16"
    resolution: Resolution = "720p"
    style: Style = "cinematic"
    accent_palette: AccentPalette = "auto"
    accent_color: str | None = None
    motion_intensity: Intensity = "normal"
    text_density: TextDensity = "standard"
    music_style: MusicStyle = "auto"
    music_volume: int = Field(default=22, ge=0, le=40)
    music_tempo: int = Field(default=0, ge=0, le=160)
    music_seed: int | None = Field(default=None, ge=0, le=2_147_483_647)
    voiceover_text: str = Field(default="", max_length=5000)
    voiceover_voice: str = Field(default="auto", max_length=80)
    multi_agent: bool = False
    refine_images: bool = False
    render_quality: Literal["fast", "balanced", "high", "ultra"] = "balanced"
    visual_engine: VisualEngine = "ensemble"
    image_quality: ImageQuality = "high"
    upscale_images: bool = True
    upscale_scale: Literal[2, 3, 4] = 2
    allow_procedural_fallback: bool = False
    language: Literal["fa", "en"] = "fa"
    brand_label: str = Field(default="CINEFORGE STUDIO", max_length=32)
    closing_text: str = Field(default="", max_length=90)
    show_grid: bool = True
    show_particles: bool = True
    show_progress: bool = True
    include_branding: bool = True
    use_ai: bool = True
    ai_provider: AIProvider = "nestapi"
    ai_model: str = "gpt5"
    project_id: str | None = None
    plan_source: Literal["ai", "fallback", "edited"] | None = None
    plan_model: str | None = None
    plan_override: VideoPlan | None = None

    @model_validator(mode="after")
    def enforce_render_budget(self):
        width, height = self.dimensions()
        frames = self.duration * self.fps
        pixel_frames = width * height * frames
        max_pixel_frames = 8_000_000_000
        max_frames = 18_000
        if frames > max_frames or pixel_frames > max_pixel_frames:
            suggested = []
            for res in ("1080p", "720p", "540p"):
                side = {"1080p": 1080, "720p": 720, "540p": 540}[res]
                w, h = (side, round(side * 16 / 9)) if self.aspect_ratio == "9:16" else ((round(side * 16 / 9), side) if self.aspect_ratio == "16:9" else (side, side))
                max_sec = min(max_frames // self.fps, max_pixel_frames // max(1, w * h * self.fps))
                if max_sec >= self.duration:
                    suggested.append(res)
            if suggested:
                raise ValueError(
                    f"حجم محاسباتی این ترکیب از بودجه رندر بیشتر است. مدت یا FPS را کم کن؛ "
                    f"رزولوشن‌های قابل‌استفاده برای همین مدت: {', '.join(suggested)}. کیفیت به‌صورت خودکار کاهش داده نمی‌شود."
                )
            raise ValueError(
                "این ترکیب از بودجه امن رندر بیشتر است. رزولوشن/FPS را پایین‌تر بیاور یا مدت را به چند بخش تولید و سپس سرهم کن."
            )
        return self

    @field_validator("prompt")
    @classmethod
    def clean_prompt(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 5:
            raise ValueError("توضیح ویدیو باید حداقل ۵ نویسه باشد.")
        return value

    @field_validator("brand_label", "closing_text")
    @classmethod
    def clean_optional_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("voiceover_text")
    @classmethod
    def clean_voiceover(cls, value: str) -> str:
        return value.strip()

    @field_validator("voiceover_voice")
    @classmethod
    def clean_voice(cls, value: str) -> str:
        value = value.strip() or "auto"
        if len(value) > 80 or not re.fullmatch(r"[A-Za-z0-9-]+", value):
            raise ValueError("شناسه صدای گوینده معتبر نیست.")
        return value

    @field_validator("accent_color")
    @classmethod
    def validate_hex_color(cls, value: str | None) -> str | None:
        if value is None or value == "":
            return None
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", value):
            raise ValueError("رنگ سفارشی باید با قالب #RRGGBB باشد.")
        return value.lower()

    @field_validator("ai_model")
    @classmethod
    def validate_model_id(cls, value: str) -> str:
        value = value.strip()
        if not value or len(value) > 100 or not re.fullmatch(r"[A-Za-z0-9._:-]+", value):
            raise ValueError("شناسه مدل معتبر نیست.")
        return value

    def dimensions(self) -> tuple[int, int]:
        short_side = {"540p": 540, "720p": 720, "1080p": 1080}[self.resolution]
        if self.aspect_ratio == "9:16":
            return short_side, round(short_side * 16 / 9)
        if self.aspect_ratio == "16:9":
            return round(short_side * 16 / 9), short_side
        return short_side, short_side


class PlanResponse(BaseModel):
    plan: VideoPlan
    planner: Literal["ai", "fallback"]
    model: str | None = None
    provider: str | None = None
    note: str
    project_id: str | None = None
    audit: dict | None = None


class JobCreated(BaseModel):
    job_id: str
    status: str
    project_id: str | None = None


class JobStatus(BaseModel):
    job_id: str
    status: str
    progress: int = 0
    message: str = ""
    download_url: str | None = None
    video_url: str | None = None
    error: str | None = None
    plan: VideoPlan | None = None
    planner: str | None = None
    note: str | None = None
    poster_url: str | None = None
    metadata: dict | None = None
    project_id: str | None = None
    audit: dict | None = None


class ProjectEditRequest(BaseModel):
    instruction: str = Field(min_length=2, max_length=3000)
    provider: AIProvider | None = None
    model: str | None = None


class AISettingsUpdate(BaseModel):
    provider: AIProvider = "nestapi"
    nestapi_model: str = "gpt5"
    gemini_model: str = "gemini-3.8-flash"
    gemini_api_key: str | None = None

    @field_validator("nestapi_model", "gemini_model")
    @classmethod
    def validate_provider_model(cls, value: str) -> str:
        value = value.strip()
        if not value or len(value) > 100 or not re.fullmatch(r"[A-Za-z0-9._:-]+", value):
            raise ValueError("شناسه مدل معتبر نیست.")
        return value

    @field_validator("gemini_api_key")
    @classmethod
    def clean_key(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        if len(value) > 512:
            raise ValueError("کلید API بیش از حد طولانی است.")
        return value or None
