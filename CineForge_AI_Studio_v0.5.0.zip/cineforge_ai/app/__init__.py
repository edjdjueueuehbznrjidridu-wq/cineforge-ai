"""CineForge AI - modular AI-assisted video production starter."""
