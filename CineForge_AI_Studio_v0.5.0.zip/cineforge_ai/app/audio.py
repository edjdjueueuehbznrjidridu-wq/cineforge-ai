"""Procedural cinematic soundtrack engine.

Creates original, deterministic, block-rendered stereo music. The engine uses
musical notes/chords, envelopes, LFOs, rhythmic pulses and a soft limiter; it
is intentionally not a single fixed sine-wave bed.
"""
from __future__ import annotations

import hashlib
import json
import math
import wave
from urllib.parse import urlparse

import httpx
from pathlib import Path

import numpy as np


def fetch_nestapi_voices(locale: str = "fa", gender: str | None = None) -> list[dict[str, str]]:
    """Fetch the provider's live voice catalogue using action=voices.

    The response shape is deliberately parsed defensively because the public docs
    define the action and filters but do not pin one fixed JSON nesting layout.
    """
    params: dict[str, str] = {"action": "voices", "locale": locale if locale in {"fa", "en"} else "fa"}
    if gender in {"Male", "Female"}:
        params["gender"] = gender
    endpoint = "https://open.nestapi.ir/apis-1/text-to-speech"
    with httpx.Client(timeout=httpx.Timeout(connect=20, read=90, write=20, pool=20), follow_redirects=True) as client:
        response = client.get(endpoint, params=params, headers={"Accept": "application/json", "User-Agent": "CineForge-Studio/0.5"})
    response.raise_for_status()
    payload = response.json()
    if isinstance(payload, dict) and payload.get("success") is False:
        error = payload.get("error") or {}
        raise RuntimeError(f"NestAPI voice catalogue: {error.get('code', 'API_ERROR')} {error.get('message', '')}".strip())

    candidates: list[dict[str, str]] = []
    seen: set[str] = set()

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            identifier = next((value.get(key) for key in ("ShortName", "short_name", "voice", "id", "name", "Name") if isinstance(value.get(key), str) and value.get(key).strip()), None)
            if identifier:
                voice_id = str(identifier).strip()
                if voice_id not in seen:
                    seen.add(voice_id)
                    label = next((str(value.get(key)).strip() for key in ("FriendlyName", "friendly_name", "label", "display_name", "Name") if isinstance(value.get(key), str) and value.get(key).strip()), voice_id)
                    voice_locale = next((str(value.get(key)).strip() for key in ("Locale", "locale", "lang", "language") if isinstance(value.get(key), str) and value.get(key).strip()), "")
                    voice_gender = next((str(value.get(key)).strip() for key in ("Gender", "gender") if isinstance(value.get(key), str) and value.get(key).strip()), "")
                    candidates.append({"id": voice_id, "label": label, "locale": voice_locale, "gender": voice_gender})
            for child in value.values():
                if isinstance(child, (dict, list)):
                    walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(payload)
    if not candidates:
        raise RuntimeError("ساختار پاسخ فهرست صداهای NestAPI قابل تشخیص نبود.")
    return candidates[:300]

# Root MIDI note, BPM, chord progression (semitones), energy, arp style, pulse.
MUSIC_PROFILES: dict[str, dict] = {
    "none": {"root": 50, "bpm": 90, "progression": [0], "energy": 0.0, "arp": False, "pulse": False},
    "mellow": {"root": 50, "bpm": 82, "progression": [0, 7, 9, 5], "energy": 0.30, "arp": False, "pulse": False},
    "cinematic": {"root": 45, "bpm": 92, "progression": [0, 5, 3, 7], "energy": 0.62, "arp": True, "pulse": True},
    "pulse": {"root": 45, "bpm": 112, "progression": [0, 3, 8, 5], "energy": 0.78, "arp": True, "pulse": True},
    "ambient": {"root": 53, "bpm": 70, "progression": [0, 5, 2, 7], "energy": 0.18, "arp": False, "pulse": False},
    "hopeful": {"root": 55, "bpm": 104, "progression": [0, 7, 5, 9], "energy": 0.56, "arp": True, "pulse": False},
    "dark": {"root": 45, "bpm": 76, "progression": [0, 3, 8, 6], "energy": 0.38, "arp": False, "pulse": False},
    "epic": {"root": 43, "bpm": 100, "progression": [0, 5, 3, 7], "energy": 0.88, "arp": True, "pulse": True},
    "focus": {"root": 50, "bpm": 96, "progression": [0, 5, 9, 7], "energy": 0.24, "arp": True, "pulse": False},
    "playful": {"root": 57, "bpm": 118, "progression": [0, 9, 5, 7], "energy": 0.66, "arp": True, "pulse": True},
    "tension": {"root": 46, "bpm": 108, "progression": [0, 1, 6, 5], "energy": 0.72, "arp": True, "pulse": True},
    "dreamy": {"root": 53, "bpm": 78, "progression": [0, 7, 2, 9], "energy": 0.25, "arp": True, "pulse": False},
    "emotional": {"root": 48, "bpm": 84, "progression": [0, 8, 5, 7], "energy": 0.42, "arp": False, "pulse": False},
    "electronic": {"root": 50, "bpm": 122, "progression": [0, 5, 3, 7], "energy": 0.82, "arp": True, "pulse": True},
    "documentary": {"root": 50, "bpm": 88, "progression": [0, 5, 7, 0], "energy": 0.22, "arp": False, "pulse": False},
}

# Chord colour: intervals above each progression root. All are consonant and
# kept below a conservative peak to avoid clipping after summing layers.
CHORD_SHAPES = {
    "mellow": (0, 4, 7, 11),
    "dark": (0, 3, 7, 10),
    "cinematic": (0, 3, 7, 10),
    "pulse": (0, 3, 7, 10),
    "ambient": (0, 4, 7, 14),
    "hopeful": (0, 4, 7, 11),
    "epic": (0, 4, 7, 12),
    "focus": (0, 4, 7, 11),
    "playful": (0, 4, 7, 12),
    "tension": (0, 1, 7, 10),
    "dreamy": (0, 4, 7, 14),
    "emotional": (0, 3, 7, 11),
    "electronic": (0, 3, 7, 10),
    "documentary": (0, 4, 7, 10),
}


def _midi_hz(note: np.ndarray | float) -> np.ndarray:
    return 440.0 * np.power(2.0, (np.asarray(note, dtype=np.float64) - 69.0) / 12.0)


def _stable_seed(seed: int | str | None, style: str, duration: int) -> int:
    raw = f"{seed!s}|{style}|{duration}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(raw).digest()[:4], "big")


def infer_music_style(prompt: str, requested_style: str = "auto") -> str:
    """Infer a restrained score mood from the brief when the user selects auto."""
    if requested_style and requested_style != "auto" and requested_style in MUSIC_PROFILES:
        return requested_style
    text = (prompt or "").casefold()
    rules = [
        (("ترس", "مرموز", "تاریک", "رازآلود", "dark", "mystery", "mysterious"), "dark"),
        (("تنش", "دلهره", "تعلیق", "tension", "suspense"), "tension"),
        (("حماسی", "باشکوه", "epic", "heroic", "majestic"), "epic"),
        (("امید", "انگیزشی", "موفقیت", "امیدوار", "hopeful", "inspiring"), "hopeful"),
        (("رویا", "خیالی", "جادویی", "dream", "dreamy", "surreal"), "dreamy"),
        (("احساسی", "عاطفی", "غمگین", "emotional", "moving", "sentimental"), "emotional"),
        (("بازی", "سرگرم", "شاد", "playful", "fun", "playful"), "playful"),
        (("الکترونیک", "فناوری", "تکنولوژی", "سایبر", "electronic", "cyber", "technology"), "electronic"),
        (("مستند", "واقعی", "آموزشی", "documentary", "educational", "explainer"), "documentary"),
        (("تمرکز", "مطالعه", "کار", "focus", "study", "deep work"), "focus"),
        (("طبیعت", "آرامش", "مدیتیشن", "ambient", "nature", "calm", "peaceful"), "ambient"),
        (("سینمایی", "فیلم", "تریلر", "cinematic", "trailer", "film"), "cinematic"),
        (("ملایم", "آرام", "لطیف", "mellow", "soft", "gentle"), "mellow"),
    ]
    for terms, style in rules:
        if any(term in text for term in terms):
            return style
    return "mellow"


def generate_nestapi_voiceover(path: Path, text: str, voice: str = "auto", *, rate: int = 0, pitch: int = 0, volume: int = 0) -> dict[str, str | int]:
    """Generate narration using NestAPI's documented TTS audio-stream mode."""
    text = (text or "").strip()
    if not text:
        raise ValueError("متن نریشن خالی است.")
    if len(text) > 5000:
        raise ValueError("متن نریشن بیشتر از محدودیت ۵۰۰۰ نویسه‌ای NestAPI است.")
    params = {
        "text": text,
        "voice": voice or "auto",
        "action": "synthesize",
        "stream": "true",
        "download": "false",
        "rate": str(max(-100, min(100, int(rate)))),
        "pitch": str(max(-100, min(200, int(pitch)))),
        "volume": str(max(-100, min(100, int(volume)))),
        "format": "mp3",
    }
    endpoint = "https://open.nestapi.ir/apis-1/text-to-speech"
    with httpx.Client(timeout=httpx.Timeout(connect=20, read=180, write=30, pool=30), follow_redirects=True) as client:
        response = client.get(endpoint, params=params, headers={"Accept": "audio/mpeg, application/json", "User-Agent": "CineForge-Studio/0.5"})
    response.raise_for_status()
    content_type = response.headers.get("content-type", "").split(";", 1)[0].lower()
    payload = response.content
    if content_type.startswith("audio/") or content_type in {"application/octet-stream", "binary/octet-stream"}:
        if len(payload) < 256:
            raise RuntimeError("NestAPI جریان صوتی خالی یا ناقص برگرداند.")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(payload)
        return {"provider": "nestapi", "format": "mp3", "bytes": len(payload), "voice": voice or "auto"}
    try:
        data = response.json()
    except ValueError as exc:
        raise RuntimeError(f"پاسخ TTS قابل تشخیص نیست: {content_type or 'unknown'}") from exc
    if isinstance(data, dict) and data.get("success") is False:
        error = data.get("error") or {}
        raise RuntimeError(f"NestAPI TTS: {error.get('code', 'API_ERROR')} {error.get('message', '')}".strip())
    # Some deployments may wrap an audio URL in the documented JSON envelope.
    candidate = None
    def walk(value):
        nonlocal candidate
        if candidate:
            return
        if isinstance(value, dict):
            for key in ("audio_url", "audioUrl", "url", "output_url", "download_url"):
                v = value.get(key)
                if isinstance(v, str) and v.startswith("https://"):
                    candidate = v
                    return
            for v in value.values(): walk(v)
        elif isinstance(value, list):
            for v in value: walk(v)
    walk(data.get("data", data) if isinstance(data, dict) else data)
    if not candidate or urlparse(candidate).hostname not in {"open.nestapi.ir"}:
        raise RuntimeError("پاسخ TTS نه جریان صوتی بود و نه URL معتبر صوتی NestAPI داشت.")
    with httpx.Client(timeout=180, follow_redirects=True) as client:
        audio_response = client.get(candidate, headers={"Accept": "audio/*"})
    audio_response.raise_for_status()
    if len(audio_response.content) < 256:
        raise RuntimeError("فایل صوتی TTS خالی یا ناقص است.")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(audio_response.content)
    return {"provider": "nestapi", "format": "mp3", "bytes": len(audio_response.content), "voice": voice or "auto"}


def create_ambient_track(
    path: Path,
    duration: int,
    style: str = "mellow",
    volume: int = 18,
    sample_rate: int = 44100,
    block_seconds: int = 3,
    *,
    tempo: int = 0,
    seed: int | str | None = None,
    stereo_width: float = 0.72,
    prompt: str = "",
    transition_events: list[float] | None = None,
    energy_curve: list[float] | None = None,
    sound_events: list[dict] | None = None,
) -> dict[str, float | int | str]:
    """Generate a layered original stereo score in blocks, with no huge RAM buffer.

    `style` is a mood preset. `tempo=0` uses its musical default. `seed` makes
    repeated renders of the same project reproducible. Output is PCM16 stereo.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    style = infer_music_style(prompt, style)
    profile = MUSIC_PROFILES[style]
    silent = style == "none" or int(volume) <= 0
    bpm = int(tempo) if 60 <= int(tempo or 0) <= 160 else int(profile["bpm"])
    total_samples = max(1, int(duration * sample_rate))
    block_size = max(1024, int(sample_rate * max(1, block_seconds)))
    gain = max(0.0, min(0.40, float(volume) / 100.0))
    width = max(0.0, min(1.0, float(stereo_width)))
    curve = [max(0.0, min(1.0, float(v))) for v in (energy_curve or [])[:24]]
    events = [e for e in (sound_events or []) if isinstance(e, dict)]
    rng = np.random.default_rng(_stable_seed(seed, style, duration))
    energy = float(profile["energy"])
    beat_seconds = 60.0 / bpm
    bar_seconds = beat_seconds * 4.0
    progression = list(profile["progression"])
    chord_shape = CHORD_SHAPES.get(style, (0, 4, 7, 11))
    root_note = int(profile["root"])

    # Choose a stable high-note sequence. The sequence is selected once, not
    # randomly every block, so no block-boundary discontinuities are introduced.
    arp_intervals = np.asarray([0, 7, 12, 7, 4, 7, 14, 7], dtype=np.int16)
    arp_seed_shift = int(rng.integers(0, len(arp_intervals)))
    stereo_phase = 0.017 + width * 0.035

    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)

        for offset in range(0, total_samples, block_size):
            count = min(block_size, total_samples - offset)
            indices = np.arange(offset, offset + count, dtype=np.float64)
            if silent:
                wav.writeframes(np.zeros((count, 2), dtype="<i2").tobytes())
                continue
            t = indices / float(sample_rate)
            beat_pos = t / beat_seconds
            bar_pos = t / bar_seconds
            bar_index = np.floor(bar_pos).astype(np.int64)
            chord_index = bar_index % len(progression)
            chord_root = root_note + np.take(np.asarray(progression, dtype=np.int16), chord_index)
            beat_fraction = beat_pos - np.floor(beat_pos)
            bar_fraction = bar_pos - np.floor(bar_pos)
            if len(curve) >= 2:
                energy_shape = np.interp(t / max(1.0, float(duration)), np.linspace(0.0, 1.0, len(curve)), np.asarray(curve))
                energy_mod = 0.32 + 0.88 * energy_shape
            elif len(curve) == 1:
                energy_mod = np.full(count, 0.32 + 0.88 * curve[0], dtype=np.float64)
            else:
                energy_mod = np.ones(count, dtype=np.float64)

            # Slow, non-repeating-feeling modulation that is deterministic.
            lfo_a = 0.5 + 0.5 * np.sin(2 * np.pi * (0.035 + energy * 0.018) * t + 0.4)
            lfo_b = 0.5 + 0.5 * np.sin(2 * np.pi * 0.071 * t + 1.7)
            pad_attack = np.clip(t / 1.7, 0.0, 1.0)
            pad_release = np.clip((duration - t) / 2.6, 0.0, 1.0)
            global_env = np.minimum(pad_attack, pad_release)

            # Wide, slowly breathing harmonic pad (four chord tones).
            pad_l = np.zeros(count, dtype=np.float64)
            pad_r = np.zeros(count, dtype=np.float64)
            for voice, interval in enumerate(chord_shape):
                note = chord_root.astype(np.float64) + interval + (12 if voice == 3 else 0)
                freq = _midi_hz(note)
                phase_l = 2 * np.pi * freq * t + voice * 0.27 + lfo_a * 0.28
                phase_r = 2 * np.pi * freq * t + voice * 0.31 + lfo_b * 0.31 + stereo_phase
                overtone = 0.72 * np.sin(phase_l) + 0.18 * np.sin(2 * phase_l + 0.13)
                overtone_r = 0.72 * np.sin(phase_r) + 0.18 * np.sin(2 * phase_r + 0.13)
                voice_gain = (0.22 if voice == 0 else 0.13 if voice == 1 else 0.10 if voice == 2 else 0.055)
                pad_l += voice_gain * overtone
                pad_r += voice_gain * overtone_r
            pad_env = global_env * (0.78 + 0.22 * lfo_a)
            pad_l *= pad_env
            pad_r *= pad_env

            # Rounded bass: root on the first beat, fifth on beat three.
            bass_note = chord_root.astype(np.float64) - 12 + np.where((np.floor(beat_pos).astype(np.int64) % 4) >= 2, 7, 0)
            bass_freq = _midi_hz(bass_note)
            bass_phase = 2 * np.pi * bass_freq * t
            bass_env = 0.68 + 0.32 * np.exp(-np.minimum(beat_fraction, 1.0) * 4.0)
            bass_l = energy * 0.17 * bass_env * (np.sin(bass_phase) + 0.12 * np.sin(2 * bass_phase))
            bass_r = energy * 0.165 * bass_env * (np.sin(bass_phase + 0.015) + 0.12 * np.sin(2 * bass_phase + 0.02))

            # Gentle eighth-note arpeggio for styles that benefit from motion.
            if profile["arp"]:
                step = np.floor(beat_pos * 2.0).astype(np.int64)
                arp_idx = (step + arp_seed_shift) % len(arp_intervals)
                arp_note = chord_root.astype(np.float64) + 12 + np.take(arp_intervals, arp_idx)
                arp_freq = _midi_hz(arp_note)
                local_step = beat_pos * 2.0 - np.floor(beat_pos * 2.0)
                arp_env = np.exp(-local_step * (5.0 + energy * 4.0)) * (0.68 + 0.32 * lfo_b)
                arp_phase = 2 * np.pi * arp_freq * t
                arp_l = 0.075 * energy * arp_env * (np.sin(arp_phase) + 0.16 * np.sin(2 * arp_phase))
                arp_r = 0.072 * energy * arp_env * (np.sin(arp_phase + stereo_phase) + 0.14 * np.sin(2 * arp_phase + stereo_phase))
            else:
                arp_l = np.zeros(count, dtype=np.float64)
                arp_r = np.zeros(count, dtype=np.float64)

            # Restrained low-frequency pulse and a soft high transient, never a
            # hard click. The transient is a short windowed sine, not white noise.
            if profile["pulse"]:
                beat_phase = beat_fraction
                kick_env = np.exp(-beat_phase * 20.0)
                kick_freq = 48.0 + 16.0 * np.exp(-beat_phase * 10.0)
                kick_phase = 2 * np.pi * kick_freq * t
                kick = 0.105 * energy * kick_env * np.sin(kick_phase)
                half_beat = (beat_pos * 2.0) - np.floor(beat_pos * 2.0)
                tick_env = np.exp(-half_beat * 30.0)
                tick = 0.018 * energy * tick_env * np.sin(2 * np.pi * 1250.0 * t)
                pulse_l = kick + tick
                pulse_r = kick + tick * 0.82
            else:
                pulse_l = np.zeros(count, dtype=np.float64)
                pulse_r = np.zeros(count, dtype=np.float64)

            # Very quiet filtered-like texture built from low-rate noise with a
            # smooth interpolation envelope; it adds air without harsh hiss.
            noise = rng.standard_normal(count)
            if count > 4:
                kernel = np.asarray([0.12, 0.20, 0.36, 0.20, 0.12])
                texture = np.convolve(noise, kernel, mode="same")
            else:
                texture = noise
            texture *= (0.004 + energy * 0.008) * (0.3 + 0.7 * lfo_a)
            texture_r = np.roll(texture, 7) * 0.86

            # Transition sound design: short filtered-noise swells and soft tonal
            # impacts placed at scene boundaries. These are very low in the mix.
            fx_l = np.zeros(count, dtype=np.float64)
            fx_r = np.zeros(count, dtype=np.float64)
            if transition_events:
                for event_time in transition_events:
                    delta = t - float(event_time)
                    swell = np.exp(-((delta + 0.28) / 0.38) ** 2) * np.clip((delta + 0.75) / 0.30, 0.0, 1.0)
                    impact_env = np.exp(-np.maximum(delta, 0.0) * 8.0) * (delta >= 0.0)
                    fx_l += 0.018 * energy * swell * texture + 0.045 * energy * impact_env * np.sin(2 * np.pi * 72.0 * np.maximum(delta, 0.0))
                    fx_r += 0.017 * energy * swell * texture_r + 0.043 * energy * impact_env * np.sin(2 * np.pi * 74.0 * np.maximum(delta, 0.0) + 0.08)

            # Sidechain-like ducking on each beat keeps bass/pulse clear.
            duck = 1.0 - (0.10 + energy * 0.08) * np.exp(-beat_fraction * 11.0)
            left = (pad_l * duck + bass_l + arp_l + pulse_l + texture + fx_l) * gain * energy_mod
            right = (pad_r * duck + bass_r + arp_r + pulse_r + texture_r + fx_r) * gain * energy_mod

            # Scripted sound events are synthesized locally and synchronized to
            # the director's timeline. Envelopes are continuous across blocks.
            for event in events:
                try:
                    event_time = float(event.get("time_seconds", -999))
                    event_kind = str(event.get("kind", "whoosh"))
                    event_duration = max(0.08, min(4.0, float(event.get("duration", 0.8))))
                    event_gain = max(0.0, min(1.0, float(event.get("intensity", 0.35)))) * 0.18 * gain
                    pan = max(-1.0, min(1.0, float(event.get("pan", 0.0))))
                except (TypeError, ValueError):
                    continue
                relative = t - event_time
                active = (relative >= 0.0) & (relative <= event_duration)
                if not np.any(active) or event_gain <= 0:
                    continue
                phase_t = np.maximum(0.0, relative)
                norm_t = phase_t / event_duration
                envelope = np.sin(np.pi * np.clip(norm_t, 0, 1)) ** 1.25
                decay = np.exp(-norm_t * (4.5 if event_kind in {"impact", "soft_hit", "tick"} else 1.7))
                if event_kind in {"impact", "soft_hit"}:
                    sweep_freq = 92.0 if event_kind == "impact" else 155.0
                    tone = np.sin(2 * np.pi * (sweep_freq * phase_t - 24.0 * phase_t * phase_t))
                    upper = 0.18 * np.sin(2 * np.pi * (sweep_freq * 2.7) * phase_t + 0.3)
                    mono = (tone + upper) * envelope * decay
                elif event_kind == "tick":
                    mono = np.sin(2 * np.pi * 1450.0 * phase_t) * envelope * decay
                elif event_kind == "riser":
                    sweep = 180.0 + 1600.0 * np.square(norm_t)
                    mono = (0.48 * np.sin(2 * np.pi * sweep * phase_t) + 0.25 * texture) * envelope
                elif event_kind == "ambience":
                    mono = texture * envelope * 2.5
                else:  # whoosh: a soft noise-and-tone sweep, not a harsh white-noise blast
                    sweep = 220.0 + 850.0 * norm_t
                    mono = (0.55 * np.sin(2 * np.pi * sweep * phase_t) + 0.35 * texture) * envelope
                left += mono * event_gain * math.sqrt((1.0 - pan) * 0.5)
                right += mono * event_gain * math.sqrt((1.0 + pan) * 0.5)

            # Crossfade edges and use a soft saturator as a safety limiter.
            fade_len = min(int(sample_rate * 2.2), total_samples // 2)
            if fade_len:
                fade_in = np.clip(indices / fade_len, 0.0, 1.0)
                fade_out = np.clip((total_samples - 1 - indices) / fade_len, 0.0, 1.0)
                edge = np.minimum(fade_in, fade_out)
                left *= edge
                right *= edge
            left = np.tanh(left * 1.18) / np.tanh(1.18)
            right = np.tanh(right * 1.18) / np.tanh(1.18)
            stereo = np.stack((left, right), axis=1)
            pcm = (np.clip(stereo, -0.98, 0.98) * 32767.0).astype("<i2")
            wav.writeframes(pcm.tobytes())

    return {
        "style": style,
        "bpm": bpm,
        "sample_rate": sample_rate,
        "channels": 2,
        "duration": int(duration),
        "seed": _stable_seed(seed, style, duration),
        "layers": 6 if transition_events and profile["arp"] else 5 if profile["arp"] else 4,
        "transition_effects": len(transition_events or []),
        "sound_events": len(events),
        "energy_curve_points": len(curve),
        "peak_safe": True,
    }
