from __future__ import annotations

import hashlib
import json
import math
import re
from typing import Any

from .audit import audit_plan, repair_plan
from .providers import ProviderError, complete_text, complete_nestapi_ensemble, complete_gemini_ensemble
from .prompts import SYSTEM_PROMPT
from .schemas import Scene, SoundEvent, VideoPlan, VideoRequest
from .storage import get_project_provider_context, get_provider_settings, save_project_provider_context, init_storage

STYLE_LABELS = {
    "cinematic": "سینمایی و دراماتیک", "minimal": "مینیمال و خلوت",
    "documentary": "مستند و اطلاعاتی", "motion": "موشن‌گرافیک تکنولوژیک",
    "cyberpunk": "سایبرپانک نئونی", "retro": "رترو و آنالوگ",
    "luxury": "لوکس و مینیمال", "nature": "طبیعت و ارگانیک",
    "corporate": "شرکتی و مدرن", "dream": "رویایی و اتمسفریک",
}

MOTIF_ROTATION = ["network", "topography", "timeline", "waveform", "orbit", "bars", "concentric", "ribbon", "typography", "maplines", "nodes", "architecture", "particles", "spiral", "constellation", "flow", "contour", "radial"]
MOTION_ROTATION = ["reveal", "parallax", "pan", "orbit", "rise", "drift", "slow_zoom", "sweep", "float", "ken_burns", "pulse", "elastic"]
LAYOUT_ROTATION = ["center", "left", "right", "diagonal", "split", "upper", "lower"]


def _allocate_exact(total: int, weights: list[float]) -> list[int]:
    """Largest-remainder allocation with a strict one-second minimum per scene."""
    if total <= 0 or not weights:
        return []
    count = min(len(weights), total)
    safe = [max(0.0001, float(x)) for x in weights[:count]]
    remaining = total - count
    weight_sum = sum(safe)
    exact = [remaining * x / weight_sum for x in safe]
    floors = [math.floor(x) for x in exact]
    result = [1 + x for x in floors]
    residue = remaining - sum(floors)
    order = sorted(range(count), key=lambda i: (exact[i] - floors[i], -i), reverse=True)
    for index in order[:residue]:
        result[index] += 1
    return result


def _extract_json(content: str) -> dict[str, Any]:
    content = content.strip().lstrip("\ufeff")
    content = re.sub(r"^```(?:json)?\s*", "", content, flags=re.I)
    content = re.sub(r"\s*```$", "", content)
    start, end = content.find("{"), content.rfind("}")
    if start < 0 or end < start:
        raise ValueError("پاسخ مدل JSON معتبر نداشت.")
    parsed = json.loads(content[start:end + 1])
    if not isinstance(parsed, dict):
        raise ValueError("ریشه JSON باید یک شیء باشد.")
    return parsed


def _fallback_subject(prompt: str) -> str:
    """Extract a compact topic from a longer creative brief without keyword overreach."""
    value = re.sub(r"\s+", " ", prompt).strip(" .،؛:!؟")
    value = value.replace("\u200c", " ")
    prefixes = (
        "یک ویدیوی ", "ویدیوی ", "یک ویدیو ", "ویدیو ", "یک فیلم ", "فیلم ",
        "یک موشن گرافیک ", "موشن گرافیک ", "لطفاً ", "لطفا ", "بساز ",
    )
    for prefix in prefixes:
        if value.startswith(prefix):
            value = value[len(prefix):]
            break
    markers = ("درباره ", "در مورد ", "با موضوع ", "پیرامون ")
    for marker in markers:
        if value.startswith(marker):
            value = value[len(marker):]
            break
        spaced = " " + marker
        if spaced in value:
            value = value.split(spaced, 1)[1]
            break
    # The first clause is usually the subject; later clauses are art direction or production notes.
    value = re.split(r"[؛;\n.!؟]", value, maxsplit=1)[0]
    value = re.sub(r"\s+(بساز|بسازید|تهیه کن|درست کن|تولید کن)$", "", value).strip()
    value = re.sub(r"^(سینمایی|مستند|تبلیغاتی|آموزشی|تکنولوژیک)\s+", "", value)
    return value[:72].strip(" ،؛:!؟.-") or "ایده و آینده"


def _semantic_domain(text: str) -> str:
    """Classify topic with word/phrase boundaries to avoid accidental substring hits."""
    normalized = re.sub(r"[\u200c\u200f\ufeff]", " ", text.lower())
    normalized = re.sub(r"\s+", " ", normalized).strip()
    groups = {
        "technology": ("هوش مصنوعی", "تکنولوژی", "فناوری", "ربات", "کد", "نرم افزار", "software", "ai", "data", "شبکه", "سیستم", "برنامه نویسی"),
        "nature": ("طبیعت", "جنگل", "دریا", "اقیانوس", "کوه", "گیاه", "حیات", "nature", "ocean", "forest", "آبشار"),
        "business": ("کسب و کار", "اقتصاد", "بازار", "سرمایه", "شرکت", "فروش", "مالی", "business", "market", "finance", "برند"),
        "science": ("علم", "فضا", "اتم", "فیزیک", "زیست", "آزمایش", "science", "space", "physics", "نجوم", "کیهان"),
        "education": ("آموزش", "یادگیری", "مدرسه", "دانش", "تاریخ", "کتاب", "education", "learning", "درس"),
        "human": ("انسان", "شخصیت", "زندگی", "انگیزه", "رویا", "ذهن", "human", "people", "life", "روابط"),
    }
    scores: dict[str, int] = {}
    for name, terms in groups.items():
        score = 0
        for term in terms:
            # Unicode \w boundaries work for Persian and English, unlike raw substring search.
            if re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", normalized):
                score += 1
        scores[name] = score
    best = max(scores.values(), default=0)
    return max(scores, key=scores.get) if best else "abstract"


def fallback_plan(request: VideoRequest) -> VideoPlan:
    """Content-conditioned offline storyboard, not a fixed four-scene template."""
    subject = _fallback_subject(request.prompt)
    domain = _semantic_domain(request.prompt)
    # More time permits additional narrative beats, not merely stretching a few slides.
    target_seconds_per_scene = {"minimal": 13, "documentary": 10, "education": 9, "motion": 8}.get(request.style, 10)
    count = max(3, min(24, math.ceil(request.duration / target_seconds_per_scene)))
    count = min(count, request.duration)
    seed = int.from_bytes(hashlib.sha256((request.prompt + request.style).encode("utf-8")).digest()[:4], "big")
    offset = seed % len(MOTIF_ROTATION)

    story_by_domain = {
        "technology": [
            ("جرقه مسئله", "موضوع در یک میدان انتزاعی شکل می‌گیرد", "intro", "radial", "reveal", "center"),
            ("اجزای پنهان", "اجزای مستقل و ارتباط میان آن‌ها آشکار می‌شوند", "technology", "network", "parallax", "split"),
            ("جریان اطلاعات", "مسیرها و لایه‌ها به یک ساختار منسجم می‌رسند", "data", "flow", "orbit", "diagonal"),
            ("نقطه تحول", "یک الگوی تازه از دل داده‌ها پدیدار می‌شود", "process", "waveform", "sweep", "right"),
            ("چشم‌انداز", "اجزای کلیدی در یک نمای واحد جمع می‌شوند", "detail", "architecture", "slow_zoom", "left"),
            ("افق بعدی", "ساختار در قاب نهایی تثبیت می‌شود", "outro", "constellation", "float", "center"),
        ],
        "nature": [
            ("نفس نخست", "فضا آرام و بافت محیط نمایان می‌شود", "intro", "topography", "drift", "center"),
            ("ریتم محیط", "جریان‌ها و خطوط طبیعی در لایه‌ها حرکت می‌کنند", "process", "contour", "float", "diagonal"),
            ("پیوندها", "اجزا در یک الگوی زنده به هم متصل می‌شوند", "technology", "ribbon", "parallax", "left"),
            ("گسترش", "موج‌ها و حلقه‌ها دامنه تصویر را توسعه می‌دهند", "abstract", "orbit", "orbit", "right"),
            ("تعادل", "حرکت به یک ترکیب‌بندی خلوت و متعادل می‌رسد", "detail", "radial", "slow_zoom", "upper"),
            ("ماندگاری", "تصویر در یک پایان آرام و روشن محو می‌شود", "outro", "waveform", "rise", "center"),
        ],
        "business": [
            ("نقطه شروع", "مسئله یا فرصت در یک قاب شفاف تعریف می‌شود", "intro", "radial", "reveal", "left"),
            ("ساختار بازار", "رابطه اجزا و جریان‌ها بدون داده ساختگی نمایش داده می‌شود", "data", "bars", "pan", "split"),
            ("اتصال عوامل", "لایه‌های تصمیم و فرایند به هم پیوند می‌خورند", "technology", "network", "parallax", "right"),
            ("تغییر مسیر", "یک مسیر بصری تازه از میان خطوط شکل می‌گیرد", "process", "timeline", "sweep", "diagonal"),
            ("نتیجه‌گیری", "عناصر مهم در یک قاب منظم جمع می‌شوند", "detail", "architecture", "slow_zoom", "lower"),
            ("گام بعدی", "پایان با یک پیام روشن و فضای تنفس", "outro", "concentric", "float", "center"),
        ],
        "science": [
            ("پرسش آغازین", "یک پدیده در فضای تاریک و دقیق نمایان می‌شود", "intro", "radial", "reveal", "center"),
            ("ساختار", "لایه‌ها و روابط در یک تصویر شماتیک باز می‌شوند", "technology", "architecture", "parallax", "split"),
            ("الگو", "ریتم و تکرار کنترل‌شده یک الگوی قابل مشاهده می‌سازد", "data", "waveform", "orbit", "right"),
            ("مقیاس", "مقیاس دید تغییر می‌کند و جزئیات برجسته می‌شوند", "detail", "spiral", "ken_burns", "left"),
            ("ارتباط", "مسیرها به یک ساختار واحد می‌رسند", "process", "constellation", "sweep", "diagonal"),
            ("کشف", "ترکیب نهایی با تمرکز بصری مشخص تثبیت می‌شود", "outro", "orbit", "slow_zoom", "center"),
        ],
        "education": [
            ("سؤال اصلی", "موضوع با یک پرسش بصری روشن معرفی می‌شود", "intro", "typography", "reveal", "upper"),
            ("مفهوم پایه", "مفهوم به اجزای ساده و قابل دنبال‌کردن تقسیم می‌شود", "detail", "architecture", "rise", "left"),
            ("رابطه‌ها", "رابطه میان اجزا به شکل مسیر و نمودار نشان داده می‌شود", "data", "timeline", "pan", "split"),
            ("نمونه تصویری", "یک نمونه شماتیک، مفهوم را به تصویر تبدیل می‌کند", "process", "flow", "parallax", "right"),
            ("جمع‌بندی", "نکته‌های اصلی در چیدمانی خلوت تثبیت می‌شوند", "detail", "concentric", "slow_zoom", "lower"),
            ("یادآوری", "پایان ساده و ماندگار با فضای کافی برای متن", "outro", "radial", "float", "center"),
        ],
        "human": [
            ("لحظه آغاز", "یک نشانه انسانی و نزدیک در قاب خلوت پدیدار می‌شود", "intro", "radial", "drift", "center"),
            ("لایه‌های ذهن", "لایه‌ها و خطوط نرم، پیچیدگی درونی را نشان می‌دهند", "abstract", "ribbon", "float", "diagonal"),
            ("انتخاب‌ها", "چند مسیر بصری از یک نقطه آغاز می‌شوند", "process", "timeline", "orbit", "split"),
            ("تغییر", "ترکیب حرکت به سمت یک مسیر تازه هدایت می‌شود", "detail", "waveform", "rise", "right"),
            ("معنا", "عناصر اضافی حذف و پیام اصلی برجسته می‌شود", "quote", "typography", "slow_zoom", "lower"),
            ("ادامه", "پایان باز و آرام، بدون اغراق تصویری", "outro", "constellation", "drift", "center"),
        ],
        "abstract": [
            ("جرقه بصری", "فرم اصلی از یک نقطه نور و چند سطح نرم آغاز می‌شود", "intro", "radial", "reveal", "center"),
            ("گسترش فرم", "مسیرهای منحنی و لایه‌های شفاف فضای جدیدی می‌سازند", "abstract", "ribbon", "orbit", "diagonal"),
            ("ریتم", "اشکال با فاصله و سرعت متفاوت وارد قاب می‌شوند", "process", "spiral", "sweep", "right"),
            ("تراکم و رهایی", "فرم‌ها به‌تدریج به ترکیبی منظم تبدیل می‌شوند", "detail", "concentric", "parallax", "left"),
            ("تعادل نهایی", "یک فرم مرکزی با فضای منفی کافی باقی می‌ماند", "outro", "topography", "slow_zoom", "center"),
        ],
    }
    beats = story_by_domain[domain]
    chosen = []
    for idx in range(count):
        base = beats[(idx + (1 if seed % 3 == 1 else 0)) % len(beats)]
        title, subtitle, kind, motif, motion, composition = base
        # Beyond the domain's core beats, add a distinct visual question/detail rather than
        # duplicating the same scene with only a different title.
        if idx >= len(beats):
            variation = idx - len(beats) + 1
            title = f"{title} - لایه {variation}"
            subtitle = f"{subject}: {subtitle}؛ این بار با تأکید بر بُعد {['مقیاس','رابطه','ریتم','جزئیات','پیامد'][variation % 5]}"
            kind = ["detail", "process", "abstract", "data"][variation % 4]
            motif = MOTIF_ROTATION[(MOTIF_ROTATION.index(motif) + variation * 3) % len(MOTIF_ROTATION)]
            motion = MOTION_ROTATION[(MOTION_ROTATION.index(motion) + variation * 2) % len(MOTION_ROTATION)]
            composition = LAYOUT_ROTATION[(LAYOUT_ROTATION.index(composition) + variation) % len(LAYOUT_ROTATION)]
        else:
            motif = MOTIF_ROTATION[(MOTIF_ROTATION.index(motif) + (offset if idx % 2 else 0)) % len(MOTIF_ROTATION)] if motif in MOTIF_ROTATION else motif
        chosen.append((title, subtitle, kind, motif, motion, composition))
    raw_weights = [1.0 + ((seed >> (idx % 24)) & 7) / 20.0 + (0.15 if idx in {0, count-1} else 0) for idx in range(count)]
    durations = _allocate_exact(request.duration, raw_weights)
    scenes: list[Scene] = []
    for idx, (title, subtitle, kind, motif, motion, composition) in enumerate(chosen):
        selected_motif = motif
        # Avoid mixing a long English source prompt into Persian poster titles.
        # The brief remains in project metadata and image prompts; the visible
        # fallback title uses the selected UI language consistently.
        scene_title = title
        visual_note = f"موضوع «{subject}»؛ {subtitle}. موتیف {selected_motif}، کادر {composition}، حرکت {motion}؛ کنتراست متناسب با سبک {STYLE_LABELS[request.style]}؛ داده و عدد واقعی جعل نشود."
        focal = [(0.50, 0.36), (0.36, 0.40), (0.64, 0.38), (0.50, 0.44), (0.42, 0.34), (0.58, 0.40), (0.48,0.52), (0.60,0.31)][idx % 8]
        scenes.append(Scene(
            title=scene_title, subtitle=subtitle, kind=kind, duration=durations[idx], motion=motion,
            visual_note=visual_note[:500], motif=selected_motif, composition=composition,
            focal_x=focal[0], focal_y=focal[1], scale_from=0.93 + (idx % 4) * 0.025,
            scale_to=1.01 + ((idx + 1) % 4) * 0.022, detail_level=1 + (idx % 4),
            transition="cut" if idx == 0 else ["dissolve", "slide", "wipe", "lightleak"][(seed + idx) % 4],
            image_prompt=(
                f"Create a premium cinematic still image for a short film about {subject}. "
                f"This exact shot is: {title}. Visual event: {subtitle}. "
                f"Distinct visual treatment: {selected_motif}; composition: {composition}; "
                f"camera movement intention: {motion}. Shot {idx + 1} of {count}; do not repeat the same subject framing as other shots. "
                f"Art direction: {STYLE_LABELS[request.style]}, sophisticated lighting, tactile materials, atmospheric depth, strong subject separation, "
                f"intentional negative space for later Persian title overlay. "
                "No words, no letters, no captions, no logo, no watermark, no interface, no borders. "
                "One coherent scene, carefully composed, polished cinematic production still."
            )[:1700],
            camera_path=f"{motion}; focal point {focal[0]:.2f},{focal[1]:.2f}; scale {0.93 + (idx % 4) * 0.025:.2f} to {1.01 + ((idx + 1) % 4) * 0.022:.2f}",
        ))
    return VideoPlan(
        project_title=f"{subject[:70]} | CineForge",
        creative_direction=f"یک طراحی اختصاصی {STYLE_LABELS[request.style]} بر پایه موضوع «{subject}»، با انتخاب موتیف‌های مرتبط با حوزه {domain}، ترکیب‌بندی متغیر، فضای منفی، نور کنترل‌شده و حرکت نرم.",
        narrative_arc=f"روایت از معرفی دقیق «{subject}» آغاز می‌شود، سازوکار یا لایه‌های مرتبط را باز می‌کند، به لحظه اصلی می‌رسد و با جمع‌بندی بصری متناسب پایان می‌یابد.",
        director_notes="این سناریو در حالت محلی تولید شده؛ برای تحلیل زبانی عمیق‌تر، مدل متنی را فعال کن. موتیف‌ها و ترتیب صحنه‌ها بر اساس موضوع و اثرانگشت درخواست تغییر کرده‌اند.",
        visual_bible=f"{STYLE_LABELS[request.style]}; palette {request.accent_palette}; controlled contrast, coherent material language, consistent world identity, varied shot scale and camera angle.",
        subject_anchor=f"موضوع ثابت پروژه: {subject}. در همه صحنه‌ها فقط هویت و نشانه‌های اصلی موضوع ثابت بماند؛ پس‌زمینه، فاصله دوربین و کنش بصری هر صحنه باید واقعاً متفاوت باشد.",
        music_mood="auto",
        music_tempo_bpm=request.music_tempo,
        music_direction="موسیقی بر اساس حس درخواست انتخاب شود؛ ملودی و هارمونی آرام، بدون تداخل با پیام اصلی.",
        music_energy_curve=[0.25, 0.38, 0.64, 0.48, 0.30],
        sound_events=[SoundEvent(time_seconds=float(sum(scene.duration for scene in scenes[:idx])), kind="whoosh", intensity=0.22, duration=0.55, pan=(-0.35 if idx % 2 else 0.35)) for idx in range(1, len(scenes)) if scenes[idx].transition != "cut"],
        sound_design_notes="افکت گذار کم‌حجم، بدون ضربه تیز؛ فضای اصلی موسیقی باید خوانایی روایت را حفظ کند.",
        scenes=scenes,
    )


CONCEPT_SYSTEM_PROMPT = """
تو مدیر خلاق پروژه و تحلیل‌گر روایت هستی. توضیح کاربر را به یک طرح مفهومی اجرایی تبدیل کن؛ زنجیره فکر خصوصی را افشا نکن و فقط نتیجه‌های قابل استفاده را برگردان.
فقط JSON معتبر با کلیدهای concept_title، intent، core_message، audience_tone، original_angle، visual_metaphor، narrative_beats (آرایه 3 تا 8 رشته)، palette_logic، pacing_logic، avoid_list (آرایه رشته) و continuity_rules برگردان.
طرح باید به خود موضوع وابسته باشد، نه یک قالب ثابت. استعاره تصویری باید در موتور دوبعدی با هندسه، مسیر، متن، لایه، نور و ذرات قابل اجرا باشد. داده ساختگی، اعداد گمراه‌کننده یا ادعای فوتیج واقعی نساز. برای ویرایش، تغییرات را محدود به خواسته کاربر کن و بقیه هویت پروژه را حفظ کن.
""".strip()


def build_concept_prompt(request: VideoRequest, previous_plan: dict | None = None, edit_instruction: str | None = None, recent_messages: list[dict] | None = None, agent_reports: list[dict[str, str]] | None = None) -> str:
    payload = {
        "brief": request.prompt,
        "duration_seconds": request.duration,
        "format": request.aspect_ratio,
        "style": request.style,
        "palette": request.accent_palette,
        "motion_intensity": request.motion_intensity,
        "text_density": request.text_density,
        "language": request.language,
    }
    parts = [CONCEPT_SYSTEM_PROMPT, "PROJECT CONSTRAINTS:", json.dumps(payload, ensure_ascii=False, indent=2)]
    if agent_reports:
        parts.extend(["PARALLEL SPECIALIST AGENT DELIVERABLES (merge, reconcile conflicts, do not copy blindly):", json.dumps(agent_reports, ensure_ascii=False, indent=2)])
    if previous_plan:
        parts.extend(["EXISTING APPROVED PROJECT PLAN:", json.dumps(previous_plan, ensure_ascii=False, indent=2)])
    if recent_messages:
        parts.extend(["RECENT PROJECT MESSAGES:", json.dumps(recent_messages[-10:], ensure_ascii=False, indent=2)])
    if edit_instruction:
        parts.extend(["USER EDIT INSTRUCTION:", edit_instruction, "Preserve everything not requested to change."])
    parts.append("Return only the concept JSON. Do not include private reasoning or chain-of-thought.")
    return "\n\n".join(parts)


def build_director_prompt(request: VideoRequest, previous_plan: dict | None = None, edit_instruction: str | None = None, recent_messages: list[dict] | None = None, creative_concept: dict | None = None, agent_reports: list[dict[str, str]] | None = None) -> str:
    constraints = {
        "user_brief": request.prompt,
        "duration_seconds_exact": request.duration,
        "aspect_ratio": request.aspect_ratio,
        "resolution": request.resolution,
        "fps": request.fps,
        "visual_style": STYLE_LABELS[request.style],
        "accent_palette": request.accent_palette,
        "accent_color": request.accent_color,
        "motion_intensity": request.motion_intensity,
        "text_density": request.text_density,
        "language": "Persian" if request.language == "fa" else "English",
        "brand_label": request.brand_label if request.include_branding else "none",
        "closing_text": request.closing_text,
        "music_style": request.music_style,
        "music_tempo_bpm_preference": request.music_tempo,
        "sound_design": "Create a mood-matched original score with a restrained energy curve and timestamped transition events.",
        "render_quality": request.render_quality,
        "maximum_scene_count": min(24, max(3, math.ceil(request.duration / 8))),
    }
    blocks = [SYSTEM_PROMPT, "مشخصات دقیق پروژه:", json.dumps(constraints, ensure_ascii=False, indent=2)]
    if creative_concept:
        blocks += ["CONCEPT DIRECTOR APPROVED BRIEF (use it as the creative source of truth):", json.dumps(creative_concept, ensure_ascii=False, indent=2)]
    if agent_reports:
        blocks += ["SPECIALIST AGENT DELIVERABLES (resolve disagreements and turn them into concrete per-scene decisions):", json.dumps(agent_reports, ensure_ascii=False, indent=2)]
    if previous_plan:
        blocks += [
            "آخرین نسخه سناریو که باید به‌عنوان مبنای ویرایش استفاده شود (از صفر بازنویسی نکن مگر درخواست کاربر صریح باشد):",
            json.dumps(previous_plan, ensure_ascii=False, indent=2),
        ]
    if recent_messages:
        blocks += ["خلاصه پیام‌های قبلی پروژه:", json.dumps(recent_messages[-12:], ensure_ascii=False, indent=2)]
    if edit_instruction:
        blocks += [
            "دستور ویرایش کاربر:", edit_instruction,
            "این دستور را نسبت به نسخه قبلی تفسیر کن. بخش‌های بدون درخواست تغییر را تا حد ممکن حفظ کن؛ اگر یک صحنه مشخص شده فقط همان صحنه و وابستگی‌های لازم را اصلاح کن. در خروجی، کل سناریوی نهایی را برگردان.",
        ]
    blocks.append("اکنون فقط JSON معتبر مطابق schema در دستور سیستم برگردان. زمان تمام صحنه‌ها باید دقیقاً با مدت درخواستی برابر باشد.")
    return "\n\n".join(blocks)


def _normalise_plan(data: dict[str, Any], duration: int, request: VideoRequest | None = None) -> VideoPlan:
    raw_scenes = data.get("scenes")
    if not isinstance(raw_scenes, list) or not raw_scenes:
        raise ValueError("مدل هیچ صحنه‌ای تولید نکرد.")
    cleaned: list[Scene] = []
    for raw in raw_scenes[:24]:
        if not isinstance(raw, dict):
            continue
        try:
            cleaned.append(Scene.model_validate(raw))
        except Exception:
            continue
    if not cleaned:
        raise ValueError("ساختار صحنه‌های خروجی مدل نامعتبر است.")
    cleaned = cleaned[:min(len(cleaned), duration)]
    exact_durations = _allocate_exact(duration, [scene.duration for scene in cleaned])
    for scene, seconds in zip(cleaned, exact_durations):
        scene.duration = seconds
    if len(cleaned) >= 2:
        cleaned[0].kind = "intro"
        cleaned[-1].kind = "outro"
    raw_energy = data.get("music_energy_curve")
    if not isinstance(raw_energy, list):
        raw_energy = []
    raw_events = data.get("sound_events")
    if not isinstance(raw_events, list):
        raw_events = []
    plan = VideoPlan(
        project_title=str(data.get("project_title") or "CineForge Project")[:100],
        creative_direction=str(data.get("creative_direction") or "طراحی اختصاصی ویدیویی")[:1200],
        narrative_arc=str(data.get("narrative_arc") or "")[:1000],
        director_notes=str(data.get("director_notes") or "")[:1600],
        visual_bible=str(data.get("visual_bible") or "")[:1600],
        subject_anchor=str(data.get("subject_anchor") or "")[:800],
        music_mood=data.get("music_mood", "auto") if data.get("music_mood", "auto") in {"auto", "none", "mellow", "cinematic", "pulse", "ambient", "hopeful", "dark", "epic", "focus", "playful", "tension", "dreamy", "emotional", "electronic", "documentary"} else "auto",
        music_tempo_bpm=max(0, min(160, int(data.get("music_tempo_bpm", 0) or 0))),
        music_direction=str(data.get("music_direction") or "")[:700],
        music_energy_curve=[max(0.0, min(1.0, float(v))) for v in raw_energy[:24] if isinstance(v, (int, float))],
        sound_events=[SoundEvent.model_validate(item) for item in raw_events[:36] if isinstance(item, dict)],
        sound_design_notes=str(data.get("sound_design_notes") or "")[:700],
        scenes=cleaned,
    )
    if request:
        plan, _ = repair_plan(request, plan)
    return plan


def create_plan(request: VideoRequest, previous_plan: dict | None = None, edit_instruction: str | None = None, recent_messages: list[dict] | None = None) -> tuple[VideoPlan, str, str, str | None, dict[str, Any]]:
    if request.plan_override is not None:
        plan, report = repair_plan(request, request.plan_override)
        return plan, request.plan_source or "fallback", "از سناریوی تأییدشده استفاده شد.", request.plan_model, report
    if not request.use_ai or request.ai_provider == "local":
        plan, report = repair_plan(request, fallback_plan(request))
        return plan, "fallback", "برنامه‌ریز محلی مبتنی بر موضوع فعال بود.", None, report
    # Planner can also be imported and used directly outside FastAPI startup.
    init_storage()
    settings = get_provider_settings()
    provider = request.ai_provider or settings["provider"]
    model = request.ai_model or (settings["gemini_model"] if provider == "gemini" else settings["nestapi_model"])
    if provider == "gemini" and model in {"auto", "gpt5", "gpt4o"}:
        model = settings.get("gemini_model") or "gemini-3.8-flash"
    provider_context = get_project_provider_context(request.project_id) if request.project_id else {}
    provider_context = provider_context.get(provider, {}) if isinstance(provider_context, dict) else {}
    try:
        # Parallel specialist agents are enabled for the documented NestAPI model
        # router. They return concise deliverables; a director model synthesizes
        # them into one consistent plan after independent work completes.
        agent_reports: list[dict[str, str]] = []
        agent_warning = ""
        if request.multi_agent and provider in {"nestapi", "gemini"}:
            try:
                agent_prompt = (
                    build_concept_prompt(request, previous_plan, edit_instruction, recent_messages)
                    + "\n\nReturn domain-specific decisions only; do not create the final storyboard JSON."
                )
                if provider == "nestapi":
                    agent_reports = complete_nestapi_ensemble(prompt=agent_prompt, language=request.language)
                else:
                    agent_reports = complete_gemini_ensemble(
                        prompt=agent_prompt, model=model, api_key=settings.get("gemini_api_key", ""),
                        language=request.language,
                    )
            except Exception as agent_exc:
                # A failed specialist should not prevent the configured director
                # from making a single-model plan.
                agent_warning = f"عامل‌های موازی در دسترس نبودند ({type(agent_exc).__name__})؛ کارگردان اصلی ادامه داد."

        # Pass 1: develop a subject-specific creative concept and narrative strategy.
        concept_text, concept_context = complete_text(
            provider=provider, model=model,
            prompt=build_concept_prompt(request, previous_plan, edit_instruction, recent_messages, agent_reports),
            language=request.language, api_key=settings.get("gemini_api_key", ""),
            context=provider_context,
        )
        concept = _extract_json(concept_text)
        required_concept = {"core_message", "original_angle", "visual_metaphor", "narrative_beats"}
        if not required_concept.issubset(concept):
            raise ValueError("طرح مفهومی مدل ناقص بود؛ مرحله دوم آغاز نشد.")

        # Pass 2: convert the approved concept into exact scene, timing and motion instructions.
        plan_text, final_context = complete_text(
            provider=provider, model=model,
            prompt=build_director_prompt(request, previous_plan, edit_instruction, recent_messages, concept, agent_reports),
            language=request.language, api_key=settings.get("gemini_api_key", ""),
            context=concept_context or provider_context,
        )
        data = _extract_json(plan_text)
        plan = _normalise_plan(data, request.duration, request)
        report = audit_plan(request, plan)
        if report["issue_count"]:
            plan, report = repair_plan(request, plan)
        if request.project_id and final_context:
            save_project_provider_context(request.project_id, provider, final_context)
        agent_note = f"؛ {len(agent_reports)} عامل تخصصی به‌صورت موازی مشارکت کردند" if agent_reports else ""
        if agent_warning:
            agent_note += f"؛ {agent_warning}"
        return plan, "ai", f"طرح مفهومی و نقشه اجرایی در دو مرحله با {provider}/{model} تولید و ممیزی شد{agent_note}.", model, report
    except Exception as exc:
        plan, report = repair_plan(request, fallback_plan(request))
        reason = str(exc)[:140]
        return plan, "fallback", f"اتصال/خروجی مدل در یکی از مراحل قابل‌استفاده نبود؛ طرح محلی موضوع‌محور جایگزین شد ({type(exc).__name__}: {reason}).", None, report
