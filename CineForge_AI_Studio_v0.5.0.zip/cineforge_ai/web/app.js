const $ = (id) => document.getElementById(id);
const state = {
  jobId: null, pollTimer: null, plan: null, planner: "fallback", planModel: null,
  projectId: null, lastDownloadUrl: null, selectedProject: null, savedSettings: null
};
const preferenceIds = [
  "duration", "aspect", "resolution", "fps", "quality", "language", "style", "accent",
  "motionIntensity", "textDensity", "brandLabel", "closingText", "music", "volume",
  "aiProvider", "aiModel", "visualEngine", "imageQuality", "upscaleScale", "upscaleImages", "refineImages", "multiAgent", "musicTempo", "voiceoverVoice", "voiceoverText", "allowFallback", "useAI", "customColor", "showGrid", "showParticles", "showProgress", "branding"
];
const nestModels = [
  ["gpt5", "GPT-5"], ["gpt4o", "GPT-4o"], ["claude45", "Claude 4.5"],
  ["gemini3", "Gemini 3"], ["grok41", "Grok 4.1"], ["auto", "Auto"]
];
function faNumber(value) { return String(value).replace(/[0-9]/g, d => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]); }
function setPipeline(name, value) {
  const el = $(name); if (!el) return;
  el.textContent = value;
  el.className = value === "DONE" ? "done" : value === "RUNNING" ? "active" : value === "ERROR" ? "error" : "";
}
function setProgress(value, message) {
  const safe = Math.max(0, Math.min(100, Number(value) || 0));
  $("progressBar").style.width = `${safe}%`;
  $("progressText").textContent = `${faNumber(Math.round(safe))}٪`;
  if (message) $("jobMessage").textContent = message;
}
function savePreferences() {
  const values = {};
  for (const id of preferenceIds) {
    const el = $(id); if (!el) continue;
    values[id] = el.type === "checkbox" ? el.checked : el.value;
  }
  try { localStorage.setItem("cineforge.preferences.v05", JSON.stringify(values)); } catch {}
}
function restorePreferences() {
  try {
    const values = JSON.parse(localStorage.getItem("cineforge.preferences.v05") || "{}");
    for (const [id, value] of Object.entries(values)) {
      const el = $(id); if (!el) continue;
      if (el.type === "checkbox") el.checked = Boolean(value); else el.value = value;
    }
  } catch {}
}
function populateModelSelect(provider, preferred) {
  const select = $("aiModel");
  const selectedProvider = provider || $("aiProvider").value;
  select.replaceChildren();
  if (selectedProvider === "nestapi") {
    for (const [value, label] of nestModels) select.add(new Option(label, value));
    if (preferred && !nestModels.some(x => x[0] === preferred)) select.add(new Option(`شناسه سفارشی · ${preferred}`, preferred));
    select.value = preferred || "gpt5";
    $("providerHint").textContent = "NestAPI عمومی است. مدل‌های GPT-5، GPT-4o، Claude 4.5، Gemini 3، Grok 4.1 و Auto در مستندات سرویس آمده‌اند.";
  } else if (selectedProvider === "gemini") {
    const id = $("geminiModel")?.value?.trim() || state.savedSettings?.gemini_model || "gemini-3.8-flash";
    select.add(new Option(id, id));
    select.value = id;
    $("providerHint").textContent = state.savedSettings?.gemini_configured ? "کلید Gemini ذخیره شده است؛ مدل بر اساس شناسه واردشده در تنظیمات فراخوانی می‌شود." : "برای استفاده از Gemini ابتدا API Key را در صفحه مدل‌ها و تنظیمات ذخیره کن.";
  } else {
    select.add(new Option("Local Planner", "local"));
    select.value = "local";
    $("providerHint").textContent = "برنامه‌ریز داخلی بدون اتصال به API کار می‌کند؛ برای فهم عمیق‌تر توضیحات، NestAPI یا Gemini را انتخاب کن.";
  }
}
function payload() {
  const color = $("customColor").value;
  const provider = $("aiProvider").value;
  return {
    prompt: $("prompt").value.trim(),
    duration: Number($("duration").value),
    aspect_ratio: $("aspect").value,
    resolution: $("resolution").value,
    fps: Number($("fps").value),
    style: $("style").value,
    accent_palette: $("accent").value,
    accent_color: color && color.toLowerCase() !== "#52bff2" ? color : null,
    motion_intensity: $("motionIntensity").value,
    text_density: $("textDensity").value,
    music_style: $("music").value,
    music_volume: Number($("volume").value),
    music_tempo: Number($("musicTempo").value),
    voiceover_text: $("voiceoverText").value.trim(),
    voiceover_voice: $("voiceoverVoice").value,
    multi_agent: $("multiAgent").checked,
    refine_images: $("refineImages").checked,
    render_quality: $("quality").value,
    visual_engine: $("visualEngine").value,
    image_quality: $("imageQuality").value,
    upscale_images: $("upscaleImages").checked,
    upscale_scale: Number($("upscaleScale").value),
    allow_procedural_fallback: $("allowFallback").checked,
    language: $("language").value,
    brand_label: $("brandLabel").value.trim(),
    closing_text: $("closingText").value.trim(),
    show_grid: $("showGrid").checked,
    show_particles: $("showParticles").checked,
    show_progress: $("showProgress").checked,
    include_branding: $("branding").checked,
    use_ai: provider !== "local",
    ai_provider: provider,
    ai_model: provider === "gemini" ? ($("geminiModel")?.value?.trim() || "gemini-3.8-flash") : $("aiModel").value,
    project_id: state.projectId
  };
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    let detail = data.detail;
    if (Array.isArray(detail)) detail = detail.map(x => x.msg || "خطای اعتبارسنجی").join("؛ ");
    throw new Error(detail || `HTTP ${response.status}`);
  }
  return data;
}
function validBrief() {
  if ($("prompt").value.trim().length < 5) {
    $("jobMessage").textContent = "توضیح ویدیو باید دست‌کم ۵ نویسه باشد.";
    $("prompt").focus(); return false;
  }
  return true;
}
function showView(name) {
  for (const view of ["studio", "library", "settings"]) {
    const page = $(`${view}View`);
    if (page) page.hidden = view !== name;
  }
  document.querySelectorAll("[data-view]").forEach(button => button.classList.toggle("active", button.dataset.view === name));
  if (name === "library") loadProjects();
  if (name === "settings") loadSettings();
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function auditText(report) {
  if (!report) return "گزارش ممیزی دریافت نشد.";
  const issues = report.issue_count ?? (report.issues || []).length;
  const warnings = report.warning_count ?? (report.warnings || []).length;
  const metrics = report.metrics || {};
  return `ممیزی سناریو · ${issues ? `${faNumber(issues)} ایراد` : "بدون ایراد ساختاری"} · ${faNumber(warnings)} هشدار · ${faNumber(metrics.scene_count || 0)} صحنه · ${faNumber(metrics.unique_motifs || 0)} موتیف متفاوت`;
}
function renderPlan(plan, planner, note, model, projectId, audit) {
  state.plan = plan;
  state.planner = planner || "fallback";
  state.planModel = model || null;
  if (projectId) state.projectId = projectId;
  $("storyboardPanel").hidden = false;
  $("plannerNote").textContent = note || "برنامه صحنه‌ها آماده است.";
  $("plannerBadge").textContent = planner === "ai" ? `AI · ${(model || "MODEL").toUpperCase()}` : "LOCAL / REPAIRED";
  $("creativeDirection").textContent = plan.creative_direction || "";
  $("narrativeArc").textContent = plan.narrative_arc || "";
  $("directorNotes").textContent = plan.director_notes || "";
  const auditEl = $("planAudit");
  auditEl.hidden = !audit;
  if (audit) {
    auditEl.textContent = auditText(audit);
    auditEl.classList.toggle("warning", (audit.warning_count || 0) > 0);
  }
  const audioPanel = $("audioPlanPanel");
  const audioDirection = String(plan.music_direction || plan.sound_design_notes || "موسیقی بر اساس حال‌وهوای درخواست انتخاب می‌شود.");
  const bpm = Number(plan.music_tempo_bpm || 0);
  const events = Array.isArray(plan.sound_events) ? plan.sound_events : [];
  const energy = Array.isArray(plan.music_energy_curve) ? plan.music_energy_curve : [];
  audioPanel.hidden = false;
  $("audioPlanMeta").textContent = `${plan.music_mood || "auto"} · ${bpm ? `${faNumber(bpm)} BPM` : "BPM هوشمند"} · ${faNumber(events.length)} رخداد صوتی`;
  $("audioPlanDirection").textContent = audioDirection;
  const energyTrack = $("audioEnergyTrack"); energyTrack.replaceChildren();
  energy.forEach((point, index) => {
    const bar = document.createElement("span");
    bar.style.height = `${Math.max(8, Math.min(100, Number(point) * 100))}%`;
    bar.title = `نقطه ${index + 1}: ${Math.round(Number(point) * 100)}%`;
    energyTrack.append(bar);
  });
  $("audioEventSummary").textContent = events.length
    ? events.map(item => `${faNumber(item.time_seconds)}s · ${item.kind}`).join("  |  ")
    : "افکت‌های انتقال در صورت نیاز به‌صورت خودکار ساخته می‌شوند.";

  const list = $("sceneList"); list.replaceChildren();
  let offset = 0;
  plan.scenes.forEach((scene, index) => {
    const card = document.createElement("article"); card.className = "scene-card";
    const top = document.createElement("div"); top.className = "scene-top";
    const number = document.createElement("span"); number.className = "scene-number"; number.textContent = `SCENE ${String(index + 1).padStart(2,"0")}`;
    const duration = document.createElement("span"); duration.className = "scene-duration";
    duration.textContent = `${faNumber(scene.duration)} ثانیه · ${faNumber(offset)} تا ${faNumber(offset + scene.duration)} ثانیه`;
    offset += scene.duration;
    top.append(number, duration);
    const title = document.createElement("input"); title.className = "scene-title-input"; title.maxLength = 90; title.value = scene.title || "";
    title.setAttribute("aria-label", `عنوان صحنه ${index + 1}`);
    title.addEventListener("input", () => { state.plan.scenes[index].title = title.value; });
    const subtitle = document.createElement("input"); subtitle.className = "scene-subtitle-input"; subtitle.maxLength = 180;
    subtitle.value = scene.subtitle || ""; subtitle.placeholder = "زیرعنوان اختیاری";
    subtitle.setAttribute("aria-label", `زیرعنوان صحنه ${index + 1}`);
    subtitle.addEventListener("input", () => { state.plan.scenes[index].subtitle = subtitle.value; });
    const chips = document.createElement("div"); chips.className = "scene-chips";
    for (const value of [scene.motif || scene.kind, scene.motion, scene.composition, `${scene.transition || "dissolve"}`]) {
      const chip = document.createElement("span"); chip.textContent = value; chips.append(chip);
    }
    const note = document.createElement("p"); note.className = "scene-note"; note.textContent = scene.visual_note || "";
    const details = document.createElement("details"); details.className = "scene-details";
    const summary = document.createElement("summary"); summary.textContent = "دستور تصویر، لنز و حرکت دوربین";
    const imagePrompt = document.createElement("p"); imagePrompt.textContent = scene.image_prompt || "هنوز image prompt مستقلی ثبت نشده است.";
    const cameraPath = document.createElement("small"); cameraPath.textContent = `Camera path: ${scene.camera_path || scene.motion || "—"}`;
    details.append(summary, imagePrompt, cameraPath);
    card.append(top, title, subtitle, chips, note, details); list.append(card);
  });
  $("renderButton").disabled = false;
  $("statusText").textContent = "نقشه اجرایی آماده ممیزی و تأیید است";
  $("jobMessage").textContent = `شناسه پروژه: ${state.projectId || "—"}`;
  $("storyboardPanel").scrollIntoView({ behavior: "smooth", block: "start" });
}
async function designPlan() {
  if (!validBrief()) return;
  savePreferences();
  $("planButton").disabled = true;
  $("planButton").querySelector("span").textContent = "در حال تحلیل و ایده‌پردازی…";
  $("jobMessage").textContent = "کارگردان در حال استخراج مفهوم، قوس روایی، زبان بصری و زمان‌بندی است.";
  setPipeline("statePlan", "RUNNING");
  try {
    const request = payload();
    const result = await api("/api/plan", { method: "POST", body: JSON.stringify(request) });
    renderPlan(result.plan, result.planner, result.note, result.model, result.project_id, result.audit);
    setPipeline("statePlan", "DONE");
    $("previewTitle").textContent = result.plan.project_title || "STORYBOARD READY";
    $("previewSubtitle").textContent = `${result.plan.scenes.length} SCENES · ${request.duration} SEC`;
    await loadProjects(false);
  } catch (error) {
    setPipeline("statePlan", "ERROR"); $("jobMessage").textContent = `طراحی سناریو ناموفق بود: ${error.message}`;
  } finally {
    $("planButton").disabled = false;
    $("planButton").querySelector("span").textContent = "تحلیل دوباره و طراحی سناریو";
  }
}
async function startRender() {
  if (!validBrief()) return;
  if (!state.plan) return designPlan();
  savePreferences();
  if (state.pollTimer) clearTimeout(state.pollTimer);
  $("renderButton").disabled = true; $("confirmRenderButton").disabled = true;
  $("renderButton").querySelector("span").textContent = "در حال ارسال به موتور…";
  $("videoResult").hidden = true; $("downloadButton").hidden = true; $("shareButton").hidden = true;
  $("openProjectButton").hidden = true; $("resultMeta").hidden = true; $("renderAudit").hidden = true;
  $("statusText").textContent = "در حال آماده‌سازی رندر";
  setProgress(1, "طرح تأییدشده وارد صف فریم‌سازی و صداگذاری شد.");
  ["stateVisual", "stateAudio", "stateRender"].forEach(id => setPipeline(id, "WAITING"));
  try {
    const request = { ...payload(), plan_override: state.plan, plan_source: state.planner, plan_model: state.planModel };
    const created = await api("/api/jobs", { method: "POST", body: JSON.stringify(request) });
    state.jobId = created.job_id; state.projectId = created.project_id || state.projectId;
    $("previewTitle").textContent = "RENDERING"; $("previewSubtitle").textContent = "MOTION · PILLOW · FFMPEG";
    $("renderButton").querySelector("span").textContent = "در حال رندر…";
    poll(created.job_id);
  } catch (error) {
    $("renderButton").disabled = false; $("confirmRenderButton").disabled = false;
    $("renderButton").querySelector("span").textContent = "تلاش دوباره برای رندر";
    $("statusText").textContent = "ارسال درخواست ناموفق بود"; setProgress(0, error.message);
  }
}
async function poll(jobId) {
  try {
    const data = await api(`/api/jobs/${jobId}`);
    setProgress(data.progress, data.message);
    $("statusText").textContent = data.status === "completed" ? "رندر و ممیزی کامل شد" : data.status === "failed" ? "تولید ناموفق بود" : data.status === "planning" ? "تحلیل و طراحی سناریو" : "در حال ساخت فریم‌ها و انکود";
    if (data.status === "planning") setPipeline("statePlan", "RUNNING");
    if (data.status === "rendering") {
      setPipeline("statePlan", "DONE");
      const progressMessage = String(data.message || "");
      if (/تصویر|keyframe|asset/i.test(progressMessage)) setPipeline("stateVisual", "RUNNING");
      if (/فریم|دوربین|رندر|انکود/i.test(progressMessage)) setPipeline("stateMotion", "RUNNING");
      if (/صدا|موسیقی|audio/i.test(progressMessage)) setPipeline("stateAudio", "RUNNING");
      if (/رندر|انکود/i.test(progressMessage)) setPipeline("stateRender", "RUNNING");
    }
    if (data.status === "completed") {
      ["statePlan", "stateVisual", "stateMotion", "stateAudio", "stateRender"].forEach(id => setPipeline(id, "DONE"));
      $("renderButton").disabled = false; $("confirmRenderButton").disabled = false;
      $("renderButton").querySelector("span").textContent = "رندر نسخه بعدی";
      const meta = data.metadata || {}; state.lastDownloadUrl = data.download_url;
      $("videoResult").src = data.video_url || data.download_url; $("videoResult").poster = data.poster_url || "";
      $("videoResult").hidden = false; $("downloadButton").href = data.download_url; $("downloadButton").hidden = false;
      $("shareButton").hidden = false; $("openProjectButton").hidden = false;
      const assets = meta.asset_report || {};
      const aiCount = Number(meta.ai_keyframes_loaded || 0);
      const sceneCount = Number(meta.scene_count || 0);
      const visualLabel = aiCount === sceneCount && sceneCount > 0 ? "AI keyframes کامل" : aiCount ? `AI keyframes ${faNumber(aiCount)}/${faNumber(sceneCount)}` : "رندر procedural";
      $("resultMeta").textContent = `${meta.width || "—"} × ${meta.height || "—"} · ${meta.fps || "—"} FPS · ${meta.duration || "—"} ثانیه · ${formatBytes(meta.bytes || 0)} · ${meta.video_codec || "H.264"}/${meta.audio_codec || "AAC"} · ${visualLabel}`;
      $("resultMeta").hidden = false;
      $("previewTitle").textContent = "VIDEO READY"; $("previewSubtitle").textContent = `VERSION ${data.version_number || "—"} · PLAY · DOWNLOAD`;
      const audit = meta.quality_report || {};
      const assetWarnings = [...(assets.warnings || [])];
      if ((assets.unresolved_duplicates || []).length) assetWarnings.push(`تصاویر مشابه حل‌نشده: ${(assets.unresolved_duplicates || []).join(", ")}`);
      const auditText = audit.passed ? "ممیزی فنی فایل نهایی موفق بود: ابعاد، مدت، کدک و جریان صدا بررسی شدند." : `ایرادهای ممیزی فنی: ${(audit.issues || []).join("؛ ")}`;
      const visualPass = assets.visual_audit_passed !== false;
      const diversityText = visualPass
        ? `ممیزی بصری پایه موفق: ${faNumber(assets.generated || 0)} تصویر جدید، ${faNumber(assets.reused || 0)} تصویر از حافظه.`
        : "ممیزی بصری هشدار دارد؛ تنوع یا کیفیت پایه بعضی تصاویر نیازمند بازبینی است.";
      $("renderAudit").textContent = [auditText, diversityText, ...assetWarnings].join("\n");
      $("renderAudit").hidden = false;
      if (data.message) $("jobMessage").textContent = data.message;
      await loadProjects(false);
      return;
    }
    if (data.status === "failed") {
      $("renderButton").disabled = false; $("confirmRenderButton").disabled = false;
      $("renderButton").querySelector("span").textContent = "تلاش دوباره برای رندر";
      $("jobMessage").textContent = `${data.message} ${data.error || ""}`; setPipeline("stateRender", "ERROR"); return;
    }
    state.pollTimer = setTimeout(() => poll(jobId), 1700);
  } catch (error) {
    $("jobMessage").textContent = `خطا در دریافت وضعیت: ${error.message}`;
    $("renderButton").disabled = false; $("confirmRenderButton").disabled = false;
  }
}
function formatBytes(bytes) { return bytes ? `${(bytes / (1024 * 1024)).toFixed(2)} MB` : "—"; }
async function checkHealth() {
  try {
    const data = await api("/api/health");
    $("connectionText").textContent = `موتور ${data.version} متصل`;
    $("connection").classList.add("online");
  } catch {
    $("connectionText").textContent = "موتور در دسترس نیست";
    $("connection").classList.remove("online");
  }
}
async function loadSettings() {
  try {
    const data = await api("/api/settings/ai"); state.savedSettings = data;
    $("defaultProvider").value = data.provider || "nestapi";
    $("defaultNestModel").value = data.nestapi_model || "gpt5";
    $("geminiModel").value = data.gemini_model || "gemini-3.8-flash";
    $("geminiKey").value = "";
    $("geminiKeyStatus").textContent = data.gemini_configured ? "کلید Gemini ذخیره شده و رمز‌شده است." : "هنوز کلید Gemini ذخیره نشده است.";
    $("aiProvider").value = data.provider || "nestapi";
    populateModelSelect(data.provider, data.provider === "nestapi" ? data.nestapi_model : data.gemini_model);
  } catch (error) {
    $("geminiKeyStatus").textContent = `خطا در خواندن تنظیمات: ${error.message}`;
  }
}
function settingsPayload() {
  const body = {
    provider: $("defaultProvider").value,
    nestapi_model: $("defaultNestModel").value,
    gemini_model: $("geminiModel").value.trim() || "gemini-3.8-flash"
  };
  const key = $("geminiKey").value.trim();
  if (key) body.gemini_api_key = key;
  return body;
}
async function saveSettings(test = false) {
  const button = test ? $("testSettingsButton") : $("saveSettingsButton");
  button.disabled = true;
  try {
    const body = settingsPayload();
    const endpoint = test ? "/api/settings/ai/test" : "/api/settings/ai";
    const data = await api(endpoint, { method: "POST", body: JSON.stringify(body) });
    const safeSettings = { ...body };
    delete safeSettings.gemini_api_key;
    state.savedSettings = { ...safeSettings, gemini_configured: data.gemini_configured };
    $("geminiKey").value = "";
    $("geminiKeyStatus").textContent = data.gemini_configured ? "کلید ذخیره شد؛ مقدار آن در UI مخفی می‌ماند." : "تنظیمات ذخیره شد؛ کلید Gemini تنظیم نشده است.";
    $("aiProvider").value = body.provider; populateModelSelect(body.provider, body.provider === "nestapi" ? body.nestapi_model : body.gemini_model);
    $("jobMessage").textContent = test ? `اتصال موفق · ${data.provider} · ${data.model}` : data.message;
    if (test) $("geminiKeyStatus").textContent = `آزمون موفق · ${data.provider} / ${data.model}`;
  } catch (error) {
    $("geminiKeyStatus").textContent = `خطا: ${error.message}`;
  } finally { button.disabled = false; }
}
async function loadProjects(showMessage = true) {
  const list = $("projectList");
  if (!list) return;
  try {
    const data = await api("/api/projects");
    list.replaceChildren();
    if (!data.projects.length) {
      const empty = document.createElement("div"); empty.className = "empty-state"; empty.textContent = "هنوز پروژه‌ای ذخیره نشده است. بعد از ساخت اولین سناریو، پروژه اینجا ظاهر می‌شود."; list.append(empty); return;
    }
    data.projects.forEach(project => {
      const button = document.createElement("button"); button.type = "button"; button.className = "project-list-item";
      const title = document.createElement("b"); title.textContent = project.title || "پروژه بدون عنوان";
      const brief = document.createElement("span"); brief.textContent = (project.brief || "").slice(0, 130);
      const meta = document.createElement("small"); meta.textContent = `نسخه ${faNumber(project.version_number || 0)} · ${new Date(project.updated_at).toLocaleString("fa-IR")}`;
      button.append(title, brief, meta); button.addEventListener("click", () => loadProject(project.project_id)); list.append(button);
    });
    if (showMessage) $("jobMessage").textContent = `${faNumber(data.projects.length)} پروژه از حافظه بارگذاری شد.`;
  } catch (error) {
    list.innerHTML = ""; const empty = document.createElement("div"); empty.className = "empty-state"; empty.textContent = `بارگذاری کتابخانه ناموفق بود: ${error.message}`; list.append(empty);
  }
}
async function loadProject(projectId) {
  try {
    const project = await api(`/api/projects/${projectId}`); state.selectedProject = project; state.projectId = projectId;
    $("projectDetailTitle").textContent = project.title || "پروژه CineForge";
    $("projectDetailMeta").textContent = `${faNumber(project.version_number)} نسخه ذخیره‌شده · آخرین تغییر ${new Date(project.updated_at).toLocaleString("fa-IR")}`;
    const content = $("projectDetailContent"); content.replaceChildren();
    const brief = document.createElement("p"); brief.className = "saved-brief"; brief.textContent = project.brief || ""; content.append(brief);
    if (project.video_url) {
      const video = document.createElement("video"); video.className = "saved-video"; video.controls = true; video.playsInline = true; video.src = project.video_url; content.append(video);
      const dl = document.createElement("a"); dl.className = "download-button"; dl.href = project.download_url; dl.textContent = "دریافت آخرین نسخه MP4 ↓"; dl.download = "cineforge-project.mp4"; content.append(dl);
    }
    const versionHeading = document.createElement("h3"); versionHeading.textContent = "تاریخچه نسخه‌ها"; content.append(versionHeading);
    (project.versions || []).forEach(version => {
      const item = document.createElement("div"); item.className = "version-row";
      const label = document.createElement("b"); label.textContent = `نسخه ${faNumber(version.version_number)}`;
      const details = document.createElement("span"); details.textContent = version.user_instruction || "رندر اولیه";
      const time = document.createElement("small"); time.textContent = new Date(version.created_at).toLocaleString("fa-IR");
      item.append(label, details, time); content.append(item);
    });
    const chatHeading = document.createElement("h3"); chatHeading.textContent = "گفت‌وگوی پروژه"; content.append(chatHeading);
    (project.messages || []).slice(-12).forEach(message => {
      const item = document.createElement("div"); item.className = `message-row ${message.role}`;
      const role = document.createElement("b"); role.textContent = message.role === "user" ? "تو" : "CineForge";
      const text = document.createElement("p"); text.textContent = message.content;
      item.append(role, text); content.append(item);
    });
    $("editChat").hidden = false; $("editInstruction").value = "";
  } catch (error) { $("projectDetailContent").textContent = error.message; }
}
async function sendProjectEdit() {
  if (!state.selectedProject) return;
  const instruction = $("editInstruction").value.trim();
  if (instruction.length < 2) { $("editInstruction").focus(); return; }
  const button = $("sendEditButton"); button.disabled = true; button.querySelector("span").textContent = "در حال تطبیق با آخرین نسخه…";
  try {
    const provider = $("defaultProvider").value || $("aiProvider").value;
    const model = provider === "gemini" ? $("geminiModel").value.trim() : $("defaultNestModel").value.trim();
    const result = await api(`/api/projects/${state.selectedProject.project_id}/edit`, {
      method: "POST", body: JSON.stringify({ instruction, provider, model })
    });
    state.projectId = result.project_id;
    $("prompt").value = (state.selectedProject.request?.prompt || state.selectedProject.brief || "") + `\n\nویرایش: ${instruction}`;
    renderPlan(result.plan, result.planner, result.note, result.model, result.project_id, result.audit);
    showView("studio");
    $("jobMessage").textContent = "سناریوی اصلاح‌شده آماده است؛ می‌توانی آن را بررسی و رندر کنی.";
  } catch (error) { $("projectDetailMeta").textContent = `ویرایش ناموفق: ${error.message}`; }
  finally { button.disabled = false; button.querySelector("span").textContent = "تحلیل دستور و ساخت نسخه جدید سناریو"; }
}

async function loadNestApiVoices() {
  const button = $("fetchVoicesButton");
  const select = $("voiceoverVoice");
  const language = $("language")?.value || "fa";
  button.disabled = true;
  $("voiceStatus").textContent = "در حال دریافت فهرست صداها از NestAPI…";
  try {
    const result = await api(`/api/audio/voices?locale=${encodeURIComponent(language)}`);
    const previous = select.value;
    const options = [new Option("تشخیص خودکار زبان و صدا", "auto")];
    for (const voice of (result.voices || [])) {
      if (!voice.id) continue;
      const label = voice.locale ? `${voice.label || voice.id} · ${voice.locale}` : (voice.label || voice.id);
      options.push(new Option(label, voice.id));
    }
    select.replaceChildren(...options);
    select.value = options.some(option => option.value === previous) ? previous : "auto";
    $("voiceStatus").textContent = `${faNumber(result.count || options.length - 1)} صدای قابل انتخاب از NestAPI دریافت شد.`;
  } catch (error) {
    $("voiceStatus").textContent = `دریافت فهرست صداها ناموفق بود: ${error.message}`;
  } finally { button.disabled = false; }
}

// Navigation and core actions
document.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click", () => showView(button.dataset.view)));
document.querySelectorAll("[data-view-link]").forEach(link => link.addEventListener("click", () => showView(link.dataset.viewLink)));
$("planButton").addEventListener("click", designPlan);
$("replanButton").addEventListener("click", designPlan);
$("renderButton").addEventListener("click", startRender);
$("confirmRenderButton").addEventListener("click", startRender);
$("prompt").addEventListener("input", () => {
  $("charCount").textContent = `${faNumber($("prompt").value.length)} / ۱۰۰۰۰`;
  if (state.plan && state.projectId) state.projectId = null;
  state.plan = null; $("renderButton").disabled = true;
});
$("volume").addEventListener("input", () => { $("volumeValue").textContent = `${faNumber($("volume").value)}٪`; });
$("aiProvider").addEventListener("change", () => populateModelSelect($("aiProvider").value));
$("geminiModel").addEventListener("input", () => { if ($("aiProvider").value === "gemini") populateModelSelect("gemini"); });
$("defaultProvider").addEventListener("change", () => { $("aiProvider").value = $("defaultProvider").value; populateModelSelect($("aiProvider").value); });
$("defaultNestModel").addEventListener("change", () => { if ($("aiProvider").value === "nestapi") populateModelSelect("nestapi", $("defaultNestModel").value.trim()); });
$("saveSettingsButton").addEventListener("click", () => saveSettings(false));
$("testSettingsButton").addEventListener("click", () => saveSettings(true));
$("fetchVoicesButton").addEventListener("click", loadNestApiVoices);
$("sendEditButton").addEventListener("click", sendProjectEdit);
$("refreshProjects").addEventListener("click", () => loadProjects());
$("openProjectButton").addEventListener("click", () => showView("library"));
$("shareButton").addEventListener("click", async () => {
  if (!state.lastDownloadUrl) return;
  const absolute = new URL(state.lastDownloadUrl, location.href).href;
  if (navigator.share) {
    try { await navigator.share({ title: "CineForge video", url: absolute }); } catch {}
  } else {
    try { await navigator.clipboard.writeText(absolute); $("jobMessage").textContent = "لینک دانلود کپی شد."; }
    catch { $("jobMessage").textContent = absolute; }
  }
});
for (const id of preferenceIds) $(id)?.addEventListener("change", () => {
  savePreferences();
  if (state.plan) { state.plan = null; $("renderButton").disabled = true; $("plannerNote").textContent = "تنظیمات پروژه تغییر کرده؛ برای تطبیق نقشه دوباره تحلیل کن."; }
});
restorePreferences();
populateModelSelect($("aiProvider").value, $("aiModel").value || $("defaultNestModel").value);
$("charCount").textContent = `${faNumber($("prompt").value.length)} / ۱۰۰۰۰`;
$("volumeValue").textContent = `${faNumber($("volume").value)}٪`;
checkHealth();
loadSettings();
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js?v=0.4.1").catch(() => {});
